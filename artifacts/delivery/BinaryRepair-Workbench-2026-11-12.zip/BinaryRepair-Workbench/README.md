# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

### macOS / Linux
```bash
chmod +x start-gui.sh
./start-gui.sh
```

### Windows
双击 `start-gui.bat`（或 `.\start-gui.ps1`）。

首次启动创建 `.venv`、安装依赖并生成本地 token；打开终端里带 `?token=` 的完整地址。

## 这一版重点

- **结果与证据空状态修复**：未选择任务时显示 N/A、V0–V5 “未回传”和明确引导，不再出现永久“正在计算/读取”。
- **补丁硬门禁**：C/C++ 补丁返回前做作用域/容量检查 + `clang -fsyntax-only`；坏补丁直接拒绝，不展示。
- **真实容量模型**：数组/成员用 `sizeof`，`malloc`/`realloc` 用实际容量；未知指针容量不自动改写。
- **C 溢出规则**：12 类种子 + 栈 memcpy、while 循环、snprintf 格式串、数组索引、有符号长度、realloc 容量同步。
- **有界 AI**：AI 可接受/否决/重试，不能把失败 gate 提升为成功。
- **知识库**：1200 条合成变体、候选模型、编译/导入面验证；诚实指标见 `docs/acceptance/overflow-ai-2026-11-12.md`。
- **公开 v1.2.1 文档修正 patch**：`artifacts/delivery/public-v1.2.1-docs.patch`。

## 边界

- 编译校验只证明语法/声明，不证明安全；仍需 ASan/UBSan、fuzz、差分/契约验证。
- 模型不是最终裁判；阳性成功由确定性 gate 决定。
- 知识库合成训练，留一种子约 0.25；不是通用 0-day 检测器。
- 公开仓库无推送凭据；其文档 patch 需有权限者 `git am`。

## 帮助

- `START-HERE.md`
- 启动后访问 `/guide`。
- 端口冲突：`BINARYREPAIR_PORT=8124 ./start-gui.sh`。
