# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

```bash
chmod +x start-gui.sh
./start-gui.sh
```

Windows 双击 `start-gui.bat`，或 `.\start-gui.ps1`。

## 这一版重点

- **CGC 二进制语料**：已构建 5 对 vulnerable/patched（Mach-O arm64），静态盘点与 LIEF 特征。
- **数据集适配**：BinPool/CveBinarySheet/CGC 元数据、配对、NVD 样例、训练切分；详见 `docs/reference/`。
- **补丁硬门禁**：作用域/容量检查 + clang 语法检查；坏补丁拒绝。
- **C 溢出规则**：栈/堆/循环/格式串/数组索引/有符号长度/realloc 容量同步。
- **结果空状态**：未选任务显示 N/A，不再永久加载。
- **固定局域网入口**：`./start-lan.sh`。

## 边界

- CGC 是 5 个挑战的子集，不是 100+ 全量；未执行 challenge 二进制。
- BinPool 40 GB / CveBinarySheet 12.5 GB 未随包分发；需自行下载。
- Ghidra 已下载但 JDK 25 未完成；RAVERSE 未安装；Mutagen 无 Ollama。
- 编译校验不证明安全；仍需 ASan/UBSan、fuzz、契约验证。
- 公开仓库无推送凭据；其文档 patch 需有权限者 `git am`。
