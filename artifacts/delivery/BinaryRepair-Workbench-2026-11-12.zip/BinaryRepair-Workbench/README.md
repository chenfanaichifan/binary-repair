# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

### macOS / Linux
```bash
chmod +x start-gui.sh
./start-gui.sh
```

### Windows
双击 `start-gui.bat`（或 `.\start-gui.ps1`）。

首次启动创建 `.venv`、安装依赖并生成本地 token；打开终端里带 `?token=` 的完整地址。

## 这一版重点

- **有界 AI 判定**：AI 可接受/否决/重试，不能把失败 gate 提升为成功；`/api/ai/boundary`、`/api/ai/adjudicate`。
- **补丁硬门禁**：C/C++ 补丁返回前做作用域/容量静态检查 + `clang -fsyntax-only`；失败则拒绝并返回原代码。
- **真实容量模型**：数组/成员用 `sizeof`，`malloc`/`realloc` 用实际容量；未知指针容量不自动改写。
- **C 溢出覆盖**：6 类根因、12 个种子、12 条规则；新增 while 循环、栈 memcpy、snprintf 格式串、数组索引、有符号长度等。
- **结果与证据控制室**、九语界面、克制的明暗双主题。
- **知识库**：1200 条合成变体、候选模型、编译/导入面验证；诚实指标见 `docs/acceptance/overflow-ai-2026-11-12.md`。
- **公开 v1.2.1 文档修正 patch**：`artifacts/delivery/public-v1.2.1-docs.patch`。

## 边界

- 演示模式使用合成 fixture，不执行真实修复。
- 编译校验只证明语法/声明成立，不证明安全；仍需 ASan/UBSan、fuzz、差分/契约验证。
- 模型不是最终裁判；阳性成功由确定性 gate 决定。
- 知识库为合成数据训练，留一种子准确率约 0.25；不是通用 0-day 检测器。
- 真实 provider key 只保存在各自本机服务端；包内没有 key。
- 公开仓库无推送凭据；其文档 patch 需有权限者 `git am`。

## 帮助

- `START-HERE.md`
- 启动后访问 `/guide`。
- 端口冲突：`BINARYREPAIR_PORT=8124 ./start-gui.sh`。
