# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

### macOS / Linux
```bash
chmod +x start-gui.sh
./start-gui.sh
```

### Windows
双击 `start-gui.bat`（或 `.\start-gui.ps1`）。

首次启动创建 `.venv`、安装依赖并生成本地 token；打开终端里带 `?token=` 的完整地址。

## 这一版重点

- **统一启动卡**：真实任务 / 演示会话 + 成功/失败场景，不再有两个割裂入口。
- **结果与证据控制室**：证据总览、V0–V5 矩阵、义务筛选、Attempts、产物指纹、原始 JSON。
- **只读评估**：`/api/jobs/{id}/evaluation` 输出覆盖率和缺口，不自行给出 verdict；缺失分母显示 N/A。
- **九语界面**：简体中文、繁體中文、English、日本語、한국어、Français、Italiano、Português、Español；长页面文案也已本地化，技术标识/代码保留原文。
- **明暗双主题**：浅色为瓷白/虹彩/青绿半透明玻璃，深色为午夜/青紫极光；带轻量动效与降级开关。
- **完整手册**：12 节、证据链图、步骤表、V0–V5、故障排查、安全边界、全球研究链接。
- **响应式**：手机/窄窗口使用顶栏 + 抽屉侧栏。
- **质量/效率报告**：`docs/acceptance/repair-evaluation-2026-11-12.md`。

## 边界

- 演示模式使用合成 fixture，不执行真实修复，不构成「补丁已验证」。
- 技术原文/证据标识保留原语言；不把机器翻译当作安全结论。
- 真实 provider key 只保存在各自本机服务端；包内没有 key。
- 插件清单只读；连接器“就绪”只代表本机具备条件。

## 帮助

- `START-HERE.md`：第一次使用。
- 启动后访问 `/guide`。
- 端口冲突：`BINARYREPAIR_PORT=8124 ./start-gui.sh`。
- 依赖失败：删除 `.venv` 后重试，确认 Python 3.10+。

主仓库含测试、验收证据与开发文档；本包是体验用瘦身版。
