# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

### macOS / Linux
```bash
chmod +x start-gui.sh
./start-gui.sh
```

### Windows
双击 `start-gui.bat`（或 `.\start-gui.ps1`）。

首次启动创建 `.venv`、安装依赖并生成本地 token；打开终端里带 `?token=` 的完整地址。

## 这一版重点

- **统一启动卡**：真实任务 / 演示会话 + 成功/失败场景。
- **结果与证据控制室**：证据总览、V0–V5 矩阵、义务筛选、Attempts、产物指纹、原始 JSON。
- **C 溢出覆盖**：6 类根因、12 个带标签种子、12 条检测/补丁规则。
- **候选记忆**：1200 条合成变体离线训练；规则主检测，模型只做候选排序。诚实指标见 `docs/acceptance/overflow-ai-2026-11-12.md`。
- **有界 AI 判定**：AI 可接受/否决/重试，但不能把失败 gate 提升为成功；`/api/ai/adjudicate` 与 `/api/ai/boundary`。
- **编译验证**：12/12 原始样本与 12/12 补丁通过 clang+ASan 编译；未执行漏洞程序。
- **二进制表面扫描**：导入符号/格式化字符串只读清点，不是漏洞结论。
- **九语界面**：导航、设置、指南、Agent 消息、结果页、代码修复卡均已覆盖。
- **克制的明暗双主题**。
- **公开 v1.2.1 文档修正 patch**：`artifacts/delivery/public-v1.2.1-docs.patch`。

## 边界

- 演示模式使用合成 fixture，不执行真实修复。
- 代码、任务 ID、SHA、verdict 值等保持原样；机器翻译不是安全结论。
- 知识库为合成数据训练，留一种子准确率约 0.25；不是通用 0-day 检测器。
- AI 仍是“自主操作者”，不是无证据的最终裁判；阳性成功由确定性 gate 决定。
- 真实 provider key 只保存在各自本机服务端；包内没有 key。
- **N-10**：自定义 key 文件要求 adapter 看到同一环境；未满足时 fail closed。
- **N-11**：本包在 `/api/ai/adjudicate` 路径有运行时字段 guard，但公开仓库其他路径仍需按 patch/文档逐项接入。
- 公开仓库无推送凭据；其文档 patch 可直接 `git am`。

## 帮助

- `START-HERE.md`
- 启动后访问 `/guide`。
- 端口冲突：`BINARYREPAIR_PORT=8124 ./start-gui.sh`。
