# BinaryRepair Workbench · 组员预览版

本地运行的 AI 二进制漏洞修复工作台。无需后端或数据库，启动后用浏览器打开。

## 30 秒启动

### macOS / Linux
```bash
chmod +x start-gui.sh
./start-gui.sh
```

### Windows
双击 `start-gui.bat`（或 `.\start-gui.ps1`）。

首次启动创建 `.venv`、安装依赖并生成本地 token；打开终端里带 `?token=` 的完整地址。

## 这一版重点

- **结果空状态**：未选任务显示 N/A 与 V0–V5 未回传，不再永久加载。
- **补丁硬门禁**：C/C++ 补丁作用域/容量检查 + clang 语法检查；坏补丁拒绝。
- **真实容量模型**：数组/成员 `sizeof`，malloc/realloc 实际容量；未知指针不自动改。
- **C 溢出规则**：12 类种子 + 栈 memcpy、while 循环、格式串、数组索引、有符号长度、realloc 容量同步。
- **二进制数据集适配**：BinPool/CveBinarySheet 元数据、配对、NVD 样例、工具链探测；详见 `docs/reference/binary-vulnerability-datasets.md`。
- **训练切分**：`knowledge/binpool_splits.json`（395/110/81，按 CVE 隔离）。
- **本地二进制特征**：24 个 Mach-O 样本，LIEF/strings 特征。
- **固定局域网入口**：`./start-lan.sh`，固定 token/端口/Bonjour 主机名。

## 边界

- 编译校验只证明语法/声明，不证明安全；仍需 ASan/UBSan、fuzz、差分/契约验证。
- 模型不是最终裁判；阳性成功由确定性 gate 决定。
- 知识库合成训练，留一种子约 0.25；不是通用 0-day 检测器。
- BinPool/CveBinarySheet 二进制未随包分发；需从官方仓库自行下载并在隔离 guest 处理。
- Ghidra 已下载但 JDK 25 未完成，未运行；RAVERSE 未安装；Mutagen 已安装但 Ollama 不可用。
- 公开仓库无推送凭据；其文档 patch 需有权限者 `git am`。
