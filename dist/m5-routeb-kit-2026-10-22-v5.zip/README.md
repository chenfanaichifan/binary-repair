# M5 Route B / Gate 4 kit (v5)

**Formal Gate 4: NOT RUN.** GitHub Actions 6/6 is supplementary only. M3 runs
this kit in the isolation-ready snapshot; M5 judges; M4 verifies image/tools.

## Environment

```bash
export PYTHON=/opt/angr-venv/bin/python
export GHIDRA_HOME=/opt/ghidra_12.1.4_PUBLIC
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export CLANG=clang          # snapshot 18.1.3
export LLD=ld.lld
```

Expected: JDK 21.0.12.1, Ghidra 12.1.4, Patcherex2 0.2.14, angr 10.0.4,
z3 5.1.0, LIEF 1.0.0, clang 18.1.3, ld.lld 18.

Patcherex2 calls literal `clang-15`/`ld.lld-15`; the runner creates per-job
symlinks to `$CLANG`/`$LLD`, prepends them to PATH, and records actual versions.
No sudo or system install.

## Run (root jobwrap -> setuid 1003, netns, no_new_privs, clear caps, fixed argv)

```bash
jobwrap ... -- /path/to/repo/routeb/gate4_runner.sh /path/to/repo /var/tmp/gate4-work
```

Never `sudo -u runner jobwrap`; never `unshare` inside the runner. The runner
checks uid 1003, ELF SHA-256 `aa428157…8393`, tools, then runs Ghidra export,
Patcherex2 unchanged round trip and the six-case compare. It writes
`gate4-status.json` = `pass` / `fail` / `not_run`.

## Six cases

| id | argv[1] | expected |
|---|---|---|
| valid-empty | `""` | rc 0, stdout `0a`, stderr empty |
| valid-smallest | `"A"` | rc 0, stdout `410a`, stderr empty |
| valid-typical | `"AAAAAAAAAA"` | rc 0, stdout `41…0a`, stderr empty |
| valid-maximum | 49 × `A` | rc 0, stdout 49 × `41` + `0a`, stderr empty |
| invalid-first | 50 × `A` | rc **1**, stdout empty, stderr 42 B exact |
| invalid-longer | 100 × `A` | rc **1**, stdout empty, stderr 42 B exact |

All six:

```bash
"$PYTHON" routeb/run_manifest_compare.py \
  --original "$WORK/original.elf" --patched "$WORK/roundtrip.elf" \
  --tests fixtures/public/CWE121_src_char_declare_cpy_51b/tests \
  --out "$WORK/manifest-compare.json"
```

`manifest-compare.json` must contain `same_count=6,total=6,gate4_pass=true`.
`gate4-status.json` contains `gate4`, `reason`, `uid`, `expected_uid`,
`elf_sha256`, `patched_sha256`, `manifest_compare`, `environment`.

## Contract note

`contract.json` entry 1 now says branch back to **0x401309** (the call at
`0x401304` is 5 bytes; `0x401308` is its last byte). Canonical hash:
`1a0ad101097461b207e3ea07e264d8d6eb03bc57d1f54c7b9e41c2955015c10c`.
