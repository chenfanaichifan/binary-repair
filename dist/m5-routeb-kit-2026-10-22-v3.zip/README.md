# M5 Route B / Gate 4 kit (v3)

Run inside the jobwrap job as uid 1003 (jobwrap root -> setuid 1003; do **not**
call `sudo -u runner jobwrap` and do not `unshare` inside the runner):

```bash
./routeb/gate4_runner.sh "$PWD" /var/tmp/gate4-work
```

Expects JDK 21.0.12.1, Ghidra 12.1.4, Patcherex2 0.2.14, angr 10.0.4,
z3 5.1.0, LIEF 1.0.0, `clang-15` and `ld.lld-15`.

The runner checks uid 1003 (override with `EXPECTED_UID` only for a dry run),
ELF SHA-256 `aa428157…8393`, then runs Ghidra export, Patcherex2 unchanged
round trip and the six-case manifest compare. It writes
`gate4-status.json` with `gate4` = `pass` / `fail` / `not_run`.

Manual pieces:

```bash
sha256sum fixtures/.../original.elf
./routeb/ghidra/export.sh fixtures/.../original.elf \
  CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink routeb/out/gate4
python3 routeb/probe_patcherex2.py --mode roundtrip \
  --binary fixtures/.../original.elf \
  --func CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink \
  --c-source routeb/experiment/samples/juliet_badSink.normalized.c \
  --out routeb/out/gate4/roundtrip.elf --skip-verify
python3 routeb/run_manifest_compare.py --original fixtures/.../original.elf \
  --patched routeb/out/gate4/roundtrip.elf \
  --tests fixtures/.../tests --out routeb/out/gate4/manifest-compare.json
```
