# M3-121 handoff - 2026-11-05

Record 121 plus what it cites: the CWE416 no-input fixture closed out. One valid
case in the fixture, a v3 contract with no rejection path, a `trigger_case` that
says `not_applicable` instead of leaving a note that reads like a missing case,
and the manifest rebuilt over the change.

Contents:

- `121-m3-cwe416-noinput-closeout-2026-11-05.md` - the record.
- `evidence/cwe416-noinput-close-2026-11-05/` - 11 files plus its own
  `SHA256SUMS`: the contract and the one case, `defect.json` before/after and the
  one-line diff, the manifest either side, the intake rerun with the code hashes
  that identify it, the in-place verification, and the V3/V4 wording.
- `fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput/` - 14 files,
  `tests/SHA256SUMS` covering the other 13. Upstream bytes for
  `original.c`, `support/io.c` and `support/std_testcase*.h`; `original.elf` is
  the guest-built artefact; `src.c` is a byte-identical alias the build never reads.

Check it in place, from this directory:

    (cd evidence/cwe416-noinput-close-2026-11-05 && sha256sum -c SHA256SUMS)
    (cd fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput && sha256sum -c tests/SHA256SUMS)
    sha256sum -c SHA256SUMS          # every other file here

What this does not claim:

- No candidate. Repair is Route A/B work, not the fixture author's.
- V3 is `not_run`. When a candidate exists it is scored `<k>/1` with invalid
  `not_applicable` - not `0/0`, not `0/2`, not `skipped`, not a missing field.
- V4 is `not_run`. There is no input domain; "binary-level" would name a
  category this fixture does not have.
- T8.3 stays blocked. One defect class, measured again.

Note for anyone holding the 120 bundle: its fixture copy is the snapshot at
`0936ac6`. `defect.json` moved since, so read that copy as 120-specific, not as
the current tree.
