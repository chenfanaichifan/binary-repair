# M3-120 handoff - 2026-11-05

Record 120 plus everything it cites, in one file: the CWE416 no-input contract
moved to schema v3, the evidence that the move was measured rather than stated,
and the fixture directory in the shape it now has.

Contents:

- `120-m3-cwe416-v3-contract-2026-11-05.md` - the record.
- `evidence/cwe416-v3-2026-11-05/` - 9 files plus its own `SHA256SUMS`:
  `01`/`02` the contract before and after, `03` a two-line diff, `04` loader
  probes including the two near-miss shapes, `05` every intake run, `06` the
  hashes that did not move, `07` the scoped test run, `08` the `src.c` alias,
  `README.md` saying which file answers which question.
- `fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput/` - 14 files,
  `tests/SHA256SUMS` covering the other 13. `original.c`, `support/io.c`
  and `support/std_testcase*.h` are upstream bytes, unmodified; `original.elf`
  is the guest-built artefact; `src.c` is a byte-identical alias of `original.c`
  that the build never reads.

Check it in place, from this directory:

    (cd evidence/cwe416-v3-2026-11-05 && sha256sum -c SHA256SUMS)
    (cd fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput && sha256sum -c tests/SHA256SUMS)
    sha256sum -c SHA256SUMS          # every other file here

What this does not claim:

- No candidate. Repair is Route A/B work, not the fixture author's.
- V3 is `not_run`, and its ceiling on this fixture is 1/1 no-input.
- V4 is `not_run`. There is no input domain; calling that "binary-level" would
  be a category error.
- T8.3 stays blocked. This is one defect class, measured again, not a second one.

One consequence worth reading before filing anything against it: the contract
still requires `symbolic`, while V4 is `not_run`, so any future candidate will
be judged inconclusive on REQUIRED_CHECK_NOT_RUN. That is the honest verdict
under the current obligation set, not a bug in this package.
