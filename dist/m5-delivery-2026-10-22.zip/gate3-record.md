# Gate 3 acceptance record — Route A

**Verifier:** Member 4 (verification slice)
**Date:** 2026-10-22
**Candidate:** `routea/out/cave-probe.elf`, SHA-256 `c4a1592157a2858fcf2dd52623b6ae8c280355ce735a1c224530845569bcaa82`
**Original:** `fixtures/public/CWE121_src_char_declare_cpy_51b/original.elf`,
SHA-256 `aa42815704d9ffc65b3a49821b3cc6189126a738a7e02d668dec250982408393`
**Contract:** canonical SHA-256 `24bfe568e162be57de013abaeda96060d7edf4cad4b2eca0b003d929d9ec4e37`
(M5 canonical v2; M4 proposal `ba33b4d0...` superseded — see §6)
**Basis:** handoff 11 §3 (six required items), handoff 12 (M4 plan), handoff 16/17/18/19
(M5 canonical contract, six-item matrix, build recipe, routea review), verification-design §4.4

**Approval status:** **DRAFT — NOT SIGNED.** The Lead approved the review process; the
signature fields stay blank until items 3–6 are `PASS`. Replay ruling (handoff 19): the Lead
waives **only the full independent rerun** of the six cases by M5; M5's **build/hash replay is
still required** (`c4a159…` reproduced, contract `24bfe568…`, bundle `SHA256SUMS`/bundle hash
recomputed and reported).
**Overall status:** **CONDITIONALLY FEASIBLE — items 3–6 `NOT VERIFIED`.** Gate 3 is **not
signed**; a CI `6/6` or a static audit is not a pass.

---

## 1. Frozen identity (re-measured by M4)

| Value | Frozen / claimed | M4 independent measurement | Match |
|---|---|---|---|
| original ELF SHA-256 | `aa428157...8393` | `aa42815704d9ffc65b3a49821b3cc6189126a738a7e02d668dec250982408393` | PASS |
| candidate SHA-256 | `c4a159...aa82` | `c4a1592157a2858fcf2dd52623b6ae8c280355ce735a1c224530845569bcaa82` | PASS |
| contract canonical SHA-256 | `24bfe568...4e37` | independently recomputed from `contract.json` (17 fields, 4 lists sorted, compact JSON) = `24bfe568e162be57de013abaeda96060d7edf4cad4b2eca0b003d929d9ec4e37` | PASS |
| contract file SHA-256 | not claimed | `15f6b492608e8c137f2612058bf43b90173284aec86d8c51b25d09903d0ad8df` (1,998 B) | recorded |
| original size | 26,792 B | 26,792 B | PASS |
| candidate size | 26,792 B | 26,792 B | PASS |
| `valid.json` / `invalid.json` / manifest-set hashes | `17b2ee...` / `d493f3...` / `a564f0...` | not re-measured here (files not in workspace) | NOT VERIFIED |

## 2. M4 independent structural measurements

Measured with a struct-only ELF parser; no candidate byte executed, no producer module imported.

**Program headers:** only `PT_LOAD[3]` changed — `p_filesz`/`p_memsz` `0x8e9 -> 0x1000`, offset
`0x1000`, vaddr `0x401000`, flags `R E`, other three segments unchanged, loadable count 4.

**Redirect at vaddr `0x401304` (file offset `0x1304`):** `e8 c7 fd ff ff` -> `e8 e0 05 00 00`
(rel32 `+0x5e0` -> `0x4018e9`), matching the manifest.

**Changed file intervals (13):** `0x108-0x109`, `0x110-0x111` (header fields), `0x1305-0x1308`
(redirect tail), `0x18e9-0x1959` (added cave code + message), as itemised in the earlier run.

## 3. Schema-2 manifest claims re-measured against candidate bytes

M5's schema-2 manifest was checked by reading the candidate bytes directly:

| Claim | M4 measurement | Match |
|---|---|---|
| added code 71 B @ file `0x18e9` sha256 `cd032694...` | recomputed = `cd0326946d931b2566d888e7244a917ef90f97e62be60c87805d4d03bbd7203e` | PASS |
| added data 42 B @ file `0x1930` sha256 `083d3bfb...` | recomputed = `083d3bfb2d9e1fa4978aabdd2318d60c67bd54f2a34d0086b0a9d11f6f84f69b` | PASS |
| added data is the frozen message | bytes equal `ERROR: input exceeds destination capacity\n` | PASS |
| writer = `write(2)` syscall | `syscall` (`0f 05`) at code offsets 52 and 64; `mov eax,1` at offset 30; `mov eax,231` at offset 54 | PASS |
| termination = `exit_group(1)` | `mov eax,231` present | PASS |
| no `fprintf@plt` call | no `e8` call target lands in the PLT range `0x4011xx` | PASS |

**Consequence:** the candidate writes the message with a raw `write` syscall and terminates with
`exit_group(1)`. It needs **no new import, no PLT/GOT edit** — the cleanest possible writer for
this contract. This differs from handoff 12 §2.2, which described a `fprintf@plt` + `stderr`
COPY-relocation writer based on the earlier `f3cb9cbb...` candidate. The contract's
`authorized_edits` item 4 allows writing to fd 2, so the syscall path is authorised; the
`allowed_calls` list allows `fprintf` but the code does not use it.

## 4. Six required items (handoff 11 §3)

| # | Item | Status | Evidence / reason |
|---|---|---|---|
| 1 | Separate candidate copy; original untouched | **PASS** | original hash still the frozen value; candidate is a separate file |
| 2 | Candidate identity and reproducibility | **PASS** | candidate hash matches; schema-2 manifest complete (displaced/added/intervals/header/writer/termination/tool_versions); build recipe `18-build-recipe.md` with `regen_c4a159.py` (stdlib-only, fail-closed) |
| 3 | Structural audit (cave R-X runtime probe, `p_filesz`/`p_memsz`, redirect; LIEF/NX/RELRO/canary/import diff) | **NOT VERIFIED** | static structure re-measured PASS (§2–3), but the runtime R-X map probe and the LIEF/NX/RELRO/canary/import diff have not been executed on the candidate |
| 4 | Six-case run (4 valid + 2 invalid = 6/6 byte-exact) | **NOT VERIFIED** | GitHub CI 6/6 is supplementary only; the required reverted-snapshot run on the guest has not been executed |
| 5 | Isolation evidence for that run (snapshot, egress block, uid 1003, wrapper attestation) | **NOT VERIFIED** | no formal isolation evidence yet |
| 6 | Evidence bundle (raw outputs + hashes) | **NOT VERIFIED** | this record + `docs/route-a/SHA256SUMS` only; the formal VM bundle and its hashes are missing |

**Gate 3 verdict: NOT signed — CONDITIONALLY FEASIBLE.** Only `PASS` / `FAIL` / `NOT VERIFIED`
are valid item labels; "partial" is not a gate label. Items 3–6 are hard requirements; a CI
`6/6` does not substitute for them (handoff 13 §5.6).

## 5. Producer inputs used (read-only, not M4 evidence)

| File | SHA-256 |
|---|---|
| `routea/out/edit-manifest.json` (schema 2) | `1b1c7321...` (schema 1) — re-exported schema 2 recorded in §3 |
| `routea/out/audit.json` | `1b1c73211f4953126f4e989cba4d5dcb68757d1b190ac4c8010776890cdb0af2` |
| `routea/out/readelf-audit.txt` | `086ce7c87f535fbc5ed583da529a05ddfae0c75846c6a543bd4aaab1d02825c5` |
| M5 contract revision approval | `docs/route-b/16-contract-revision-approval.md` |
| M5 six-item matrix | `docs/route-b/17-gate3-six-item-matrix.md` |
| M5 build recipe | `docs/route-b/18-build-recipe.md` |
| M5 routea review | `docs/route-b/19-routea-review.md` |

## 6. Deviations and open items

1. **Contract hash changed.** M4's proposal `ba33b4d0...` is superseded by M5's canonical v2
   `24bfe568...`. The changes are explicit (same six `authorized_edits`, `entry 1 = 0x401309`,
   `allowed_calls = ("fprintf","printLine","strcpy")`, environment assumptions narrowed to
   "CET compile-time only", "guest seccomp not yet recorded"). M4 re-measured the new canonical
   hash and it matches. **Approval must cite `24bfe568...`, not `ba33b4d0...`.**
2. **Writer mechanism differs from handoff 12 §2.2.** Actual candidate uses raw `write` +
   `exit_group` syscalls, no `fprintf@plt`. handoff 12's writer description is stale (based on
   `f3cb9cbb...`). The contract authorises fd-2 write, so the implementation is in scope; the
   record must state the syscall path, not the stale PLT description.
3. **Candidate hash history.** handoff 12 records `f3cb9cbb...`; the delivered candidate is
   `c4a159...`. handoff 12's value is superseded; `c4a159` is the single gate-3 subject.
4. **M4 audit branch resubmitted (handoff 18).** `origin/member-4-routea-gate3` @ `2ac0f66`
   (base `ad1a1f8`) retargets the tooling to `c4a159…`/`24bfe568…` and fixes M5's B1–B6; patch
   `docs/route-a/m4-patches/0002-member-4-routea-gate3-canonical-audit.patch`
   (`b68aabcd…cab8`). M5 re-review is pending; the old `7977bac` / patch `0001` is superseded.
5. **M4's earlier `f3cb9cbb` cross-check is void** and must not be cited.

## 7. What must happen before this record can be signed

1. Run item 4 on the isolation-ready guest from a reverted snapshot, recording byte-exact
   results for the six frozen cases.
2. Run item 5: snapshot revert log, no-egress attestation, uid-1003 execution evidence.
3. Run the runtime R-X cave probe (map `0x401000-0x401fff`, cave bytes == memory, instruction at
   cave entry executes).
4. Re-measure `valid.json` / `invalid.json` / manifest-set hashes in the guest.
5. **M5 replay (handoff 19):** the Lead waives only the **full independent rerun** of the six
   frozen cases. **M5's build/hash replay is not waived:** reproduce candidate `c4a159…aa82`
   from the recorded recipe on `original.elf` (`aa428157…`), verify contract `24bfe568…4e37`,
   recompute the evidence bundle `SHA256SUMS`/bundle hash, and report the observed hashes. Until
   that replay exists, this record stays DRAFT and the signature line stays blank.

## 8. M5 review status: RE-REVIEW PENDING

M5 reviewed the first patch (`docs/route-b/20-m4-patch-review.md`) and requested changes
B1–B6. M4 resubmitted on base `ad1a1f8` (handoff 18): branch
`origin/member-4-routea-gate3` @ `2ac0f66`, patch
`docs/route-a/m4-patches/0002-member-4-routea-gate3-canonical-audit.patch`
(`b68aabcd…cab8`), additive tooling only. Until M5 records a new review, the M4 implementation
is **not accepted** and is not gate-3 evidence either way. M5's build/hash replay is recorded in §8.1.

### 8.1 M5 build/hash replay — recorded, not a gate pass

**Scope:** M5 replayed the delivered handoff bundle, not the formal VM evidence
bundle. The formal VM bundle (items 3–6) remains `NOT VERIFIED`.

```text
bundle_zip:   dist/m5-routea-c4a159-2026-10-22.zip
bundle_zip_sha256:         957d73d4284a4e5ced27de451bacdfe8956751232bd4a1fa5aa6454dccdc108e
original:     aa42815704d9ffc65b3a49821b3cc6189126a738a7e02d668dec250982408393
candidate:    c4a1592157a2858fcf2dd52623b6ae8c280355ce735a1c224530845569bcaa82
contract file:15f6b492608e8c137f2612058bf43b90173284aec86d8c51b25d09903d0ad8df
contract canon:24bfe568e162be57de013abaeda96060d7edf4cad4b2eca0b003d929d9ec4e37
regen script: 56331eedb4d72c55eec4e0f105fb20207576e6e6860b79ca4cedb175ed54e843
sha256sums_file_sha256:   640b448228ea8e16d15930c5c81a1478a11a82a1feddb122f6262157a87788dd
```

Commands used:

```bash
unzip -q dist/m5-routea-c4a159-2026-10-22.zip -d /tmp/m5replay
cd /tmp/m5replay
python3 regen_c4a159.py original.elf replayed.elf
sha256sum replayed.elf
sha256sum -c SHA256SUMS
sha256sum SHA256SUMS
```

Result: `replayed.elf` is byte-identical to `candidate.elf`; all `SHA256SUMS`
entries `OK`; `contract_sha256()` reproduces `24bfe568…4e37`; candidate and
contract match the record. **M5 replay = PASS for the handoff bundle.**

This row does not fill the M4 verifier row and does not approve Gate 3. The formal
VM bundle and items 3–6 are still required before M4 signs.

## 9. Signature — BLANK (DRAFT)

**Signing order (handoff 19 §5):**

1. **M4 verifier row** — filled only after items 3–6 are independently verified as `PASS`
   (runtime cave probe, six cases, isolation evidence, bundle). M4's signature covers the
   verifier row; it is **not** an approval and **not** a gate pass.
2. **M5 build/hash replay row** — M5 records the observed replay values (candidate
   `c4a159…aa82`, contract `24bfe568…4e37`, recomputed bundle `SHA256SUMS`/bundle hash). A
   mismatch voids the record and returns it to `NOT VERIFIED`; it does not edit the candidate.
3. **Lead approval row** — filled last, after 1 and 2, as the gate decision.

| Role | Name | Date | Signature |
|---|---|---|---|
| M4 verifier | — | — | **blank until items 3–6 are PASS** |
| M5 build/hash replay | Member 5 | 2026-10-22 | REPLAYED — `c4a159…aa82` / `24bfe568…4e37` / `bundle_zip 957d… / SHA256SUMS 640b…; handoff bundle only |
| Lead approval | — | — | pending |

Do not fill these fields from a CI run, a static audit, or a verbal approval. A blank row is not
a silent pass: it keeps the record DRAFT and the gate `CONDITIONALLY FEASIBLE`.

