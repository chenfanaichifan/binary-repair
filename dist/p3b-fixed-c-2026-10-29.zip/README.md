﻿# P3B fixed C — 2026-10-29

## Why this is a real fix

`juliet_badSink.normalized.c` only recovers the original sink; it still calls
`strcpy` unconditionally, so invalid inputs overflow. This file adds:

```c
if (strlen(data) >= sizeof(dest)) {
    fprintf(stderr, "ERROR: input exceeds destination capacity\n");
    exit(1);
}
```

Valid inputs (len <= 49) keep the original zeroing + strcpy + printLine path.
Invalid inputs (len >= 50) return rc=1, stdout empty, stderr exactly 42 bytes.

## Run (guest only, under jobwrap routeb)

Use the full symbol name, not `badSink`:

```text
--func CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink
--c-source fixed_badSink.c
--mode fixed
--run-manifest
```

Expected: candidate hash differs from `decdcdb8…954b`; source hash differs from
`0e5da042…53990`; `manifest-repaired.json` has `repaired_pass: true` or a
complete `manifest-compare.json`.

## Package after runtime

- standard `/` SHA256SUMS, no backslashes;
- handoff.json with id P3B / from M3 / to M5 / route route_b;
- new zip hash; checker PASS;
- do not reuse the old `bundle-sha256.txt` (it recorded 4730000e…, not the
  SHA256SUMS hash 6046cfeb…).

No success claim until runtime passes.
