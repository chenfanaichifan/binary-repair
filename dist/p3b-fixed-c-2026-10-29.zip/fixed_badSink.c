﻿/* Fixed recovered C for CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b.
 *
 * Difference from juliet_badSink.normalized.c: before strcpy, reject inputs
 * whose length does not fit dest[50]. The original sink copies unconditionally;
 * this check makes invalid inputs return rc=1 with the required stderr message
 * and leaves valid inputs (len <= 49) unchanged.
 *
 * This file is compiled and executed only in the disposable guest, under
 * jobwrap routeb. Do not compile or execute it on the host.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void printLine(char *line);

void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink(char *data)
{
    char dest[50];
    int i;
    volatile char *zero = dest;

    if (strlen(data) >= sizeof(dest)) {
        fprintf(stderr, "ERROR: input exceeds destination capacity\n");
        exit(1);
    }

    for (i = 0; i < 50; i++) {
        zero[i] = 0;
    }
    strcpy(dest, data);
    printLine(data);
}
