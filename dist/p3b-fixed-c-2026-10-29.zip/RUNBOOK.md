﻿# P3B rerun runbook

1. Copy `fixed_badSink.c` into the guest job.
2. Run routeb executor under `jobwrap routeb` with:
   - c-source: `fixed_badSink.c`
   - func: `CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink`
   - mode: `fixed`
   - run-manifest: yes
3. Require:
   - candidate hash != `decdcdb821bfe4c41a070b0a23a2f6497f46a92f439cb02a1e4139a82cde954b`
   - c-source hash != `0e5da0423d68518933f0fb910e8732d58f73ca9cc8323b1dae7bc82694753990`
   - V3 `repaired_pass: true` or complete `manifest-compare.json`
4. Build handoff package:
   - handoff.json: id P3B, from M3, to M5, route route_b, files list
   - SHA256SUMS: slash paths, LC_ALL=C sorted
   - checker PASS
5. If V3 still fails, deliver as failed runtime, not static-only pass.
