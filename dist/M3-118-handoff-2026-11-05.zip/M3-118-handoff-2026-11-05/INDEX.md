# M3-118 handoff - 2026-11-05

Record 118 plus the evidence it cites, in one file, so the claim can be checked
without this branch.

Contents:

- `118-m3-t30-baseline-rebuild-2026-11-05.md` - the record.
- `evidence/t30-rebuild-2026-11-05/` - 11 files. `00` is the host-side window
  (snapshot uid 11, 0 `.lck`); `01`-`05` are the guest's own files; `06-SHA256SUMS`
  is the guest transport check over `01`-`05`; `07-rebuild.json` is the field-by-field
  conformance record; `README.md`, `SHA256SUMS`, `collect.sh` complete the set.
- `SHA256SUMS` - digest of every other file here (the record, the 11 evidence
  files, and this INDEX), with paths relative to this directory.

The record cites `docs/handoffs/evidence/T30`, which is in neither this bundle nor
the branch's tree: it lives at commit c274893 on `member-3/t62-host-safe`. The
byte-equality claim is checkable without it:

    git cat-file -p c274893:docs/handoffs/evidence/T30/build/original.elf | sha256sum
    # c9c2632e792c5acd0311cc3a5e4eb3fde538eb05d0de9c6601711e84b7b123c9
    git cat-file -s c274893:docs/handoffs/evidence/T30/build/original.elf
    # 25344

Not claimed: T8.3 relief, a repair candidate, or any V0-V5 gate.
