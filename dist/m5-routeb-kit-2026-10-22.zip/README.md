# M5 routeb kit — Gate 4

Target: Ubuntu 24.04 x86-64, JDK 21, Ghidra 12.2, Patcherex2 0.2.14.

```bash
sha256sum fixtures/public/CWE121_src_char_declare_cpy_51b/original.elf
# aa428157...8393
./routeb/ghidra/export.sh fixtures/.../original.elf \
  CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink routeb/out/gate4
python3 routeb/probe_patcherex2.py --mode roundtrip \
  --binary fixtures/.../original.elf \
  --func CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink \
  --c-source routeb/experiment/samples/juliet_badSink.normalized.c \
  --out routeb/out/gate4/roundtrip.elf --skip-verify
python3 routeb/run_manifest_compare.py --original fixtures/.../original.elf \
  --patched routeb/out/gate4/roundtrip.elf \
  --tests fixtures/.../tests --out routeb/out/gate4/manifest-compare.json
```

`verify.py` is the synthetic copy_name oracle; the Juliet manifest is compared by
`run_manifest_compare.py` (Gate 4) and `run_manifest_repaired.py` (fixed candidate).
