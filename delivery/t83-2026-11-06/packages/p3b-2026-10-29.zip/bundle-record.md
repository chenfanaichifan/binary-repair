# Route B/provider executor bundle

- mode: `fixed`
- function: `CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_51b_badSink`
- original: `aa42815704d9ffc65b3a49821b3cc6189126a738a7e02d668dec250982408393`
- candidate: `decdcdb821bfe4c41a070b0a23a2f6497f46a92f439cb02a1e4139a82cde954b`
- static audit: `pass`
- reproducibility: `measured`
- runtime manifest: `measured`

This bundle is static unless `runtime_manifest.state == measured`.
A static bundle is not a Gate 4 pass; run the six cases in the guest under
the isolation controls and attach the raw output.
