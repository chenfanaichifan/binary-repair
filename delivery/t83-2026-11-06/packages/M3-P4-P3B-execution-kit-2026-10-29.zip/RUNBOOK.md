﻿# P4 / P3B runbook (M3 -> M5)

## P4 Gate 4 (guest only)

1. Restore `gate4-harness` (v6 kit `499f510c…`, runner `515c4d60…`).
2. Run `jobwrap gate4 <job>`.
3. Collect: `gate4-status.json`, case-01..06.json (command/rc/stdout/stderr/hash),
   candidate.elf/original.elf SHA-256, `environment.txt`, `isolation.json`,
   `revert.log`, `harness-v2-manifest.txt`, `harness-manifest.json`.
4. Copy `templates/handoff-P4.json` -> `handoff.json`, fill created_at/files.
5. Generate `SHA256SUMS` sorted by path; run:
   `python check_handoff.py <pkg> --expect-from M3 --expect-to M5`
   until PASS.

## P3B Route B (guest only, isolated)

1. Merge `jobwrap routeb` (decision B); do not use lab/direct execution for evidence.
2. Run routeb executor under `jobwrap routeb` with fixed config.
3. Collect: candidate.elf, edit-manifest.json, manifest-compare.json (real runtime),
   executor log.
4. Copy `templates/handoff-P3B.json`; fill; generate SHA256SUMS; checker PASS.
5. If runtime was not run: V3 = not_run, no static-only pass.

## Checker

`python check_handoff.py --self-test` must print PASS in the user's environment.
`python check_handoff.py <pkg> --expect-from M3 --expect-to M5` must PASS.

## Boundary

These are execution kits, not evidence. Do not submit until the guest produces
the raw outputs and checker passes.
