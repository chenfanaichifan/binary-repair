# M3-124 handoff — the CWE416 no-input candidate, with the evidence that scores it

Record 124. This package is the answer to "the blocker is a candidate": one
exists, and everything needed to score it is inside.

- Candidate: `evidence/cwe416-candidate-2026-11-05/candidate.elf`
  — sha256 `46d16e997bdfbb87fbd9c1d6f09443a7907b11b2b37118f5c773087a0d91fcd0`,
  25,344 bytes.
- Original: `fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput/original.elf`
  — sha256 `c9c2632e792c5acd0311cc3a5e4eb3fde538eb05d0de9c6601711e84b7b123c9`,
  same size.
- Contract: the fixture's `contract.json`, unchanged — `schema_version: 3`,
  `input_mode: "none"`, file sha256 `8a2b408c…e3c3b`, canonical sha256
  `c1684f15…b4f7c`. This package does not modify it.

## The edit

Five bytes at file offset 4869 (`0x1305`, vaddr `0x401305`):

```
e8 e6 fd ff ff   call 4010f0 <free@plt>   ->   90 90 90 90 90
```

That is `contract.json#authorized_edits[0]` — "drop the `free()` and accept the
leak". No C replacement, no code cave, no added byte, size delta 0. The second
authorised option (move the read ahead of `free()`) needs inserted instructions,
so it changes more bytes for the same behaviour.

## What it scores

```
input_mode: none   invalid: not_applicable   valid: 1/1
passed: 1   total: 1   repaired_pass: true   (runner exit 0)
```

On the unrepaired original, same runner, same `valid.json`:

```
valid: 0/1   passed: 0   total: 1   repaired_pass: false   (runner exit 1)
```

| Gate | Result | File |
|---|---|---|
| V0 identity | passed | `v0-identity.json` |
| V1 structure | passed | `audit.json` |
| V2 interface | `not_run`, `scored: false` | `v2-interface.json` |
| V3 behaviour | passed, 1/1 | `manifest-repaired.json` |
| V4 symbolic | `not_run`, `claimed_scope: null` | `v4-symbolic.json` |
| V5 reproducibility | passed | `reproducibility.json` |

`gate-index.json` is the index over those six files.

## Re-running it, without trusting any number above

```sh
cd evidence/cwe416-candidate-2026-11-05 && sha256sum -c SHA256SUMS && cd -
FIX=fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput
python3 routeb/run_manifest_repaired.py \
    --binary evidence/cwe416-candidate-2026-11-05/candidate.elf \
    --tests "$FIX/tests" --contract "$FIX/contract.json" --out /tmp/v3.json
```

The runner resolves `input_mode` through `SecurityContract.from_dict`, so `none`
comes from the contract, not from a JSON read. Pointing `--binary` at the
fixture's `original.elf` flips the same case to `0/1`.

## Contents

- `122-m3-cwe416-candidate-2026-11-05.md` — how the candidate was made and scored.
- `123-m3-cwe416-contract-sync-2026-11-05.md` — proof the tree contract is the
  one being read, and that the two hashes above are the tree's.
- `evidence/cwe416-candidate-2026-11-05/` — 31 files: candidate, original,
  `edit-manifest.json`, `audit.json`, the two V3 manifests, `v0-identity.json`,
  `v2-interface.json`, `v4-symbolic.json`, `reproducibility.json`, the run log,
  repeat runs, independent readelf/objdump views, the five scripts that produced
  them, and its own `SHA256SUMS`.
- `evidence/cwe416-contract-sync-2026-11-05/` — 12 files: contract identity, the
  per-file comparison against the 120 snapshot, the inventory of every reachable
  CWE416 contract, and a fresh V3/V5 run from the tree fixture.
- `fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput/` — 14 files, the
  tree state, with `tests/SHA256SUMS` covering the other 13. **Read this one, not
  the copy inside the 120 package**: that copy is the `0936ac6` snapshot, and
  `defect.json` has moved since (its `trigger_note` now opens with
  `not_applicable: input_mode is none …`).

## Check it in place

```sh
sha256sum -c SHA256SUMS                       # every other file in this package
(cd evidence/cwe416-candidate-2026-11-05 && sha256sum -c SHA256SUMS)
(cd evidence/cwe416-contract-sync-2026-11-05 && sha256sum -c SHA256SUMS)
(cd fixture/CWE416_Use_After_Free__malloc_free_char_01_noinput && sha256sum -c tests/SHA256SUMS)
```

## What this does not claim

- **No gate verdict.** `contract.json#required_obligations` still lists
  `symbolic`, so an attempt assembled from this bundle is
  `REQUIRED_CHECK_NOT_RUN` → `inconclusive`, not `pass`. `repaired_pass: true`
  is the runner's own judgement over one case, not a gate decision.
- **V4 is `not_run`.** No symbolic or bounded-model engine was used for this
  candidate; `claimed_scope` is `null`. A replay result is `replay` scope and
  cannot be relabelled binary-level.
- **V2 is an observation, not a score.** Route B has no interface check; the file
  says `scored: false`.
- **T8.3 stays blocked.** One sample, one repair, one observation. No second
  defect class is described here and none is implied by `1/1`.
- **This is not `unsupported`.** The candidate was produced, and the nine numbers
  above were measured on the guest; if a future sample cannot be repaired, the
  record will say `unsupported` rather than borrow this result.
