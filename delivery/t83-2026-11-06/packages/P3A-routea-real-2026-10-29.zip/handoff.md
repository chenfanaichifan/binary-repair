﻿# P3A — Route A real executor bundle (M3 → M5)

- Producer: M3 (guest evidence)
- Consumer: M5 (adapter/replay)
- Route: route_a
- Candidate: c4a1592157a2858fcf2dd52623b6ae8c280355ce735a1c224530845569bcaa82
- Original: aa42815704d9ffc65b3a49821b3cc6189126a738a7e02d668dec250982408393
- G3 evidence source: gate3-bundle-v3-2026-10-22.zip (1d0e5441…4271f)
- Gates: V0 passed, V1 passed, V2 not_run, V3 passed, V4 not_run, V5 not_run
- Worker shape: attempt.json (produced by tools/routea_bundle_to_attempt.py)
- check_handoff.py: NOT RUN — tool not present in this checkout/public branches
- Caveat: VMer evidence; M4 verifier and M5 replay pending; V3 passed is six-case
  behaviour on the reverted snapshot, not a signed Gate 3 decision.
