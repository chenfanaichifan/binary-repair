# Evidence status — M3 isolation bundle (2026-10-22)

Purpose: make it explicit which items are raw evidence in this bundle and which
are still pending, so the bundle cannot be read as "everything delivered".

## Present

| Item | File | Note |
|---|---|---|
| Image chain + post-revert fingerprint | `isolation-manifest.txt` | hashes, snapshot tree, 7 restore checks |
| Toolchain versions / interpreter split | `state-change-2026-10-22.md` | versions and `/opt/angr-venv` |
| VM profile / snapshot history | `vm-profile.md` | context, not raw command output |
| Host/guest baseline | `environment-baseline.md` | measured host/guest values |
| Freeze scope (input freeze) | `fixture-freeze-record.md` | gates 3–5 still pending |
| Corrected contract (from main 666a5dc) | `contract-main.json` | entry 1 = 0x401309; canonical `1a0ad101…` |
| Fixture integrity (local) | `fixture-SHA256SUMS.txt` | **local worktree only**; origin/main does not have it yet |

## Missing — owner VMer, must be appended before M4 accepts

1. `/opt/angr-venv/bin/pip freeze` raw output (55 packages);
2. `java -version`, Ghidra `analyzeHeadless` version, `python -c "import ..."` raw stdout;
3. `df -h /` raw output;
4. V4 bounded-explore raw stdout (result `inconclusive`);
5. per-case jobwrap logs for the six cases (valid-empty/smallest/typical/maximum,
   invalid-first/longer), with uid/CapEff/NoNewPrivs/netns/exit captured;
6. proof (or explicit absence) of a `pre-reset-test` protection snapshot before revert;
7. SSH key SHA-256 fingerprints and access windows for M4/M5 (`guest-access-2026-10-22.md`
   has `<待填>` placeholders).

## Retraction

The earlier statement "SHA256SUMS 24/24 on origin" is withdrawn. The 24/24 check
was run on the local worktree. `origin/main` does not contain the fixture; M1 must
push/merge before any origin-based canonical claim is made.
