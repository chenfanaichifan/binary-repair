# 回复 M4：M3 guest / 隔离 / fixture 清单（2026-10-22）

> 内部回复稿。随附文件见 `dist/m3-isolation-evidence-2026-10-22.zip`。
> 原则：有原始输出的才写“已交”；没有的写“待 VMer 补”，不拿摘要冒充原始证据。

## 1. 安装证据

已附：

- `state-change-2026-10-22.md` §1：JDK 21.0.12.1、Ghidra 12.1.4、Patcherex2 0.2.14、
  angr 10.0.4.post1、z3 5.1.0、LIEF 1.0.0、clang 18.1.3；解释器为 `/opt/angr-venv`；
- Ghidra `analyzeHeadless` 完成一次 import/analysis 的记录（state-change §1）；
- angr 加载 `original.elf`（AMD64，entry 0x401170）的记录；
- 镜像链 + 还原后指纹：`isolation-manifest.txt`。

仍缺，需 VMer 补原始输出：

- `/opt/angr-venv/bin/pip freeze` 的 55 包原文（工作区的 `vm-pip-freeze.txt` 是
  10-20 的 system python，不是 venv 证据，不能替代）；
- `java -version`、`analyzeHeadless` 版本、`python -c "import ..."` 的完整 stdout；
- `df -h /` 原文；
- V4 bounded explore 的原始输出（结论是 `inconclusive`，不是 pass）。

## 2. snapshot revert

已完成，见 `isolation-manifest.txt` §Post-revert：

- `isolation-ready` uid 8，关机拍摄；
- revert 后 hostname/uptime、jobwrap hash、probe.sh hash、original.elf hash 全部对上；
- jobwrap probe：uid=1003、CapEff=0、NoNewPrivs=1、lo DOWN、evaluator 不可读、egress blocked；
- 1003 调 wrapper：Permission denied；
- `disk-000005`（还原前写入层）被丢弃。

**未记录**：是否先拍了 `pre-reset-test` 保护快照。`isolation-manifest` 的 snapshot tree
只有 uid 4–8，没有 `pre-reset-test`；这一项按“未证明”处理，不补写。

## 3. jobwrap

当前 `/usr/local/sbin/jobwrap`：`2427c62c…413a`，943 B，`0700 root:root`。
它已经能做到：root 拉起、netns、setuid 1003、无出口、evaluator 不可读、1003 不能调用。

**但还没满足你要求的“固定校验过的 execv 参数”**：

- 仍是 shell wrapper，接受 `"$@"`；
- 没有固定 case 表、没有 hash 校验、没有 env 清理、没有 caps/rlimits/per-case 日志；
- 目前只覆盖两个 smoke 输入（`A` / 100×A）。

计划：改成只接受六个 case id（valid-empty/smallest/typical/maximum、invalid-first/longer），
argv 从 root-owned 表读取，目标候选 hash 固定，netns→setgid/setuid→no_new_privs→
清 caps→rlimit→清环境→execv；每 case 写 root-owned 日志。完成前不写“jobwrap 验收通过”。

## 4. Guest 访问

建议方式（密钥线下交付，不进 repo；记录见 `guest-access-2026-10-22.md`）：

- **M4**：主 VM `lab` 账号的审计 key，用于版本/哈希/快照核验；访问窗口与会话日志登记；
- **M5**：不要给主 VM 写权限；从 `isolation-ready` 克隆一台一次性 VM，给 `lab` 的
  Gate 4 key，只在该克隆里跑 kit；主 VM 快照不动。

记录字段：用户、key SHA-256 指纹、IP/端口、快照 uid、起止时间、允许动作、撤销方式。
如果你要求 M5 直接在主 VM 跑，需要你先确认这会破坏哪条隔离边界，并书面接受。

## 5. original.elf canonical 来源

- 本地分支 `member-3-route-a` 的 `d1e0741` 含 `original.elf` blob，26,792 B，
  SHA-256 `aa428157…8393`；
- **origin/main 没有 fixture**（你已核实），所以 origin 目前不是 canonical 来源；
- 在 M1 push/merge 之前，不能写“origin 可验证”。

**撤回**：“SHA256SUMS 24/24 在 origin 上可核验”这一说法不成立。准确表述是：
本地工作区 24/24 通过；origin 上尚无该文件。等 M1 推送后再改为 origin 证据。

## 6. fixture 冻结

只等 gates 3–5 证据；不动 oracle、不改 `DEST_CAPACITY`/`ERROR_STDERR`/manifest。
Gate 3 正式结论仍等正式 VM 的 6/6 + isolation 证据；Gate 4 仍 NOT RUN。

## 7. 待补清单（按 owner）

| 项 | Owner | 状态 |
|---|---|---|
| venv pip freeze / java / analyzeHeadless / import / df 原始输出 | VMer | 待补 |
| jobwrap 六 case 固定枚举 + 每 case 日志 | VMer/M3 | 进行中 |
| `pre-reset-test` 是否拍过 | VMer | 未证明 |
| 新 contract canonical `1a0ad101…` 的 scope 签字 | M4 | 待签 |
| c4a159 在正式 VM 的 6/6 | VMer/M3 | 待跑 |
| Gate 4 v5 kit 正式运行 | VMer/M3 | 待跑 |
| origin canonical（push/merge） | M1 | 待处理 |
