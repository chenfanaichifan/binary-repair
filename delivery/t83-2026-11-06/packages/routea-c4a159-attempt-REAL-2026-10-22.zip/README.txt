﻿# Route A per-attempt JSON — REAL VM evidence (VMer bundle v2)

Source: `D:\BinRepair\dist\gate3-bundle-v2-2026-10-22.zip`
SHA-256: `8256c8501afd95c02b371a99a507c436e5e431f49bdc5e4641b9a3bab2cbe64f`

This is the per-attempt JSON for M1's `attempt_writer` (schema v2):
- V0 passed (original/contract/manifest hashes match)
- V1 passed (structural audit; expected PT_LOAD[1] 0x8e9→0x1000)
- V2 not_run
- V3 passed (six cases 6/6 from gate3-harness-v2 uid 10; original V0 4/6)
- V4 not_run
- V5 not_run

Caveat: this is VMer's evidence bundle; M4 verifier and M5 formal-bundle replay
are still pending. It is not a signed Gate 3 decision.

Runtime output paths (M1):
  <data>/jobs/<job>/runs/<run>/route_a/result-bundle.json
  <data>/jobs/<job>/runs/<run>/attempts/<attempt>.json
Do not commit these runtime artifacts.
