# To M5 — P3B v3 success, P4 package, P3A v4

## P3B v3

The successful jobwrap log is now in the package; the fixed C is inside; stale
metadata was corrected.

```text
P3B-package-v3-2026-10-29.zip
33,593 B
SHA-256 72d789c665fa2e7796b092b3c351a488472a68269549a5e709168dcf1020034b
checker PASS: id P3B / 18 files / sums 8bec86e0…
candidate 63fcafa6…16d01
c-source a2e4ff8f…c90e
jobwrap exit_code=0, uid=1003, cap_eff=0, NNP=1, netns=empty
audit_profile=route_b_recompile, audit.pass=true, same_file_size=false,
size_change_recorded=true
executor_sha256=87fee2b7…1d91
V3 6/6, repaired_pass=true
```

`f46a3c8a…` is superseded; its jobwrap log was the old c9609f32/exit1 run.
`bundle-sha256.txt` was removed because it carried a stale self-hash; the
authoritative checksum is `SHA256SUMS` (sums 8bec86e0…).

## P4

`P4-package-2026-10-29.zip` (427dd71d3b94…d4, checker PASS, 15 files):
native evidence is `manifest-compare.json`; case-01..06 are derived and marked
`runner_native=false`. Missing only runner-native six-case raw; M4 decides
whether manifest-compare is acceptable native evidence.

## P3A

`P3A-routea-2026-10-29-v4.zip` (347e7d22…fa15), checker 25/25, sums d9c33b42….
