# To M5 — 2026-10-31 v12: V4 raw replay package (Standard B)

This bundle supersedes v11. v11 shipped the V4 evidence; v12 additionally ships
the **raw replay package** the Lead's Standard B ruling
(`docs/handoffs/62-lead-v4-acceptance-standard.md`) requires for independent
verification: `v4/REPLAY-README.md`, `v4_accounting.py`, `v4-accounting.json`,
`v4-accounting.log`.

**Nothing here claims V4 is `passed`.** Standard B is explicit: a self-verified
single-agent result is NOT sufficient; V4 stays `not_run`/`NOT VERIFIED` until an
independent role replays the raw evidence and the Lead approves. M3 publishes the
raw material only.

## Honest finding surfaced by the raw accounting (read `REPLAY-README.md`)

The supplementary instrumentation (`v4_accounting.py`) shows the solver performed
**0 satisfiability queries and 1 `eval` across every run**. The valid domain is fed
as **concrete worst-case bytes** (49 'A' + NUL), not a symbolic input domain. So
the V4 `proven` verdict is a **concrete worst-case execution**, not a symbolic
proof over all legal inputs. M3 does not over-claim this; it is recorded plainly
in `REPLAY-README.md` §3.1 and §6.

## Packages

- P2-real-2026-10-31.zip (62,790 B, checker PASS 42/42) — carries the V4 raw
  replay package.
- P3A v7 / P3B v6 / P4 v3 unchanged from v11.

## Status (unchanged, Standard B)

```text
V4: NOT VERIFIED (self-verified only; independent replay required)
Gate 4 formal: NOT RUN (separate criteria, not V4-gated)
Gate 5: BLOCKED (jobwrap gate5 + GATE5_SCRIPT_SHA256)
MVP: NOT COMPLETE
```

No gate4_pass, no merge, no tag.
