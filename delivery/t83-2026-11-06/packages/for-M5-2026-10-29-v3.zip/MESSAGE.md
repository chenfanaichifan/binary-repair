# To M5 — P3A v4 is final; P3B f46a; Gate 4 inputs

## P3A v4 — final, do not use v5/v6

Lead correction: v4 is the final package; it already passed the canonical
INTERFACE-v1 checker (25 artifacts / 25 sums, sums d9c33b42…). The v5/v6
repackages and `P3A-v1-draft.zip` are void.

```text
P3A-routea-2026-10-29-v4.zip
35,573 B
SHA-256 347e7d22cc741e2da539e756761afa28d09c739751a33ca5b9a6b22d2b6efa15
checker PASS: id P3A / files 25 / sums 25 / sums d9c33b42…e0bcb
candidate/evidence bytes unchanged
```

## P3B — use f46a, not the old failed source

The old `c9609f32…` source failed to link (`exit`, `strlen`); the passing run
uses `a2e4ff8f…`:

```text
P3B-package-2026-10-29.zip
31,589 B
SHA-256 f46a3c8ac3c5cfbea646ea5b08e2fb03ce12ec535fcb6fd1d966ecdcf182f639
checker PASS: id P3B / 15 files / sums 9fec168f…
candidate 63fcafa6…16d01; c-source a2e4ff8f…c90e; V3 6/6 repaired_pass=true
```

`edit-manifest.audit.pass=false` (size 26792→29512) is M5’s acceptance call.
Do not rerun with `c9609f32…`.

## Gate 4

Inputs: v6 kit 499f510c…, runner 515c4d60….
Invocation (M3/VMer side):

jobwrap gate4 -- <repo>/routeb/gate4_runner.sh <repo> /var/tmp/gate4-work

`gate4-2026-10-29.zip` (9aa86320…) is evidence, not a formal gate4_pass; the
formal run/record is still pending.

## Gate 5

Still blocked: M4 script + jobwrap fixed-script mode. `Gate5A-blocked-2026-10-29.zip`
(74952fc4…) documents it; no PASS/FAIL.
