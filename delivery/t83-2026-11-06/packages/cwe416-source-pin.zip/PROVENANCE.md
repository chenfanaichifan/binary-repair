# CWE-416 source pin — provenance

**Repo:** https://github.com/dsp-testing/samate-c-cpp
**Full commit SHA:** `01e353daa3d28a4ce2ae68904cbcde5e03e3519d`
**Source path:** `C/testcases/CWE416_Use_After_Free/CWE416_Use_After_Free__malloc_free_char_01.c`
**Source SHA-256:** `fa84a6bb9df36a8a1ab4d33a7064746d9037247f7599d3cd39659478d4b7f42e`
**Size:** 3,198 bytes
**Raw URL:** https://raw.githubusercontent.com/dsp-testing/samate-c-cpp/01e353daa3d28a4ce2ae68904cbcde5e03e3519d/C/testcases/CWE416_Use_After_Free/CWE416_Use_After_Free__malloc_free_char_01.c

Verified by M4: bytes at the pinned commit/path hash to the stated SHA-256; the source is a
use-after-free shape (`malloc` -> `free` -> `printLine(data)`).

**Rejected mix:** `arichardson/juliet-test-suite-c` commit
`f88433e3443648a17671398797a04ea1f8e1a274` is a different repository; it is not part of this
pin. A separate four-tuple is required if that repo is ever used.

**License:** NIST Juliet Test Suite for C/C++ version 1.3 is public domain (not subject to
copyright protection in the United States). Pursuant to 17 USC 105, foreign rights that NIST may
claim are made available under CC0 1.0 Public Domain License. Keep this provenance with the fixture.
