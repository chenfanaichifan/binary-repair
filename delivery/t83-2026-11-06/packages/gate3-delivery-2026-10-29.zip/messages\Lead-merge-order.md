# To Lead — merge order and delivery gate

## Current state (2026-10-29)

- Gate 3 record: `docs/route-a/gate3-record.md`, DRAFT, SHA-256
  `bddccbfe…a9e081` (M4 version). Items 1–2 PASS, 3–6 NOT VERIFIED.
- Formal evidence: `gate3-bundle-v3-2026-10-22.zip`, SHA-256
  `1d0e5441…4271f`, 26 files, `SHA256SUMS` 25/25.
- M5 formal v3 replay: **not yet recorded**.
- M4 verifier signature: **blank**.
- Lead approval: **blank**.
- Gate 4: **NOT RUN** — v6 kit ready, no formal gate4-harness run.
- Push: `member-3-route-a` ahead 9; `SEC_E_NO_CREDENTIALS` still blocks.

## Merge order (do not reorder)

1. **M5 replay first**: §8.2 formal v3 actual values merged into M4’s record
   branch; §8.1 handoff replay preserved.
2. **M4 verification second**: items 3–6 PASS and verifier row filled; record
   hash updated and reported.
3. **Lead approval third**: approval row filled only after 1 and 2.
4. **M3 code fourth**: `workers/route_a/*`, converter, tests; code only, no
   runtime per-attempt JSON.
5. **Gate 4 separately**: evidence goes in its own record/branch; a `NOT RUN`
   is acceptable only if written as such, never as pass.
6. **Freeze record last**: four signatures; fixture freeze key remains the
   input hashes, not a gate result.

## Blockers

- M5 formal replay missing.
- M4 verifier signature missing.
- Gate 4 formal run missing (`NOT RUN`).
- Push credentials missing; merge cannot be claimed until pushed.

Do not fill Lead approval from CI 6/6, static audit, or chat approval.
