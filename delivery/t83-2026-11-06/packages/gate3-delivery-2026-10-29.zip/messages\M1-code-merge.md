# To M1 — Route A worker/converter code merge

## Package

`m3-routea-converter-2026-10-22.zip`

- 13,081 B
- SHA-256 `9f76f6b79adf67980b140ac17f4e7d95a1039f4c6af8b5147ad3822146cee8bb`

Contents:

```text
workers/route_a/attempt_from_bundle.py   result-bundle -> attempt_writer v2
workers/route_a/result_bundle.py         V0-V5 collector
workers/route_a/worker.py                deterministic fixture worker
workers/route_a/README.md
workers/route_a/JOBWRAP_ROUTEA.md
tests/unit/test_attempt_from_bundle.py   2 tests, pass
examples/routea-c4a159-attempt-DRYRUN.json
README-M1.md
```

## Request

- Review and merge on the M3 branch; open PR to `main`.
- Runtime artifacts (`result-bundle.json`, per-attempt JSON) are **not**
  committed.
- `attempt_from_bundle.py` maps:
  `pass→passed`, `fail→failed`, `not_run→not_run`,
  `inconclusive/unsupported→unknown`.
- `evidence_files` only for V1–V5 `passed`; V0 never gets evidence.
- The `examples/…DRYRUN.json` is a schema example, not gate evidence.

Push is blocked here by `SEC_E_NO_CREDENTIALS`; the zip is the code handoff.
