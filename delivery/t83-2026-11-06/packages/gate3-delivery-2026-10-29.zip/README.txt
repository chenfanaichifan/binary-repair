﻿# Gate 3 delivery pack — 2026-10-29

- `gate3-bundle-v3-2026-10-22.zip` — formal v3 evidence (35,887 B,
  SHA-256 1d0e5441…4271f); give to M5 for §8.2 replay and M4 for verification.
- `m3-routea-converter-2026-10-22.zip` — Route A worker/collector/converter code
  for M1 review; 13,081 B, SHA-256 9f76f6b7…e8bb.
- `messages/` — ready-to-forward texts for M5, M4, Lead, M1.

Gate 3 remains CONDITIONALLY FEASIBLE until M5 formal v3 replay + M4 verifier
signature + Lead approval. Gate 4 remains NOT RUN.
