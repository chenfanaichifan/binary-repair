# To M5 — formal v3 bundle replay

The self-contained v3 bundle is ready. Please run the **formal v3 build/hash
replay** (not the handoff replay).

## Input

`gate3-bundle-v3-2026-10-22.zip`

- 35,887 B
- SHA-256 `1d0e5441925de0fc3cc814d8c36d6443d8c1a65b87e05a4d6d008beaac44271f`
- 26 files; `SHA256SUMS` 25/25
- Contains the v2 raw evidence plus `candidate.elf`, `original.elf`,
  `regen_c4a159.py`

## Commands

```bash
unzip -q gate3-bundle-v3-2026-10-22.zip -d /tmp/g3v3
cd /tmp/g3v3
sha256sum -c SHA256SUMS
sha256sum SHA256SUMS
python3 regen_c4a159.py original.elf replayed.elf
sha256sum replayed.elf
cmp candidate.elf replayed.elf
```

## Report

| Item | Expected / actual |
|---|---|
| v3 zip SHA-256 | `1d0e5441…4271f` |
| `SHA256SUMS` file SHA-256 | report actual |
| `sha256sum -c` | __/25 OK |
| candidate | `c4a1592157a2858fcf2dd52623b6ae8c280355ce735a1c224530845569bcaa82` |
| regen/replayed | must equal candidate |
| contract canonical | `24bfe568e162be57de013abaeda96060d7edf4cad4b2eca0b003d929d9ec4e37` |
| contract file | `15f6b492608e8c137f2612058bf43b90173284aec86d8c51b25d09903d0ad8df` |

## Record

- Keep §8.1 handoff replay.
- Add/replace §8.2 with the **formal v3** actual values.
- M5 row: formal v3 bundle only.
- Do **not** fill M4 verifier or Lead approval rows.
- Mismatch or missing input: record `NOT VERIFIED`, do not edit candidate.
