# To M4 — verify v3 evidence and close items 3–6

## Input

`gate3-bundle-v3-2026-10-22.zip`

- 35,887 B
- SHA-256 `1d0e5441925de0fc3cc814d8c36d6443d8c1a65b87e05a4d6d008beaac44271f`
- 26 files; `SHA256SUMS` 25/25
- Adds `candidate.elf`, `original.elf`, `regen_c4a159.py` to the v2 evidence

## G1–G4 status in v3

- **G1** — LIEF `PT_LOAD[1]` flags `"R E"`, align `0x1000`; imports real names;
  `interp=/lib64/ld-linux-x86-64.so.2`; only expected difference
  `p_filesz/memsz 0x8e9→0x1000`.
- **G2** — `harness-v2-manifest.txt` (`e53253cf…`) and `harness-manifest.json`
  (`3bdbc339…`) included; `SHA256SUMS` 25/25; new bundle hash.
- **G3** — `gate3-summary` remapped to handoff 11 §3 six items.
- **G4** — `revert.log` operator = VMer (same human as M3, another AI window),
  manual VMware Snapshot Manager action + post-hoc observation.

## Verification request

1. Independently verify the six items and the two manifest hashes.
2. If items 3–6 are satisfied, update the record and fill the M4 verifier row.
3. Keep the Lead approval row blank.
4. Do not merge before M5’s formal v3 replay (§8.2) is recorded.
5. Report the updated record hash.

Gate 3 remains `CONDITIONALLY FEASIBLE` until M4 verifier + M5 replay + Lead
approval are all present.
