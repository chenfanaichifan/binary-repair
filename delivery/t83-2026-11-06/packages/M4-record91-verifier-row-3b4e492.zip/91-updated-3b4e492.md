# 91 — M5 completion status (2026-11-05)

**Branch:** `member-5/complete-m5`
**Base:** `origin/post-final/host-importer-broker` @ `1da22ff`
**Status:** M5 implementation for records 87 / Improve.md; not merged, no tag.

## Completed

| Task | Deliverable | Evidence |
|---|---|---|
| T6.1 ingest adapter | `tools/route_bundle_ingest.py`: manifest/schema validation, path traversal/symlink/size/hash checks, artifact registration, gate→artifact map | `tests/integration/test_route_bundle_ingest.py` |
| T6.1 hardening | `tools/host_importer.py` result/status/evidence validation; `tools/host_broker.py` `bundle_path` containment/symlink rejection | `tests/integration/test_host_broker.py` |
| T6.5 conformance | reject-list tests: unknown gate/status, traversal, symlink, missing passed evidence, idempotency | ingest tests |
| T7.2 analysis/comparison | `analysis` roles + `behavior-comparison.json` registration and ids in result details | `test_ingest_registers_analysis_and_comparison` |
| T8.1 assistant seam | `app/domain/assistant.py` schema + deterministic planner; `004_assistant.sql`; `app/services/assistant.py` persistence | `tests/integration/test_assistant_plan.py` |
| T8.2 LLM planner | **handed to M2**; M5 keeps seam + fallback in `app/services/assistant.py`, implementation in `app/services/assistant_llm.py` | `docs/handoffs/92-t82-handoff-m2-2026-11-05.md` |
| M5 #14 analysis roles | `app/domain/analysis.py`; `docs/interfaces/artifact-roles-v1.md`; ingest validates expected_effects/assumptions/uncertainties | ingest/analysis tests |
| M5 #15 model_calls | `app/services/model_calls.py`; assistant calls persisted; provider-result helper; aggregate returns token counts or null | assistant usage test |
| Legacy result hash | `result-bundle.json` must be listed in handoff.json + SHA256SUMS before it is read | `test_legacy_result_bundle_must_be_in_sums` |
| Envelope hash/size | tampered bytes and size mismatches rejected | `test_evidence_hash_and_size_are_rehashed` |
| F2/F3 V3 regression | manifest-compare never maps to repair V3 | `test_manifest_compare_is_not_repair_v3` |
| Evidence envelope | `app/domain/evidence.py`; passed artifacts rehashed, size/path/attempt binding checked before obligation persistence | `tests/integration/test_evidence_envelope.py` |
| Route B V3 honesty | round-trip `manifest-compare.json` no longer maps to repair V3; only `manifest-repaired.json` does; shared `runtime_state()` used by both writers | writer tests |
| P0.2 strict Route B comparison | `routeb/run_manifest_compare.py`: rejects empty/timeout cases and requires original to exhibit pre-repair invalid behaviour; matching crashes cannot pass | `tests/test_run_manifest_compare.py` |
| Protocol docs | `docs/interfaces/execution-bridge-v1.md`, `docs/host-importer-broker.md` | docs |

## Test status

```text
M5 host: pytest --ignore=tests/e2e -q -> exit 0
M4 host: not reproducible (exit 2, missing environment deps)
M4 report: `_scratch/m5-verify-15fed2d/M4-VERIFIER-REPORT.md`; M5 does not claim M4 PASS.
M4 f326537 report: symlink skip, exit-0 wording, candidate binding independently reproduced;
273 passed / 4 skipped (new head 277/4) after **excluding five environment-dependent
modules**, not after installing capstone/pyelftools. This is not merge/tag/live success.

Review items 9/10/11/12 are explicitly **not** part of this M5 PASS:
9/10 missing incomplete_test_set/timeout_observed; 11 is error/tool_failed, not reject/evidence_hash_mismatch; 12 lacks scope/bounded. They remain separate work.
```

This is a host-dependent result, not a universal claim. M4's environment gaps
are authoritative; the symlink rejection test skips when the host cannot create
symlinks. M4 remains independent verifier and must not sign a full pass from
M5's local run alone.

## Not completed / blocked

```text
T8.3 generic repair plan
  blocked on: second public sample of a different defect class + T7.3 comparison;
  M5 must not fabricate a second class.
```

Controller/UI endpoint bodies for T8.1 remain M1/M2; M5 supplies schema + persistence only.

## Boundaries

No verdict/approval is written by the assistant. Synthetic evidence without
bytes/hash binding is rejected. No main merge, no tag.

## P3B bridge package record (2026-11-05)

The **branch-available** package is the fixed ZIP from commit `14f5322`:

```text
P3B-execution-bridge-2026-11-05-fixed.zip
SHA-256 357207ae15a275dbb7196fc305854ad0e806ebe1dfcb882938fbdfaf61134da7
internal SHA256SUMS: 11/11
```

This is the only package SHA that can be fetched from the branch and re-hashed
by M4. The later M3 corrected ZIP (`e1cbaeb...`, 13/13) is not tracked in this
branch; this record does **not** claim 13/13 as branch-verifiable evidence.

Ingest behaviour for the branch-available ZIP is still: V0/V1/V2/V3/V5 have
bound artifacts, V4 is `not_run`, worker is
`inconclusive / required_check_not_run`. `result-bundle.json` is registered as
`legacy_result_bundle` and is hash-bound. No merge/tag/live success.

## INTERFACE-v1 without result-bundle

A legacy `handoff.json + SHA256SUMS` package without `result-bundle.json` is
accepted structurally but every gate is `not_run`; notes such as "V2 16/16" or
"V3 6/6" are not per-gate hash evidence and are not promoted to passed. To get
passed, the package must ship `result-bundle.json`, list it in `handoff.json`
and `SHA256SUMS`, and name per-gate evidence.

For V0 with multiple artifact names, ingest now selects the artifact whose bytes
match `candidate_sha256`, not the first list entry.

## M4 verifier row (2026-11-05, head 3b4e492)

**Verifier:** M4. **Same-person limitation:** the M4 verifier and the Lead are
the same operator; this is role-separated verification, not an independent
two-person signature. **Scope:** host-side evidence only; no guest execution,
no merge/tag/live success.

**Head reviewed:** `3b4e492a4f48` (branch `member-5/complete-m5`), archive
SHA-256 `22f98368ff91f511505b5ba2b748a10b6f003376762a94befde4c3e7980ac06c`.
**Patch base:** this file at `3b4e492` (pre-row SHA-256
`fdb31b5425025e243633200705320a68d47cef265a72c7fe3f73bc81f3ae1ac8`); the
older `c15a3aff`-based patch is superseded.

| Item | Result |
|---|---|
| Record 91 corrected P3B entry | **PASS (with note).** The record states the branch-available package is `P3B-execution-bridge-2026-11-05-fixed.zip`, SHA-256 `357207ae15a275dbb7196fc305854ad0e806ebe1dfcb882938fbdfaf61134da7`, internal SHA256SUMS **11/11**, and explicitly says the M3 `e1cbaeb…`/13/13 original is not tracked or claimed as branch-verifiable. `13/13` remains only in that negative disclaimer, not as a claim. |
| Legacy ingest result-bundle role | **PASS.** Independent legacy-shape control registers `result-bundle.json` with role `legacy_result_bundle`; the artifact sha256 equals the file bytes. `tests/integration/test_route_bundle_ingest.py` passes and the role assertion test passes. |

Only these two requested items were re-verified on this row. This head also adds
the V0 candidate-artifact selection rule and the INTERFACE-v1 no-result-bundle
rule; those are outside this row's requested scope and are not claimed as
verified here. Review items 9/10/11/12 remain separate work; T8.3 stays blocked;
no merge, tag or live success is approved.
