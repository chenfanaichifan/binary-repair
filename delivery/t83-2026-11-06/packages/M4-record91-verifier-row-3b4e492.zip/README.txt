# M4 verifier-row delivery (record 91)

**Base:** `docs/handoffs/91-m5-completion-2026-11-05.md` at M5 branch head
`3b4e492a4f48` (pre-row SHA-256
`fdb31b5425025e243633200705320a68d47cef265a72c7fe3f73bc81f3ae1ac8`).
The older `c15a3aff`-based patch is superseded and must not be used.

**Apply:**

```text
git apply record91-m4-verifier-row-3b4e492.patch
```

**Files and SHA-256:**

```text
0472a54177fd557b110efa5931b6ad3f167371914f30cd800787efe48d68ee21  record91-m4-verifier-row-3b4e492.patch
e01a1752644333e079818e73b1986434f6b80850ce6b5c82cb52c2f7be0f38b6  91-updated-3b4e492.md
```

The verifier row keeps the same-person limitation: M4 verifier = Lead, same
operator, not an independent two-person signature. Review items 9/10/11/12 are
separate work; T8.3 remains blocked; no merge, tag or live success is approved.
