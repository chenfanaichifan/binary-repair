# M3-132 handoff — the M4 verification package, packed with the evidence that it runs

Record 130 delivered `M4-v4-handoff-2026-11-06/`; this package carries it, the
evidence that it was executed from a clean directory, and the record that
describes both. Built at `86b6e36` on `m3/cwe416-v3-noinput`.

Nothing here decides a gate. It carries no `verified_by` value, V4 is still
`not_run` in the 124 bundle, and CWE416 no-input remains the only sample.

## Contents

```
M3-132-m4-handoff-package-2026-11-06/
  INDEX.md                                  this file
  130-m4-v4-handoff-2026-11-06.md           how the package was built and proven
  handoff/M4-v4-handoff-2026-11-06/         13 files — the runnable package
  evidence/m4-handoff-2026-11-06/           5 files — the transcripts
  SHA256SUMS                                20 rows, every file above
```

The handoff directory keeps its own `SHA256SUMS` (12 rows) and the evidence keeps
its own (3 rows), so the archive is verifiable at three levels: the whole
package, the payload, and each transcript. Nothing inside writes the archive's
own digest — that lives beside it as `dist/M3-132-m4-handoff-package-2026-11-06.zip.sha256`.

## The payload in one table

| file | sha256 | what it is |
|---|---|---|
| `handoff/…/inputs/candidate.elf` | `46d16e99…1fcd0` | repaired binary, 5 bytes at offset 4869: `call free@plt` → 5 × `nop` |
| `handoff/…/inputs/original.elf` | `c9c2632e…123c9` | unrepaired control, same size |
| `handoff/…/inputs/contract.json` | `8a2b408c…e3c3b` | `schema_version 3`, `input_mode none` — unchanged, not modified by this delivery |
| `handoff/…/inputs/v4_harness.py` | `986688bc…b863e` | the producer, byte-identical to record 128 |
| `handoff/…/expected/harness-output.expected.json` | `9c6eeda7…8ca8c` | what the producer must reproduce |
| `handoff/…/expected/selfcheck.expected.json` | `8e4f082a…075b5` | normalised result of the 18 environment checks |

## Verifying it without trusting this file

```sh
# 1. the archive itself, from dist/
cd dist && sha256sum -c M3-132-m4-handoff-package-2026-11-06.zip.sha256

# 2. after extracting
cd M3-132-m4-handoff-package-2026-11-06 && sha256sum -c SHA256SUMS        # 20/20
cd handoff/M4-v4-handoff-2026-11-06 && sha256sum -c SHA256SUMS           # 12/12
cd ../../evidence/m4-handoff-2026-11-06 && sha256sum -c SHA256SUMS       # 3/3
```

Then run the payload, which is the point of it:

```sh
cd handoff/M4-v4-handoff-2026-11-06 && sh verify_all.sh      # 3/3 steps, exit 0
```

`verify_all.sh` re-checks the package's own sums first, so a tampered input fails
there rather than silently changing a verdict.

## Running it where it belongs

The intended machine is the guest, as the unprivileged `m4verify` account:

| | |
|---|---|
| address | `m4verify@192.168.30.128:22` over VMnet8 IPv4 (host `192.168.30.1`) |
| privilege | none — no sudo, no sudo group, password locked, public key only |
| key | `dist/m4verify_id_ed25519`, fingerprint `SHA256:5JOwkAS+6WI6rTdI88Ho6J4Lly/A+lozxUhEPN21zBc` |
| interpreter | `/opt/angr-venv/bin/python` — CPython 3.12.3, angr 10.0.4.post1, z3 5.1.0 |

The private key is deliberately **not** in this archive: shipping a secret inside
a hash-manifested package defeats both the manifest and the secret. It sits next
to the archive in `dist/`, is excluded by `.gitignore`, and is not in any
`SHA256SUMS` here.

## What the evidence inside shows

`evidence/…/02-clean-run.txt` is the whole transcript of extracting the payload
into an empty `/tmp/m4-clean-<pid>` directory as `m4verify` and running it:

```
sh run_selfcheck.sh   identical: 18/18 checks, same engine block   EXIT=0
sh run_e2e.sh         byte-identical                               EXIT=0
sh verify_all.sh      12 files match SHA256SUMS / ALL PASS 3/3      EXIT=0
```

`evidence/…/01-access.txt` is the account: `uid=1004(m4verify)`, `sudo -n true`
→ exit 1, `groups` → `m4verify`, `passwd -S` → `L`, password attempt → `Permission
denied (publickey)`, and the interpreter answering `10.0.4.post1 5.1.0`.

## Known defect, carried rather than patched

`handoff/…/inputs/v4_harness.py` still says its output "is written only through
`write_v4_evidence`". That stopped being true in record 128, when the second
writer was deleted and M1's adapter took over: the code writes the measurement
file directly and the adapter produces `v4-symbolic.json` from it.

The docstring is left alone on purpose. Its sha256 is what records 128 and 129
vouch for, and a cosmetic edit would invalidate two delivered records to fix a
sentence. The README inside the package says which part to trust when they
disagree.

## Not claimed

- **No `verified_by`.** Writing it is the verifier's act after its own replay.
- **V4 remains `not_run`.** These scripts show environment and producer are
  reproducible; they say nothing about whether the evidence is sufficient.
- **One sample.** CWE416 no-input only. T8.3 stays blocked, and nothing here
  proposes or implies a second defect class.
- **Scope is a model.** `claimed_scope: model` — a property over the target
  function with a symbolic `malloc` result, with the candidate's unsat coming
  from an empty disjunction rather than a solved constraint. The `not_claimed`
  list inside `harness-output.expected.json` spells this out.
