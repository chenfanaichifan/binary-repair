# P3B execution-bridge bundle — V0 multi-artifact variant

Route B bridge package for the frozen candidate `208574ab…6717`, assembled from
P3B v6 evidence. Compared with `P3B-execution-bridge-2026-11-05.zip` this
variant changes exactly one thing: **V0 carries two artifacts**, so the candidate
is bound by `candidate_sha256`, not by list position.

## Why V0 has two files

V0 binds the job identity.

- `original.elf` — the frozen original binary, sha256 `aa428157…8393`
- `candidate.elf` — the repaired candidate, sha256 `208574ab…6717`

The artifact list deliberately puts `original.elf` **first**:

- binding by first entry would select `original.elf` and be wrong;
- binding by hash selects `candidate.elf`, the only file whose bytes hash to
  `candidate_sha256`;
- exactly one file in the whole package hashes to `candidate_sha256`.

This is the case M5 fixed in `3b4e492` (`bind V0 candidate among multiple
artifacts`). Ingesting this package is a direct check that the fix is live:
`evidence["V0"]` must resolve to sha256 `208574ab…6717`, not to `original.elf`.

## Contents (flat layout, bare filenames only)

```text
bundle.json                 manifest: route, candidate_sha256, gates V0..V5, analysis, comparison
handoff.json                INTERFACE-v1 envelope: from M3, to M5, route_b, files
SHA256SUMS                  integrity record, hash-binds every file except itself
result-bundle.json          per-gate status + evidence (required to obtain passed)
original.elf                V0: frozen original (aa428157…8393)
candidate.elf               V0: repaired candidate (208574ab…6717)
audit.json                  V1: static audit (pass, 7 checks)
v2-routeb-fixed.json        V2: interface check (16/16, explanation only)
manifest-repaired.json      V3: repaired behaviour (6/6, explanation only)
reproducibility.json        V5: byte-identical x2
expected-effects.json       analysis_expected_effects (AnalysisArtifacts)
assumptions.json            analysis_assumptions
uncertainties.json          analysis_uncertainties
behavior-comparison.json    original-vs-candidate on the same six cases
```

## Gate status

| Gate | Status | Evidence |
|---|---|---|
| V0 | passed | `original.elf`, `candidate.elf` (candidate bound by hash) |
| V1 | passed | `audit.json` |
| V2 | passed | `v2-routeb-fixed.json` |
| V3 | passed | `manifest-repaired.json` |
| V4 | **not_run** | model-level only (Lead ruling 65); not binary-level proof |
| V5 | passed | `reproducibility.json` |

`16/16` and `6/6` are explanatory notes in `details`; they are not per-gate hash
evidence and are not used to promote any gate.

## Boundaries

- `T8.3` remains **blocked**: no second public sample of a different defect
  class and no guest build path exist. No sample is fabricated.
- M3 did not modify any M5 file (`tools/`, `docs/interfaces/`, `app/domain/`).
  Ingest is owned by M5.
- Verification here is **offline** (`scripts/check_handoff.py` + rehash +
  schema checks). M5 ingest has not been run in this checkout, and this document
  does not claim any acceptance verdict.
