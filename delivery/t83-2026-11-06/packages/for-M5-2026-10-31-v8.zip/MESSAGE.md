# To M5 — 2026-10-31 v8: authoritative P3A v6, P3B v6, P4 v3

This bundle supersedes v7. The only change from v7 is P3B v5 -> P3B v6, which
carries the Route B candidate fix (reuse the R-X PT_LOAD tail, 0 new segments).

## P3A v6 (authoritative, decided 2026-10-30)

```text
P3A-routea-2026-10-29-v6.zip
35,660 B
SHA-256 192492eedd3c83931da7f4e6ce3a1e717dabde85549a94cd9a2e3c6d289870c1
checker PASS (re-run 2026-10-30 by M3+M5 agent): 26 files / 26 sums
SHA256SUMS sha256 023b94fac2ecc3d6e991901092c2c7c980002e875e2fe5e283524118e3b22115
```

Decision: v6 is the authoritative Route A package. It is the newest, it passes
check_handoff.py, and its README's "checker NOT RUN" note is now closed by the
observed PASS above. P3A v4/v5 are superseded; earlier for-M4/for-M5 bundles
(v1..v7) carried v4/v6 and are superseded by this bundle.

## P3B v6 (authoritative — Route B candidate fix)

```text
P3B-package-v6-2026-10-31.zip
55,104 B
SHA-256 461b5f58eb5fab7c5ae85e096020d62eafcf11c58c0b505f2cad570710ac1bbe
checker PASS: 23 files / 23 sums
SHA256SUMS sha256 24a9abc3…3fcc6c (see the zip's own SHA256SUMS)
```

v6 = v5 + Route B candidate fix. The old candidate `63fcafa6…6d01` failed V2
`extra_load_segments_within_contract` (2 added PT_LOAD, contract allows 1 R-X
fallback). The fixed `patch_function` in `executor/probe_patcherex2.py` now
extends the existing R-X PT_LOAD tail (0x8e9 -> 0x1000, `authorized_edits[1]`)
and registers it as RX free space via `AllocationManager.add_free_space`, so the
recompiled `badSink` body lands there instead of in a new segment.

Result (new candidate `208574ab…6717`):

```text
PT_LOAD count      4 (unchanged, was 6)
V2 interface       16/16 passed (was 15/16 failed)
V3 behaviour       6/6 (repaired_pass=true)
V5 reproducibility byte-identical x2
file size          26,792 B (unchanged)
```

Contract `authorized_edits[2]` is NOT changed (per the Lead's instruction). The
executor main file `routeb/executor.py` is unchanged (sha256
`4f072175…b05d`); only `routeb/probe_patcherex2.py` changed (sha256
`d6e65427…b96b`).

## P4 v3

```text
P4-package-v3-2026-10-30.zip
45,691 B
SHA-256 a8f335a38d4d3e8e495724bbdd098f37afb3405970f32c1ef03bef9746cae
checker PASS: 26 files / 26 sums
SHA256SUMS sha256 e4b81b34df9b2707542fe2158f9f76ce5760a675e6494d82df85994f669e6c5e
```

v3 closes the guest-boot evidence: chain-manifest.json (uid 4..11 layers + .vmsd,
hashed powered off), revert-raw.log (scripted vmrun revert, verbatim),
post-revert-fingerprint.txt (live in-guest), regenerated uid 11 harness-manifest.json,
exported jobwrap + gate4.conf bytes, updated isolation.json. P4 v2 superseded.

## Still open (do not over-read)

- Gate 4 acceptance is NOT RUN. Execution pass 6/6 (2026-10-29) is not acceptance.
- No gate4_pass claim anywhere. The Gate 4 record is written from observed values only.
  The Lead's 2026-10-31 approval covers the strict unchanged round-trip scope only;
  overall MVP remains NOT APPROVED.
- Route B V4 symbolic is still `not_run`.
- A fresh real p2 with candidate 208574ab has NOT been run. Existing job1/job2
  verdicts (inconclusive/rejected) used the 10-30 candidate 63fcafa6 and remain
  historical facts.
- Gate 5 is still BLOCKED (no `jobwrap gate5` mode + no `GATE5_SCRIPT_SHA256`).
- app/ and tools/ are absent from this checkout: adapter and p2_acceptance.py
  cannot run here until transferred.
- M4 independent verification waived by the Lead on 2026-10-30; result is
  self-verified (single agent), never "independently verified".
