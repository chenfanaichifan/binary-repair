# To M5 — 2026-10-31 v11: P2-real + P3A v7 + P3B v6 (fixed) + P4 v3

This bundle supersedes v10. **v10 had a packaging gap**: it carried P3A/P3B/P4
but not the **P2-real** package, which is where the V4 bounded-symbolic evidence
lives (`P2-real/v4/`). v11 adds P2-real so the V4 evidence actually ships.

**Nothing here changes the overall verdict: Gate 4 acceptance is NOT RUN,
overall MVP is NOT COMPLETE, Gate 5 is BLOCKED.**

## The four packages

### P2-real (NEW in v11 — carries V4 evidence)

```text
P2-real-2026-10-31.zip
54,237 B
SHA-256 a9db726a888c6fedfa7016ea36a088fb4e49ec80e3d93ee1cd0467c2ecadb71a
checker PASS 38/38
```

End-to-end acceptance on the real fixture + probes + the V4 evidence. The V4
evidence is `v4/v4-evidence.json` + `v4_symbolic.py` + `v4_run_all.py`:

- Calibration `original`, free/over-long domain -> **counterexample** (57 bytes
  written past dest[50]) — proves the model catches the defect.
- `original`, valid domain -> proven.
- Route A `c4a159` -> valid proven / free **no_counterexample**.
- Route B fixed `208574ab` -> valid proven / free **no_counterexample**
  (entry observed at `0x4018ec`, in the reused R-X tail).

### P3A v7

```text
P3A-routea-2026-10-31-v7.zip
40,610 B
SHA-256 0d013a284138c2ca35065a8a309adec737999ceeb71e3e8163eddb3402b8b2cf
checker PASS 29/29
```

### P3B v6 (fixed; candidate 208574ab)

```text
P3B-package-v6-2026-10-31.zip
58,138 B
SHA-256 b5ddbb48267d97d6946d5a87c9eba98c7a3d9638c59a9ca621f070e8439903a4
checker PASS 25/25
```

### P4 v3 (unchanged)

```text
P4-package-v3-2026-10-30.zip
45,691 B
SHA-256 a8f335a38d4d3e8e495724bbdd098f37afb3405970f32c6841ef03bef9746cae
checker PASS 26/26
```

## Honest status (v11)

```text
P2-real: checker PASS 38/38; V4 evidence present (self-verified, single-agent)
P3A v7:  checker PASS; V0/V1/V2/V3/V5 evidence; V4 self-verified (no independent review)
P3B v6:  checker PASS; V0/V1/V2/V3/V5 evidence; V4 self-verified (no independent review)
P4 v3:   checker PASS; execution evidence complete; acceptance NOT RUN
Gate 4:  DRAFT / NOT RUN
Gate 5:  BLOCKED
MVP:     NOT COMPLETE
```

Important caveats, unchanged by v11:

- **V4 is single-agent self-verified, not independently reviewed.** M4 was
  waived; the Lead verifies personally. A self-check is evidence, not a
  two-person sign-off. Whether V4 may be recorded `passed` (and thus close the
  last required obligation) is the Lead's call, not M3's.
- **No fresh real p2 with the fixed candidate 208574ab has run inside this
  package.** job1/job2 used 63fcafa6 (historical fact). M5's adapter must be
  pointed at `v4/v4-evidence.json` if V4 is to be re-adjudicated.
- No `gate4_pass` is written anywhere. Do not merge, do not tag.
