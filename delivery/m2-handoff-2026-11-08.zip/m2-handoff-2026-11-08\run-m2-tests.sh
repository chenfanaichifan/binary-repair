#!/usr/bin/env bash
# 跑 M2 的测试子集。
#
#   bash run-m2-tests.sh /path/to/binaryrepair-mvp
#
# 预期：62 passed（test_agent_console + test_agent_honesty）。
# test_assistant_llm / test_assistant_tools 也应全过。
set -euo pipefail

repo="${1:-.}"
cd "$repo"

if [ -x ".venv/bin/python" ]; then
  PY=".venv/bin/python"
elif [ -x ".venv/Scripts/python.exe" ]; then
  PY=".venv/Scripts/python.exe"
elif command -v python3 >/dev/null 2>&1; then
  PY="python3"
else
  PY="python"
fi

# Windows 上默认临时目录路径太长会让 pytest 建 basetemp 失败，
# 优先用短的根路径。
if [ -n "${M2_BASETEMP:-}" ]; then
  BASE="$M2_BASETEMP"
  mkdir -p "$BASE"
elif [ -d "/c" ]; then
  BASE="C:/pt-m2"
  mkdir -p "$BASE"
else
  BASE="$(mktemp -d)"
fi

echo "python: $PY"
echo "basetemp: $BASE"

exec "$PY" -m pytest --basetemp="$BASE" -q \
  tests/test_agent_console.py \
  tests/test_agent_honesty.py \
  tests/test_assistant_llm.py \
  tests/test_assistant_tools.py
