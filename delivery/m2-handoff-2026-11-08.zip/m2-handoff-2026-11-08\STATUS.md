# M2 状态（2026-11-08）

## 一、完成项

| 项 | 状态 | 提交 |
|---|---|---|
| T7.4 agent shell | 完成 | 早前 |
| T7.5 guided inputs | 完成 | 早前 |
| T7.6 结果屏 5.1/5.2 | 完成 | `dc7a012` |
| T7.6 顶层 obligations 兼容 | 完成 | `c6f2035` |
| T7.8 `/agent` job id 校验 | 完成 | `fb5ace1` |
| attempts + scope/bounded 渲染 | 完成 | `2853f8d` |
| T8.4 assistant 模式 UI | 完成 | `3db4719` + `102d0fb` |
| Review 12 scope/bounded UI | 完成 | `16b2a42` |
| comparison 状态 UI（179 契约） | 完成 | `34d054c` |

## 二、提交链（相对 `4f512f5`，共 8 个）

```text
dc7a012  fix(agent): flag missing evidence and never render blank cells or dead links
fb5ace1  fix(agent): do not redirect a legacy job link that is not an id
c6f2035  feat(agent): accept top-level obligations when routes omit them
2853f8d  feat(agent): render the attempts timeline and scope/bounded as read-only facts
3db4719  feat(agent): label the plan mode as scripted v1 and keep the raw mode visible
102d0fb  docs(agent): record the T8.4 mode badge and metadata behaviour
16b2a42  feat(agent): always render scope/bounded as unknown when the job omits them (Review 12)
34d054c  feat(agent): show comparison status from the API and never infer a pass
```

## 三、测试

```text
test_agent_console + test_agent_honesty = 62 passed
```

运行：`bash run-m2-tests.sh /path/to/repo`

## 四、已被外部确认的事实

```text
V5 字节核验        16/16（HOST）、8/8（内层）、65/65（顶层）
交付分支 head      5f8efa0d
P1 job             9247357c54714546a7ff84891f7766f8
verdict            success_within_scope
Review 9-11        PASS（按交付文件）
VMer record 88     NOT AVAILABLE
```

## 五、口径红线

1. `scope` / `bounded` 缺失一律 `unknown`，任何情况不显示通过；
2. `comparison.status=not_provided` 一律不可用，不猜字段名；
3. `exit_code=null` 显示「未知退出码」，不补 0；
4. `mode=deterministic` 显示「脚本 v1（deterministic）」，原始值保留；
5. 回退横幅必须写「不代表模型输出」；
6. Review 12 的 PASS 只表示 UI 如实表达缺失，不代表 scope 已满足。

## 六、依据文件

- `delivery/p1-real-window-2026-11-07/api/attempts.json`
- `delivery/p1-real-window-2026-11-07/api/route-a-evidence.json`
- `delivery/p1-real-window-2026-11-07/api/route-b-evidence.json`
- `delivery/p1-real-window-2026-11-07/controller/snapshot.json`
- `docs/handoffs/179-m2-all-inputs-handoff-2026-11-07.md`
- `docs/reviews/review-9-12-*.md`
