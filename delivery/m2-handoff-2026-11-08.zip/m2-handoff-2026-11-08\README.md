# M2 移交包（2026-11-08）

本包把 M2 的全部待移交内容一次交齐：分支、补丁、说明、复验清单、自检脚本。

## 包内导航

| 文件 | 干什么 |
|---|---|
| `m2-on-791.thin.bundle` | 增量 git bundle，ref `tmp/m2-on-791`，head `34d054c` |
| `patches-m2/0001..0008.patch` | M2 的 8 个自有提交，可 `git am` |
| `MERGE-INSTRUCTIONS.md` | 两种合并方式，含命令和冲突处理 |
| `REVIEW-12-CHECKLIST.md` | 给 M4 的 Review 12 复验步骤 |
| `STATUS.md` | 完成项、提交链、口径红线 |
| `STATE-122.md` | V5 16/16 与 comparison 契约的核验记录 |
| `verify-v5.sh` | 只读核验 V5 与交付清单 |
| `run-m2-tests.sh` | 跑 M2 的测试子集 |
| `MANIFEST.sha256` | 本包文件自校验 |

## 三件事

### 1. 合并代码（M1）

按 `MERGE-INSTRUCTIONS.md` 执行，核心三步：

```bash
git bundle verify m2-on-791.thin.bundle
git fetch ./m2-on-791.thin.bundle tmp/m2-on-791:refs/heads/tmp/m2-on-791
git merge tmp/m2-on-791
```

推荐用 bundle：`git bundle verify` 先验，再 fetch、merge。

### 2. 复验 Review 12（M4）

按 `REVIEW-12-CHECKLIST.md` 执行，关键是看到 `data-testid="agent-scope-bounded"`
且文案为 `scope：unknown` / `bounded：unknown`。

### 3. 复核 V5（任何人）

```bash
bash verify-v5.sh /path/to/binaryrepair-mvp
```

预期三项全 0 missing。

## bundle 前置条件

```text
prerequisite: 791caa319028a42071c7744a0042d147f90d5c6d
```

已确认该提交在 `delivery/all-hands-2026-11-07` 的历史中，因此接收方无需额外操作。
若 `git bundle verify` 报 `prerequisite commit not found`，说明本地仓库没有这条历史，
改用 `patches-m2/` 逐个应用。

## 当前状态

```text
分支    tmp/m2-on-791
head    34d054c
提交数  8（相对 4f512f5）
测试    test_agent_console + test_agent_honesty = 62 passed
V5      16/16（交付分支 5f8efa0d 已确认）
Review 12  代码就绪，等合入后由 M4 复验
```
