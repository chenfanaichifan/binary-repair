# P1 Route A — real guest run, 2026-11-07

**Outcome: executor `rc=0`, V0 `passed`, V1–V5 `not_run`. The candidate was never
executed by the executor, so no stdout/exit code exists for it.**

## What ran

Guest: `binrepair-vm` (Ubuntu 24.04.5, kernel 6.8.0-147-generic), baseline
snapshot `p1-prewindow-20261107` (uid 15).

```
/usr/local/sbin/jobwrap-executor executor /opt/binrepair/executor-repo \
  /var/lib/binrepair/jobs/p1-routea-noinput-20261107/staging/pkg \
  /var/lib/binrepair/jobs/p1-routea-noinput-20261107/out
```

Wrapper: `workers/executor/jobwrap_executor.c` compiled in the guest,
installed `0700 root:root`, sha256
`85be8aefea123c3825b807899486914c149cc371b95ce9ce88af1d8aeb1b2f60`.
Repo tree at `/opt/binrepair/executor-repo` reduced to the three files the
executor actually needs (`run_job.py`, `workers/route_a/worker.py`,
`workers/route_a/result_bundle.py`) because the full tree trips the wrapper's
depth limit.

## Result

```json
{"ok": true, "route": "route_a", "purpose": "repair",
 "bundle_sha256": "ede8a61acff88919fe83ff4b5638d4cbc513208a958fc2bd19f0825d62c8a481",
 "gates": {"V0":"passed","V1":"not_run","V2":"not_run","V3":"not_run","V4":"not_run","V5":"not_run"},
 "verified_files": 6}
```

`route_a/status.json` phase is `generating`, all five obligations `not_run`, with
the warning:

```
structure evidence incomplete (audit/readelf/edit-manifest)
```

The package ships none of those three files, and the executor's Route A path does
not run the candidate — it stages it, records identity, and writes the bundle.
So V1/V2/V3/V5 were never attempted.

## Isolation (measured, attested)

```json
{"account_guard":"passed","uid":1003,"euid":1003,"gid":1003,"groups":[],
 "cap_eff":"0000000000000000","no_new_privs":"1","seccomp":"2",
 "netns":"net:[4026532220]","jobwrap_attested":true,
 "jobwrap_path":"/usr/local/sbin/jobwrap-executor"}
```

Attestation file is root-owned `0444` at
`/run/binrepair/executor/attest-2955.json` (shipped as
`jobwrap-attestation.json`).

## Identity (V0)

```
original   c9c2632e792c5acd0311cc3a5e4eb3fde538eb05d0de9c6601711e84b7b123c9
candidate  2a96b1083f23a0885ef6152dee39c48648d496a7a026e37ccfb31382c412970e
contract   8a2b408c9b1463ca8cb14692d11f1580f80816a74e81cc13310852f3700e3c3b
valid     33be1edf0572a2563f456b3be3dd68a860da3d95d5f9b3d35d078de632180b08
SHA256SUMS sha256 = ede8a61a…a481
```

## Open observations

1. **No candidate execution.** The requested stdout/exit code does not exist.
   Running the candidate would be a separate step and is not part of this bundle.
2. **Contract hash differs between layers.** `route_a/status.json` reports
   `contract_sha256 = 2dea9b4c0a84a92450c029e3e17acc5894268b75594d401910cb98a7a2d44719`,
   while the shipped `contract.json` is
   `8a2b408c9b1463ca8cb14692d11f1580f80816a74e81cc13310852f3700e3c3b`.
   The package's own `SHA256SUMS` agrees with `8a2b408c…`, so V0 passed on the
   package hash. The `2dea9b4c…` value must be the worker's normalised contract
   hash; M3/M5 should confirm which one is canonical before this is cited.
3. **Operator steps needed for repeatability** (all discovered by failure):
   - package must live under `/var/lib/binrepair/jobs/`;
   - the `out` directory must not exist beforehand;
   - repo tree must be root-owned, not group/other-writable, and shallow.
