#!/bin/sh
{
  echo "uid=$(id -u) gid=$(id -g) groups=$(id -G)"
  grep -E '^(CapEff|CapPrm|CapBnd|NoNewPrivs|Seccomp):' /proc/self/status
  echo "netns=$(readlink /proc/self/ns/net)"
  echo "pidns=$(readlink /proc/self/ns/pid)"
  echo "route=$(ip route 2>/dev/null | head -3 | tr '\n' ';')"
  echo "lo=$(ip -o link show lo 2>/dev/null | sed 's/.*state //;s/ .*//')"
} >&3
exec "$1"
