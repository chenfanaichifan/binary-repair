# P1 Route A — supplemental candidate execution (2026-11-07)

**This is a supplemental observation. It is NOT the executor result bundle, it
carries no `verified_by`, and it does not raise any V-gate to `passed`.**

## Command

Run once in the guest `binrepair-vm`, as root, inside a fresh netns/mountns/pidns,
dropping to uid 1003 before `exec`:

```sh
unshare --net --mount --pid --fork sh -c '\
  mount -t proc proc /proc; \
  setpriv --reuid=1003 --regid=1003 --clear-groups \
          --inh-caps=-all --ambient-caps=-all --bounding-set=-all --no-new-privs \
          /tmp/probe.sh /var/tmp/supp/candidate.elf \
  > stdout.bin 2> stderr.txt 3> isolation.txt'
```

`probe.sh` writes the measured isolation facts to fd 3 and then `exec`s the
candidate, so `stdout.bin` contains candidate output only.

Candidate: `/var/tmp/supp/candidate.elf`, copied from the staged package.

## Result

```
exit code   0
stdout      100 bytes
            99 x 0x41 ('A') followed by 0x0a  -> ends with LF
stderr      0 bytes
sha256      2a96b1083f23a0885ef6152dee39c48648d496a7a026e37ccfb31382c412970e
before and after execution: identical
```

## Measured isolation

```
uid=1003 gid=1003 groups=1003
CapPrm: 0000000000000000
CapEff: 0000000000000000
CapBnd: 0000000000000000
NoNewPrivs: 1
Seccomp: 0
netns=net:[4026532220]
pidns=pid:[4026532216]
route= (empty)
lo=DOWN
```

**Caveat:** `Seccomp: 0` — this ad-hoc `unshare` + `setpriv` path does not install
a seccomp filter. The executor path (`jobwrap-executor`) does (`Seccomp: 2`, see
`P1-routea-real-2026-11-07/isolation.json`). Do not claim seccomp for this run.

## Contract hashes — two different layers, do not compare

```
package.expected.contract_sha256 = 8a2b408c9b1463ca8cb14692d11f1580f80816a74e81cc13310852f3700e3c3b
  -> file-byte hash of contract.json; used for package identity / V0

status.contract_sha256           = 2dea9b4c0a84a92450c029e3e17acc5894268b75594d401910cb98a7a2d44719
  -> canonical-JSON hash; used by worker / status / result-bundle internally

Authority rule: package identity / V0 -> file hash 8a2b408c…
                worker normalised state -> canonical 2dea9b4c…
Never compare the two against each other.
```

Confirmed by M3: the two values are not a conflict and no layer currently mixes
them.

## What this does and does not cover

| Gate | State after this run |
|---|---|
| V0 identity | `passed` (executor bundle) |
| V1 structure | still missing `audit.json` / `readelf-audit.txt` / `edit-manifest.json` |
| V2 interface | still missing interface evidence |
| V3 behaviour | **only this single observation**; not a gate pass |
| V4 symbolic | missing (Route A candidate); M4 owns it, Route B marker must not be reused |
| V5 reproducibility | missing; two independent patch replays required |

Consequence: Route A is **not** V0–V5 green and P1 overall stays `inconclusive`.

## Boundaries honoured

- guest-only execution; host neither compiled nor executed anything;
- no `verified_by` field anywhere in this package;
- no V-gate upgraded by this observation;
- Route B and V5 evidence untouched.
