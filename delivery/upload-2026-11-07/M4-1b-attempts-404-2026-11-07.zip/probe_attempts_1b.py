import os
import tempfile
from pathlib import Path

data_dir = Path(tempfile.mkdtemp()) / "var"
os.environ["BINARYREPAIR_DATA_DIR"] = str(data_dir)

from fastapi.testclient import TestClient  # noqa: E402

from app.controller_api import app  # noqa: E402
from app.services import jobs  # noqa: E402

client = TestClient(app, base_url="http://127.0.0.1")

record = jobs.create_job(
    original_bytes=b"\x7fELF attempts probe",
    filename="attempts.elf",
    defect_description="attempts probe",
    data_dir=data_dir,
)

empty = client.get(f"/api/jobs/{record.id}/attempts")
print("empty job status:", empty.status_code)
print("empty job body:", empty.json())

missing = client.get("/api/jobs/does-not-exist/attempts")
print("missing job status:", missing.status_code)
print("missing job body:", missing.json())

approval = jobs.approve_contract(
    record.id,
    contract_revision=1,
    reviewer_label="m4",
    data_dir=data_dir,
    input_sha256=record.original_sha256,
    manifest_sha256="1" * 64,
)
run = jobs.start_run(
    record.id,
    approval=approval,
    idempotency_key="m4-attempts",
    data_dir=data_dir,
)

payload = client.get(f"/api/jobs/{record.id}/attempts").json()
rows = payload["attempts"]
print("attempt count:", len(rows))
for row in rows:
    print("row keys:", sorted(row))
    print(
        "attempt_no/status/route:",
        row.get("attempt_no"),
        row.get("status"),
        row.get("route"),
    )
print("all have attempt_no:", all("attempt_no" in row for row in rows))
print("all have status:", all("status" in row for row in rows))
print("all have reason:", all("reason" in row for row in rows))

snapshot = client.get(f"/api/jobs/{record.id}").json()
print(
    "snapshot routes A/B attempt_id:",
    snapshot["routes"]["A"].get("attempt_id"),
    snapshot["routes"]["B"].get("attempt_id"),
)
by_route = {row["route"]: row["id"] for row in rows}
print(
    "snapshot attempt_id matches rows:",
    snapshot["routes"]["A"].get("attempt_id") == by_route.get("route_a"),
    snapshot["routes"]["B"].get("attempt_id") == by_route.get("route_b"),
)

empty_record = jobs.create_job(
    original_bytes=b"\x7fELF empty probe",
    filename="empty.elf",
    defect_description="empty attempts probe",
    data_dir=data_dir,
)
empty_snapshot = client.get(f"/api/jobs/{empty_record.id}").json()
print(
    "empty snapshot attempt_id A/B:",
    empty_snapshot["routes"]["A"].get("attempt_id"),
    empty_snapshot["routes"]["B"].get("attempt_id"),
)

