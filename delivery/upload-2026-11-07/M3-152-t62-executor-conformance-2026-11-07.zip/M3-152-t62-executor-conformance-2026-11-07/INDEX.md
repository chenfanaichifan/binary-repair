# M3 T6.2 executor conformance: jobwrap-executor, isolation proof and repair retirement

- Package: `M3-152-t62-executor-conformance-2026-11-07`
- Owner: M3
- Date: 2026-11-07
- Status: T6.2 complete; T8.3 untouched, no gate promoted, no verified_by written
- Source: `working tree at eb60468 with uncommitted T6.2 files (2026-11-07)`
- Recipients: VMer, M4, Lead
- Requester: VMer

## What this is

- Record 152: the new fixed-argv jobwrap-executor wrapper and its guest-side build/install contract.
- The executor now validates a root-owned, pid-bound attestation; setting BINARYREPAIR_JOBWRAP alone is refused.
- Formal synthetic Route B screening under the wrapper (run5) plus negative checks and the retirement of account repair (uid 1002), with runner (uid 1003) retained.

## Contents

| file | sha256 |
|---|---|
| `152-m3-t62-executor-conformance-2026-11-07.md` | `9ce4c01ed9937267…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/accounts.txt` | `d5f5473af3ac1991…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/bundle-sha256.txt` | `a43fcb9752c4d5fe…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/conformance.txt` | `74d7d6fb2f8f8372…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/jobwrap-attestation.json` | `367878cca8c60823…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/negative.txt` | `286f6c7565e85749…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/package-SHA256SUMS` | `1e75782d29c841da…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/package.json` | `31b7b0f19719925e…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/README.md` | `f71e2bd6896dc3fe…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/audit.json` | `48b484a0deeb6693…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/bundle-record.md` | `20e07de001cd489d…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/bundle-sha256.txt` | `6c586883b4ac72b6…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/bundle.json` | `bcebad18fa830c5d…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/candidate.elf` | `46d16e997bdfbb87…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/edit-manifest.json` | `10315685ee90fcb0…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/environment.json` | `491ed1c1b8a329da…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/independent-views/objdump-disassembly.txt` | `e8f8b40d6a43c6fc…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/independent-views/readelf-dynamic.txt` | `4ef58db9bdfb0970…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/independent-views/readelf-program-headers.txt` | `768ac74e5c824242…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/independent-views/readelf-relocations.txt` | `aeb8d45031f36722…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/independent-views/readelf-section-headers.txt` | `3886469249f5bddf…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/isolation.json` | `d9655e37ec562275…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/logs/routeb-executor.stderr` | `e3b0c44298fc1c14…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/logs/routeb-executor.stdout` | `e5f8ed0d84602985…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/original.elf` | `c9c2632e792c5acd…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/reproducibility.json` | `db18e041d5c7af9f…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/result-bundle.json` | `2bb4b796972cdb6a…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/run.log` | `4d8e8a28afb29566…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/run/SHA256SUMS` | `9f4d9ac804099b0f…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/SHA256SUMS` | `213c572dc64e56f5…` |
| `evidence/t62-guest-executor-conformance-2026-11-07/wrapper.txt` | `3efaeaccdab1ea26…` |
| `handoff/executor/__init__.py` | `72950165c80bdff5…` |
| `handoff/executor/jobwrap_executor.c` | `6a8b8a5707ec843b…` |
| `handoff/executor/README.md` | `c2a92361c66862e2…` |
| `handoff/executor/run_job.py` | `1176b03ac04001af…` |
| `handoff/executor/self_test.py` | `950bd18e5489cdc2…` |
| `handoff/tests/test_guest_executor.py` | `a3e5a802662b31c2…` |

`SHA256SUMS` holds 38 rows: the 37 files above plus `INDEX.md`, which cannot contain its own digest. Rows are sorted by path.

## Verify

```sh
cd dist && sha256sum -c M3-152-t62-executor-conformance-2026-11-07.zip.sha256
python3 -c "import zipfile;zipfile.ZipFile('M3-152-t62-executor-conformance-2026-11-07.zip').extractall('.')"
cd M3-152-t62-executor-conformance-2026-11-07 && sha256sum -c SHA256SUMS
```

## Deliberately not included

- No T8.3 producer marker, V2-interface.json, V4-not-run.json, candidate or contract bytes.
- No guest SSH private key, API key, client binary or credential.
- No old jobwrap binary; the Gate 3/4 binding is intentionally unchanged.
- No guest VM disk image or runtime job directory.

## What it does not claim

- This is synthetic Route B static screening with run_manifest false; no manifest or candidate was executed.
- V2 and V4 remain not_run; T8.3 remains blocked; this package is not a V0-V5 verdict and assigns no verified_by.
- The package freezes uncommitted T6.2 files on top of eb60468, not a new commit; repackage if the branch moves.
- The wrapper was compiled inside the guest; the host did not compile or execute any candidate.

## Next

- Verify the archive and inner manifest before opening anything; do not forward a modified copy.
- Treat jobwrap_executor.c and run_job.py as the reviewed contract; any attestation change must update tests and evidence together.
- T8.3 V4 replay remains M4/Lead work; this package does not unblock it.
