# Review 13 — v1.2.1 assistant key store / API (independent security review)

- **Date:** 2026-11-09 (Asia/Shanghai)
- **Reviewer role:** M3 (reviewer role), independent of M2 (producer of the key feature)
- **Review target:** branch `release/v1.2.1`
  - code state reviewed: `b7ee9a882a6860751fcb89a46f2aa589ebe8b9da` ("docs: record v1.2.1 rc1 candidate and M5 confirmation")
  - branch head at review close: `8f0908af5e0fb319db4dccd2c0428758ce9e69b1` ("fix(assistant): honor llm mode for jobless and job plans")
  - the branch moved while the review was running; every delta commit was reviewed (see §2). All key-scope files are **byte-identical** between `b7ee9a8` and `8f0908a` **except `agent.js`**, which changed only in `97c565d` (page reload after a successful key test; behavior-only, reviewed — no key handling change). The other code deltas (`backend.py`, `controller_api.py`, `8f0908a`) do not touch the key store/API; their key-consumption paths were reviewed and add no echo/log/prompt path.
- **Review worktree:** `D:\BinRepair\.tmp\review-v121` (detached HEAD at `8f0908a`; `git status --porcelain` empty before and after).
- **Host:** Windows, workspace-write sandbox; Python 3.12.15 (`D:\Binary_Repair\.venv\Scripts\python.exe`), pytest 9.2.0, FastAPI 0.162.0, httpx 0.28.1.
- **Fake keys only.** No real provider key was read, written, logged, or transmitted by this review. No provider call was completed; the one attempted call was blocked by the probe's egress guard. No P1/V5 run was repeated, no binary was executed, no VM was started.
- **Conclusion up front:** **PASS WITH LIMITATION** — no full-key disclosure was found in the reviewed store/API/UI/export paths, but two MEDIUM findings (mask policy, bundle-evidence path containment), one MEDIUM concurrency/atomicity defect, and several LOW findings are recorded, and the POSIX 0600 fallback was not executed on a POSIX host.
- **Fix re-review (same day, reviewed source `0d5791a`):** M5 fixed F1/A-1/F3 and partially mitigated F2; independent re-verification found **F2 not fixed** (HIGH residual bypasses) plus residual F1/A-1 edges. See **§9 addendum** — it supersedes the per-finding statuses above but not the original evidence.
- **F2 focused re-review (2026-11-10, reviewed commit `b06dadc`):** new `is_secret_file`-based fix passes all **8 required stored-key-file vectors** (pre-copy ValueError, 0 artifacts, 0 ZIPs with key), but is **not a full F2 closure**: `.env`/`session.token` aliases and a custom-env regression remain open. See **§10 addendum** (F2: PASS for the focused scope; overall F2 hardening still OPEN).
- **N-8/N-9 focused addendum + final N-11 closure review (2026-11-10/11, reviewed commits `079da82`/`ab25c17`, docs correction `3418491`, handoff `1dbd34c6…`):** **N-8 FIXED, N-9 FIXED, N-10 ACCEPTED LIMITATION, N-11 FIXED (docs-only; no runtime guard claimed or implied)**; F2 overall **PASS WITH LIMITATION**; **rc1: RETAIN (no recall); stable: ELIGIBLE from this M3 security review, subject to the disclosures/conditions in §11.6 and §11.9**. See **§11** — it supersedes N-11's status in §10.3.
- **Stable-target documentation sign-off (§11.12, 2026-11-11): `stable docs: PASS`.** Exact public candidate `148d236d46bbd514dbb48f0a0f506ef2a2143fcc` was delivered as bundle `v1.2.1-stable-148d236.bundle` (SHA-256 `c279ce…` verified) and reviewed against public RC `d7d20f4`: exactly 3 documentation files changed (README version, `217` N-11 wording, `220` N-11 label), **no application-code/test/evidence delta**, no runtime-guard claim, N-10 accepted limitation retained; targeted suite on the candidate tree 67/67 passed. Prior approvals applied only to earlier sources; this PASS is for this exact public commit. M4 may proceed with the ordered release workflow (publish `v1.2.1`, fast-forward public `main` to `148d236…` only, preserve RC tag); M3 moved no tag/main and made no P1/V5 change. See §11.12.

---

## 1. Review scope (审查范围)

### 1.1 Files reviewed line by line

| File | Blob (git SHA-1, `8f0908a`) | Focus |
|---|---|---|
| `app/services/assistant_key_store.py` (241 lines) | `6982474de524afc928ca51f7bf97abf056c6461a` | whole file: path, DPAPI, 0600 fallback, atomic write, validation, masking, status, load/clear |
| `app/services/assistant_llm.py` (704 lines) | `992cbfd019247ed4042b918af911d39996242244` | key read/precedence, `Authorization` header, `repr`, error mapping, `test_provider_connection`, `.env` loader |
| `app/main.py` (1021 lines) | `542b48e74a5d106d1e8f5291bb863caab9dcd96f` | the 4 key routes (`822-890`), session/CSRF middleware (`46-178`), export/report/artifact routes (`893-1008`) as needed for item 3 |
| `app/static/js/agent.js` (1746 lines) | `c366541bdeed6a0ea634cce32ccff457bd3c893a` | key panel `1608-1697`, `setText`, storage/history/URL use, CSRF header wiring |
| `app/templates/agent.html` (10,394 B) | `7a3ce91a15e9b0490ed863276ff2a846d3e33eef` | key panel `170-181`, `data-csrf` at line 21, password input `173-176` |
| `tests/test_assistant_key_store.py` (40 lines) | `4734876e99f5b8a599077c9d328c337143c6f45a` | what the committed tests actually assert |
| `tests/test_assistant_key_api.py` (96 lines) | `e2f45147ed97429297d50a1452ceb2ab231aa2d0` | same, at the HTTP boundary |

`tests/test_agent_console.py` (56 tests) was run as required and read for relevant key-panel assertions.

### 1.2 Adjacent paths inspected because a checklist item requires them

- Export/report/artifact: `app/main.py:893-908, 940-1008`, `app/backend.py:75-260` (`build_export_bundle` and all backend variants).
- Bundle/evidence ingestion (handoff path): `app/services/attempt_writer.py:49-142`, `tools/routea_bundle_to_attempt.py:95-140`, `workers/route_a/attempt_from_bundle.py:28-110`, `app/controller_api.py:178-265`.
- Key precedence consumer: `app/services/assistant_llm.py:531-563` (`client_from_env`).
- Delta commits added during the review: `97c565d` (`agent.js` reload after key test), `8f0908a` (`backend.py` mode passthrough; `controller_api.py` LLM plan path now builds `client_from_env()`).

### 1.3 Out of scope / not re-run

- P1 and V5 were **not** re-run; no P1/V5 evidence file was modified (verified empty diff since `b7ee9a8`; see §8 and the evidence transcript).
- No real provider call, no real key, no browser journey replay, no POSIX host, no VM.
- Public `main` and any tag were not touched by this review.

---

## 2. Method and independence

- **Lead review:** full static read of the files above; independent replay of the security-critical claims (DPAPI, validation matrix, CSRF/session, env precedence, save failure, masking, real-uvicorn log capture, repository key scans) with fake keys only.
- **Three independent focused reviews**, each with its own evidence file (kept out of git because they contain machine transcripts; paths under `D:\BinRepair\.tmp\review-findings\`):
  1. `backend-findings.md` — key store, provider-key handling, routes, committed tests (static + focused probes).
  2. `frontend-export-findings.md` — `agent.js`/template panel, browser-storage/DOM, export/handoff/report/download paths, repository key scan.
  3. `probe/probe-results.md` + `probe/probe.py` — in-process adversarial probe of the four routes (CSRF matrix, echo sink scan, env precedence, DPAPI at rest, save failure, masking, concurrency), with an egress guard and no uvicorn process.
- **Independence statement:** the reviewer is a different role/window from M2, who produced the feature. This is role separation, not human-independent review: all role windows are AI agents operated by the same owner. It is recorded here so no two-person-signature claim is inferred.
- The reviewer re-verified the material claims made by the focused reviews; where a verdict differs it is called out (item 1 and item 8 in §3).

---

## 3. Test commands and numbers (测试命令/数字)

### 3.1 Required command, as given

```bash
BINARYREPAIR_BINUTILS_DIR=/opt/homebrew/opt/binutils/bin \
python -m pytest -q \
  tests/test_assistant_key_store.py \
  tests/test_assistant_key_api.py \
  tests/test_agent_console.py
```

**This exact form cannot run on the review host:** `/opt/homebrew/opt/binutils/bin` is a macOS path and does not exist on this Windows host; the host Python is 3.12.15 in `D:\Binary_Repair\.venv`. The equivalent Windows form was run; `BINARYREPAIR_BINUTILS_DIR` was set to the Windows binutils directory documented in `docs/fixtures.md` (absent on this host, but none of the three files invokes `readelf`/`objdump` — verified by grep — so the variable is inert for these files).

### 3.2 Environment defect found first (recorded, not hidden)

The plain run fails at pytest fixture setup, before any app code runs:

```text
ERROR tests/test_assistant_key_store.py::test_key_round_trip_is_masked_and_removable
ERROR ...
E   PermissionError: [WinError 5] 拒绝访问:
    '...\pytest-of-<user>'
```

Cause: pytest's `tmp_path` factory creates its temp directories with POSIX mode `0o700`; this DSH Windows sandbox maps the mode onto the directory ACL in a way that makes the same confined token unable to list/scan them. This is a **host sandbox defect, not an application defect**: CPython documents that the `mode` argument is ignored on Windows. A scratch-only pytest plugin (`D:\BinRepair\.tmp\review-findings\hostshim\dshenv_win_temp.py`) restores the documented Windows behavior for the test process (ignores the POSIX mode on `os.mkdir`/`Path.mkdir`). No project file, no test, and no assertion was modified.

### 3.3 Required suite — observed result at final head `8f0908a`

```text
D:\Binary_Repair\.venv\Scripts\python.exe -m pytest -q -o addopts= \
  -p dshenv_win_temp -p no:cacheprovider \
  tests/test_assistant_key_store.py tests/test_assistant_key_api.py tests/test_agent_console.py
-> exit 0
-> 63 passed, 1 warning in 1.38s

per file:
  tests/test_assistant_key_store.py   2 passed
  tests/test_assistant_key_api.py     5 passed
  tests/test_agent_console.py        56 passed
```

`-o addopts=` overrides `pytest.ini`'s `addopts = -q`; the literal required command form would otherwise run at `-qq` and print no summary line (the test-planet dots are then the count).

### 3.4 Required grep check

```bash
grep -RIn "BINARYREPAIR_ASSISTANT_PROVIDER_KEY\|sk-" \
  app tests docs delivery --exclude='*.pyc' | head
```

Windows equivalent (`git grep` over the tracked tree; `-RIn` over the working tree is equivalent here because the worktree was clean):

```text
git grep -In -E 'BINARYREPAIR_ASSISTANT_PROVIDER_KEY|sk-' -- app tests docs delivery
-> 92 hits, exit 0 (first hits shown in §5/testing evidence file)
```

Every hit was classified; the classes are: the environment-variable **identifier** in code/docs/tests, obviously fake test keys (`sk-test-…`, `sk-api-…`, `sk-env-…`, `sk-stored-…`, `sk-csrf-…`, `sk-probe-…`, `sk-SENTINEL-DO-NOT-LEAK`), the `.env.example` placeholder `sk-your-key-here`, and false positives where `sk-` occurs inside words such as `task-`, `disk-`, `risk-`. **No real key.**

Additional independent scans (both by a focused review and re-run by the Lead):

```text
git grep -In -E 'sk-[0-9a-fA-F]{24,}' -- . ':!*.pyc'        -> 0 hits  (no DeepSeek-shaped key)
git grep -In -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|Bearer [A-Za-z0-9._-]{20,}' -> 0 hits
tracked byte scan: 1,370 tracked files + 85 zip archives (members scanned, incl. delivery/) 
                   -> 49 raw pattern hits, all placeholder/fake; no key-like token inside any zip
git check-ignore -v var/assistant.key                         -> .gitignore:20:var/
git ls-files 'var/*' '.env'                                   -> empty
Test-Path var/assistant.key / .env in the review worktree     -> False / False
```

### 3.5 Adversarial probe of the four routes (in-process, fake keys, egress guarded)

Required probes `(a)`–`(g)` of the probe review: **(a)–(f) PASS, (g) FAIL.**

| Probe | Result |
|---|---|
| (a) CSRF/session on save/test/delete | PASS — 6/6 missing/wrong-token calls → `403 {"detail":"CSRF token missing or invalid."}`; no state change; correct token → save 200, test 503 (`llm_client_not_configured`, no provider call), delete 200; GET 200 with cookie / 401 without; foreign `Host`/`Origin` → 403 |
| (b) key never echoed/logged | PASS — invalid JSON/array/string/non-string/empty/whitespace/513-char/newline → 422 fixed strings; 512-char accepted; 0 full-key leaks across 148 bodies/headers/log/stdout sinks and 248 logging records |
| (c) environment precedence | PASS — POST/DELETE → 409, stored file absent or byte-unchanged; GET `source=environment`, `can_clear=false` |
| (d) Windows DPAPI at rest | PASS — 313-byte file starts `BRKEY1\n`; plaintext and base64 of the fake key absent; `protection=dpapi-user`; `load_key()` round-trips |
| (e) save failure | PASS — 500 `{"detail":"could not persist the key."}`, no key in body/logs, no `*.tmp`, previous key unchanged (same sha256) |
| (f) masking measurement | PASS as measurement — 9-char key exposes 7 literal chars (`sk-…ke99`), 12-char exposes 7, ≤8-char exposes 0 (finding F1) |
| (g) atomicity under concurrent saves | **FAIL** — see A-1: with one fixed `<key>.tmp`, 8/8 concurrent HTTP rounds had at least one 500; 2/8 had both 500; one captured round returned **HTTP 200 while no key file existed** (interleaving trace in `probe-raw.json`). A pre-existing stale `.tmp` also makes the next save 500 once (A-3) |

Lead's independent reruns of the security-critical claims agreed with the probe: DPAPI file shape/round-trip, `BRKEY1` magic and no plaintext; validation matrix (`422` paths); env 409s; save-failure 500 with no tmp/no key; CSRF 403s; `Host`/`Origin` 403s; GET read-only.

### 3.6 Real-server log check (supplement, Lead)

A real `uvicorn` process was started on `127.0.0.1:8817` with a scratch key file, a fixed session token, and deterministic mode; save/status/oversize/whitespace/clear requests were sent with a fake key. Observed:

```text
access log lines: only method/path/status, e.g.
  "POST /api/assistant/key HTTP/1.1" 200 OK
fake-key occurrences in stdout+stderr: 0
validation: oversize -> 422 "API key is too long"; whitespace -> 422 "API key must not contain whitespace"
```

The API key does not enter the server logs. **However** the access log does record the login URL including the session token (`GET /?token=<session-token> ...`), which is a session-boundary finding recorded as F8 (not an API-key finding).

### 3.7 Committed-test coverage (what the two target test files do not catch)

The 7 committed key tests pass and exercise real code, but they would **not** catch several regressions found or simulated during this review (finding F9):

- a Windows DPAPI → base64 downgrade: the store test asserts only that the raw key bytes are absent, never that the file starts `BRKEY1\n` or that `saved["protection"] == "dpapi-user"`, and a simulated downgrade passes every assertion;
- the short-key mask over-reveal (F1) passes all mask assertions;
- no negative tests for wrong/absent CSRF on DELETE or `/test` (only missing-token POST), empty/whitespace/oversized/non-string keys at the API, route-level env 409s, save-failure paths, corrupt key file, POSIX 0600/atomicity, or key absence in logs.

---

## 4. Findings (发现)

Severity scale: HIGH = full secret exposure or exploitable authorization break; MEDIUM = security-relevant weakness with preconditions, or integrity/failure under realistic use; LOW = hardening/robustness; INFO = design note. Evidence paths are relative to the reviewed commit unless stated.

### F1 — MEDIUM — Masked status over-reveals short keys; no minimum key length

- `mask_key()` returns `key[:3] + "…" + key[-4:]` for any key longer than 8 (`assistant_key_store.py:212-217`). That is 7 literal characters; for a 9-character key it exposes **7/9 = 78%** (`sk-…ke99`), for 12 characters 7/12. For a real DeepSeek-style ~35-character key it exposes 7/35 = 20% (prefix is the known `sk-`).
- The mask is returned by `GET /api/assistant/key` (`main.py:822-825`, via `key_status()` at `assistant_key_store.py:236`) and by the POST save response, and is rendered in the panel (`agent.js:1608-1626`). The full key is never returned.
- No minimum length/format check exists (`assistant_key_store.py:169-176`; `main.py:842-844`), so a short value — a misconfigured key, or a valid short key from a future adapter — can be saved and then mostly disclosed in the authenticated local page.
- No cross-origin read path: the app has no CORS middleware, the session gate and CSRF/Origin checks apply, and all rendered text goes through `textContent`.
- **Why not scored higher:** the disclosure is to the authenticated same local session that typed the key (the key owner), and realistic DeepSeek keys are long. The backend reviewer scored this item FAIL; the Lead records it as a release-relevant MEDIUM hardening defect rather than a full-key leak.
- **Recommendation (before a stable v1.2.1 tag):** mask to a fixed short tail (e.g. `sk-…` + last 4 only for keys of plausible length, otherwise bullets), and require a plausible minimum length/format before accepting a key. Do not commit key-derived text to records (see F3).
- **Evidence:** backend-findings.md §2 item 1/F1; probe result (f); Lead probe (`masking of short keys: 9-char → 7 visible, 13-char → 7 visible`).

### F2 — MEDIUM — Bundle-evidence ingestion can copy `var/assistant.key` into the artifact/export path

- The GUI/API export paths are clean (§3 checklist item 3). But two host-side bundle adapters accept a path declared by a **result bundle** and copy it into `data_dir/jobs/<job>/artifacts/...` with a DB artifact row, without containing the source path:
  - `app/services/attempt_writer.py:113-134` (`evidence_files`; relative paths resolved against the input file's parent, absolute paths used as-is) → `_register()` copies (`:49-85`);
  - `tools/routea_bundle_to_attempt.py:116-120` (`(evidence_root / relative_path).resolve()` with no `relative_to()` check) → `_register()`;
  - pass-through: `workers/route_a/attempt_from_bundle.py:33-45` returns an absolute bundle path unchanged.
- A crafted/compromised bundle (guest/worker output is explicitly untrusted data) can therefore name the on-disk key file; it gets copied, hashed and registered, and is then listable/downloadable through the controller artifact endpoint and referenced (name/`content_url`, not bytes) in the GUI export. The focused review demonstrated the `_register` primitive copying a scratch `var/assistant.key` into the artifact store; this was not driven through the full guest→GUI wiring (the pipeline is not wired end-to-end at this commit).
- Impact depends on the fallback: on Windows the copy is DPAPI ciphertext (not usable by another user without the same DPAPI context); on the POSIX `mode-0600` fallback the file is `BRKEY0` + **base64, i.e. plaintext** to anyone who can read the exported artifact or handoff package. Preconditions: operator runs a host adapter on an untrusted bundle.
- **Recommendation:** add the containment checks already used elsewhere (`tools/route_bundle_ingest.py:73-87`, `workers/executor/run_job.py:173-189`) to both adapters, reject absolute bundle-declared paths, and/or keep the key file outside the `data_dir` tree. Until then, the handoff claim “key never exported” must be read with this limitation.
- **Evidence:** frontend-export-findings.md §3.2/§3.3, §7 (`evidence_path_probe.py`); Lead code re-read of the three files.

### A-1 — MEDIUM — Concurrent saves are not atomic; one captured round returned HTTP 200 with no key persisted

- Root cause: `_atomic_write()` uses one fixed temp path `path.with_name(path.name + ".tmp")` with `O_EXCL`; the losing writer's unconditional `finally: tmp.unlink()` deletes the winner's in-flight temp file (`assistant_key_store.py:143-166`). Consequences under two simultaneous saves (double-click, two tabs, script):
  - one request reliably fails with HTTP 500 (`FileExistsError`/`PermissionError`/`FileNotFoundError`);
  - both can fail (observed 5/25 store rounds, 2/8 HTTP rounds), leaving no key configured;
  - one captured round returned **HTTP 200 while the key file did not exist** afterwards (interleaving trace in `probe-raw.json`); the route has no “did the destination appear” check.
- No full-key leak and no corruption of a previously stored key were observed; this is an availability/integrity-of-report defect.
- **Recommendation:** unique temp name per writer (`tempfile.mkstemp(dir=path.parent, ...)`), unlink only that writer's own temp path, serialise `save_key`/`clear_key` with a process-wide lock (single local process), and/or verify the destination after `os.replace`.
- **Evidence:** probe-results.md §4.7/§5 A-1, `probe-raw.json`; complements backend-findings.md F3 (stale-temp first-save 500).

### F3 — LOW — Masked tails of real provider keys are committed in handoff records

- `docs/handoffs/218-v1.2.1-real-key-ui-journey-2026-11-09.md:21` records the panel status from a **real-key** journey including the mask tail (4 trailing characters of the real key); `docs/handoffs/216-real-deepseek-smoke-2026-11-09.md:22` records a masked tail as well (its own wording describes the UI path as fake-key-only). The values are deliberately not reproduced in this review.
- Four characters of a long random key are not enough to authenticate, and the repository is the project's own; but “no key material in committed records” is the team's rule, and the same mask policy is F1.
- **Recommendation:** scrub the masked tails from those records in a follow-up docs commit (or state explicitly that the displayed key was a fake fixture where that is the fact), and adopt “no key-derived characters in committed records” as a record rule.

### F4 — LOW — Plaintext envelope is accepted on Windows and status mislabels its protection

- `load_key()` accepts the `BRKEY0\n` + base64 envelope unconditionally (`assistant_key_store.py:195-197`), and `key_status()` decides the `protection` label from the platform, not from the stored envelope (`:227-229`). Verified on this host: writing a plaintext `BRKEY0` file (fake key) and calling `GET /api/assistant/key` yields `source=stored`, `protection="dpapi-user"`, `configured=true`.
- Requires write access to the key file (a local compromise/downgrade) and does not disclose the key; it is a truthful-reporting and defense-in-depth gap: a plaintext or tampered key file can be used and is reported as DPAPI-protected.
- **Recommendation:** derive the protection label from the envelope magic, and on Windows reject or re-protect a plaintext envelope (or clearly report `mode-0600`).

### F5 — LOW — Stale `.tmp` blocks the next save once

- A once-crashed/interrupted write can leave `assistant.key.tmp`; the next valid save fails with HTTP 500 once because of `O_EXCL`, then the function's own cleanup removes the stale file and a retry succeeds. Same fix as A-1.
- **Evidence:** probe S2; backend F3.

### F6 — LOW — Validation accepts control characters and non-ASCII; no minimum length

- Only whitespace (`ch.isspace()`) and >512 characters are rejected (`assistant_key_store.py:169-176`). `"\x00"`, embedded NUL, and non-ASCII keys were accepted with 200 in the probe. A NUL cannot be placed in an HTTP header, so the provider call fails safely and nothing is echoed; this is a validation-contract gap, related to F1's missing minimum length.
- **Recommendation:** restrict to printable ASCII (the documented provider-key alphabet), add a minimum/maximum plausible-length check.

### F7 — LOW — Save/clear override the environment-provided assistant mode

- POST save forces `BINARYREPAIR_ASSISTANT_MODE=llm` and DELETE forces `deterministic` (`main.py:857-860, 889`), although the comment says “an explicit env value wins”. Probe flipped an env-provided mode both ways. This changes process-global behavior, not the key itself; record it because it contradicts the in-code contract.

### F8 — LOW (session/CSRF boundary, adjacent to the key routes) — session token handling is weaker than the key file

- `var/session.token` is written with `token_file.write_text(...)` and default permissions (`main.py:55-66`), unlike the key file which is created 0600; the CSRF token is a process-lifetime static HMAC of it (`main.py:70`); and the real-server check observed the login token in the uvicorn **access log** (`GET /?token=<session-token>`), which follows the documented `?token=` bootstrap design.
- Impact: a local user/log reader who obtains the session token can mint the session cookie and CSRF token, then read the masked status and replace/clear the stored key — but cannot recover the DPAPI/0600-protected full key through the UI. The app's documented threat model is a single local operator, so this is recorded as an adjacent limitation, not a key-store defect.
- **Recommendation:** create `var/session.token` 0600 like the key file, and filter/redact the `token` query parameter in access logging; consider deriving CSRF per-request.

### F9 — LOW — Test coverage gaps

- See §3.7. The committed tests do not assert the DPAPI magic/protection label, the masking policy, or most negative paths; a simulated DPAPI→base64 downgrade passes all 7 tests. Add negative tests when fixing F1/F4/A-1, including POSIX 0600/atomicity coverage where a POSIX runner exists.

### INFO observations (no action required for rc1)

- `POST /api/assistant/key/test` has no try/except (`main.py:870-875`); the called function is designed never to raise, and a raise would yield a generic 500 without the key.
- `GET /api/assistant/key` sets no `Cache-Control`; the response contains only the masked status, never the key.
- The key file lives at `<repo>/var/assistant.key`, inside the default `data_dir` root (`app/backend.py:28`, `assistant_key_store.py:34-36`); all current artifact writers use `jobs/...` paths, so it is not reachable today (defense-in-depth: move it out of `data_dir` or deny-list non-`jobs/` artifact paths).
- The non-Windows fallback is base64, not encryption, and the status says `mode-0600` honestly; if POSIX ever becomes production, this needs a decision.
- `agent.js:6` still says the file “does not read or write the API key”, which is stale after this feature; the code itself is safe.
- `BINARYREPAIR_ASSISTANT_MODE=deterministic` does not gate `POST /api/assistant/key/test`: with a stored key the route builds a provider client and attempts the network by design (the probe blocked it). Deterministic mode is not an offline guarantee — relevant for offline demos, not a secret leak.
- During the review the branch added an LLM plan path (`8f0908a`, `app/controller_api.py`) that uses the same `client_from_env()` resolution (env key first, stored key second). No key is put in the plan, prompt, response, or log; reviewed as part of the delta.
- `97c565d` changed `agent.js` behavior only (page reload after a successful key test); no key handling change, no new echo/log/storage.

---

## 5. Checklist verdicts for the task's 10 items

| # | Item | Verdict | Basis |
|---|------|---------|-------|
| 1 | Can the key be echoed back? | **PASS for full-key echo; MEDIUM finding F1 on the mask** | Full key never in a response; only `masked`; mask over-reveals 7 chars for >8-char keys (78% for 9-char); no cross-origin read path |
| 2 | Can the key enter logs or error messages? | **PASS** | No `logging`/`print` in the key paths; error strings fixed; provider error keeps status only; `repr` hides the key; probe scanned 148 sinks/248 log records → 0 leaks; real uvicorn log scan → 0 occurrences |
| 3 | Can the key enter export/handoff? | **PASS for GUI export/report/download; LIMITATION via F2 + F3** | Export bundle is controller data only, no filesystem walk; `var/` gitignored; but bundle-evidence adapters can copy the key file into the artifact store (F2), and one real-key handoff record commits a masked tail (F3) |
| 4 | Does CSRF cover POST/DELETE? | **PASS** | All three unsafe routes require `X-CSRF-Token` (`main.py:835, 873, 881`; `_require_csrf` `:173-177`); missing/wrong → 403 with no state change; unauthenticated → 401 first; foreign `Origin` → 403; GET is read-only (session-boundary caveat F8) |
| 5 | Can the env key be overwritten/cleared from the UI? | **PASS** | `source=environment`, `can_clear=false`; POST/DELETE → 409 before any write; stored file untouched; status truthful (mode-override caveat F7) |
| 6 | Is non-Windows storage 0600? | **LIMITATION (not executed on POSIX)** | Code creates the temp 0600 (`O_CREAT|O_EXCL, 0o600`), replaces it, then `chmod 0o600`; faked-platform execution confirmed the exact calls; no POSIX host available (no WSL; VM unavailable) and `chmod` failure is swallowed |
| 7 | Is Windows storage DPAPI? | **PASS (executed on this Windows host)** | `BRKEY1\n` envelope, `CryptProtectData`/`CryptUnprotectData` with explicit ctypes signatures, current-user scope (no `LOCAL_MACHINE`), plaintext absent, round trip verified; cross-user refusal not tested (LIMITATION) |
| 8 | Is the file written atomically? | **PASS for a single writer; MEDIUM A-1 under concurrency** | temp in same dir, `O_EXCL`, `fsync`, `os.replace`, 0600; failed replacement preserves the old key and leaves no temp; concurrent saves can fail and once returned 200 with no file; stale temp blocks one save (F5); no directory fsync |
| 9 | Are empty/oversize/whitespace keys rejected? | **PASS** | Empty/whitespace-only/non-string → 422; internal whitespace/newline → 422; 513-char → 422, 512 accepted; store repeats the checks; control chars/non-ASCII/min-length gap = F6 |
| 10 | Does a save failure leak the key? | **PASS** | HTTP 500 fixed detail; no key in response/logs; no `*.tmp` leftovers; previous key bytes unchanged; stale-temp and blocked-path cases probed |

---

## 6. Not verified (未验证项)

1. **POSIX runtime behavior** — 0600 enforcement on a real POSIX filesystem, umask variants, chmod failure behavior. Host is Windows; WSL is not installed and the VMware guest could not be started from this session (`vmrun` unavailable). Only static analysis plus a faked-platform execution were done.
2. **DPAPI cross-user refusal / NTFS ACL isolation** — no second Windows user/administrator available. Same-user round trip is verified; that a different user cannot decrypt is inferred from current-user scope, not measured.
3. **Browser-level execution** — Node.js is absent on this host, so the panel was reviewed statically (textContent-only, no console/innerHTML, password input, cleared value) and the server side was exercised with `TestClient` and a real uvicorn process; no actual browser/DOM/Edge/Chrome run was replayed by this reviewer. The M2 records (docs 218/222) report such runs; they were not independently re-executed here.
4. **Real provider behavior** — no real key, no live DeepSeek request. Provider error-body behavior is covered by mock transports only; provider-side logging/retention is out of scope.
5. **Full F2 pipeline** — demonstrated at the `_register`/adapter level (the pipeline is not wired end-to-end at this commit), not by driving a crafted guest bundle through a live worker to a GUI download.
6. **Git history** — the key-material scan covers the tracked tree and all tracked zip members at the reviewed head; earlier commits were not scanned.
7. **Concurrency frequencies** — the A-1 failure modes are stable across >15 probe runs, but the exact per-run mix of errors and the 200-without-file rate are scheduler-dependent.
8. **Out-of-app handoff tooling beyond the files named in §1.2** — audited by reading the named scripts, not all scripts in the repository.

---

## 7. Conclusion (结论)

**PASS WITH LIMITATION.**

Rationale: across the reviewed store/API/UI/export paths, the full provider key is never returned to the browser, never logged, never put in a plan/prompt, never included in a GUI export/report/download, and cannot be overwritten or cleared while an environment key is active. On this Windows host the storage is genuinely DPAPI (magic, opaque bytes, round trip), single-writer atomic replacement is correct, validation rejects the required cases, and a save failure neither leaks the key nor destroys the previous key. The required targeted suite passes (63 passed, exit 0), and the required grep/scan finds no real key material.

The PASS is limited by the recorded findings, of which the following should be dispositioned before a stable `v1.2.1` tag (none of them blocks a prerelease candidate provided these limitations are disclosed with it):

1. **F1 (MEDIUM)** mask over-reveal for short keys and missing minimum key length — fix mask policy and validation, or explicitly accept for rc1.
2. **F2 (MEDIUM)** bundle-evidence path containment — fix before host bundle ingestion is used with untrusted packages, especially on the POSIX plaintext fallback.
3. **A-1 (MEDIUM)** concurrent-save atomicity — unique temp name + process lock + destination check; otherwise a double-click/two-tab save can report success while persisting nothing.
4. **F3 (LOW)** scrub the masked real-key tail from `docs/handoffs/218` (and 216) and adopt a no-key-derived-text-in-records rule.

The review does **not** certify: POSIX 0600 at runtime, browser DOM behavior, real-provider behavior, full bundle-ingestion pipeline. It also does not change any gate status: P1/V5 were not re-run and their evidence is unmodified; public `main` (`472aa94b8d931e03a2b20a8e4f671ba64f832230`) and tags were not moved; v1.2.1 remains a candidate branch.

---

## 8. Submission gates (提交门槛)

| Gate | Status | Evidence |
|---|---|---|
| Code review completed | **PASS** | 6 target files read line by line by the Lead, plus 3 independent focused reviews; all delta commits during the review reviewed |
| Security tests passed, or failure stated explicitly | **PASS (with environment adaptation disclosed)** | Required suite 63 passed / exit 0 on `8f0908a`; plain form is blocked by a host-sandbox `tmp_path` ACL defect (documented, reproduced); adversarial probe required (a)–(f) PASS, (g) FAIL, reported as A-1 |
| No key leakage | **PASS for full keys; LIMITATION F3** | No real key in tracked tree, delivered zips, tests, docs scan, logs, responses, or exports; masked 4-char tail of a real key committed in `docs/handoffs/218` (and a tail in 216) — values not reproduced here; fix recommended |
| P1/V5 evidence not modified | **PASS** | `git diff --stat b7ee9a8 8f0908a -- T8.3-evidence-* T8.3-refresh-* T8.3-supplement-* M4-v4-handoff-* delivery/p1-*` → empty; no P1/V5 run was repeated |
| Tags/main not moved | **PASS** | `origin/main` before and after: `472aa94b8d931e03a2b20a8e4f671ba64f832230`; no `v1.2.1` tag created; review is on a separate branch |
| Unverified items written out | **PASS** | §6 lists 8 explicit unverified items |

**Disposition for the team:** accept as the M3 independent review of v1.2.1 rc1 with the limitations above; open follow-up fixes for F1, F2, A-1 and the F3 docs scrub before a stable tag. No gate/tag/main change is requested or made by this review.

---

## Appendix A — Commands actually run (review-close head `8f0908a`)

```text
git -C D:\BinRepair fetch origin release/v1.2.1 (https, sslBackend=openssl)
git -C D:\BinRepair\.tmp\review-v121 checkout --detach 8f0908af5e0fb319db4dccd2c0428758ce9e69b1
D:\Binary_Repair\.venv\Scripts\python.exe -m pytest -q -o addopts= -p dshenv_win_temp \
  -p no:cacheprovider tests/test_assistant_key_store.py tests/test_assistant_key_api.py \
  tests/test_agent_console.py          -> 63 passed, exit 0
git grep -In -E 'BINARYREPAIR_ASSISTANT_PROVIDER_KEY|sk-' -- app tests docs delivery  -> 92 hits, classified
git grep -In -E 'sk-[0-9a-fA-F]{24,}' -- . ':!*.pyc'                                   -> 0 hits
git grep -In -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|Bearer [A-Za-z0-9._-]{20,}'     -> 0 hits
python lead-verify.py   (27 probes: session, CSRF/Origin/Host, validation, DPAPI, env, failure, masking)
uvicorn app.main:app --host 127.0.0.1 --port 8817 --log-level debug + fake-key HTTP client
python probe.py         (required CSRF/echo/env/DPAPI/failure/mask/concurrency matrix; egress guarded)
git diff --stat b7ee9a8 8f0908a -- T8.3-evidence-2026-11-06 T8.3-refresh-2026-11-06 \
  T8.3-supplement-2026-11-06 M4-v4-handoff-2026-11-06 delivery/p1-real-window-2026-11-07  -> empty
```

Detailed transcript excerpts: `docs/reviews/evidence/review-13-key-store-2026-11-09.txt`.
Reviewer working evidence (not committed; machine transcripts): `D:\BinRepair\.tmp\review-findings\` (`backend-findings.md`, `frontend-export-findings.md`, `probe/probe-results.md`, `probe/probe.py`, `lead-verify.py`, `lead-verify.log`).

## Appendix B — Independence statement

This review was produced by the M3 role, separate from the M2 role that implemented the key feature, and was supplemented by three independently-run focused reviews whose raw evidence was kept separate. All role windows are AI agents operated by the same human owner, and all ran on the same host. This is role-separated review, **not** a human-independent two-person signature; no such claim is made.

---

## 9. Fix re-review addendum — M5 fix commit `0d5791a` (2026-11-09)

**reviewed source `0d5791a317d0e6d06dd6de7a818dfc65f7378bdf`** ("fix(m5): harden key masking, atomic save, and evidence copy", M5, 2026-11-09 22:00 +0800).

- Release branch head at re-review close: `c495656` (docs-only delta over `0d5791a`: the `docs/handoffs/222` final verification/key-cleanup record; the reviewed code files are byte-identical between `0d5791a` and `c495656` — `git diff --stat 0d5791a c495656 -- <scope files>` is empty).
- Reviewed diff: `git diff 8f0908a 0d5791a` for `app/services/assistant_key_store.py`, `app/services/attempt_writer.py`, `tools/routea_bundle_to_attempt.py`, `tests/test_assistant_key_store.py`, plus docs 216/218/222/226. `tools/route_bundle_ingest.py` was unchanged by the fix and was re-checked.
- Method: Lead static review + dynamic probes, plus one independent adversarial verifier (`fix-verifier`, Team task `task-4`) with separate raw logs. Fake keys only; no provider/network call; no tracked file modified; no P1/V5 rerun.

### 9.1 Fix verdicts

```text
reviewed source 0d5791a
F1:  FIXED (stored/API path) / PARTIAL (environment-key residual = new finding N-1)
A-1: FIXED (original defects) / PARTIAL (residual N-2 MEDIUM: spurious concurrent-save 500 on Windows)
F2:  NOT FIXED (partial mitigation only; bypasses N-3 HIGH)
F3:  FIXED
new echo/log path: NONE (PASS)
```

- **F1 — mask/validation — FIXED for the stored/API path.** `mask_key` now returns `"*"*(len-4)+key[-4:]` (`app/services/assistant_key_store.py:228-231`): verified for lengths 5/8/15/16/33/512 — only the last 4 characters visible, no prefix leak. `_validate_key` (`:175-183`) enforces min 16, max 512, no whitespace, printable ASCII; API mapping verified: 15→422 `API key is too short`; 16→200; 512→200; 513→422 `API key is too long`; non-ASCII/NUL→422 `API key must be printable ASCII`; tab/newline→422 `API key must not contain whitespace`; empty/whitespace/non-string→422 `key is required.`. **Residual (N-1 LOW):** environment keys bypass `save_key` validation entirely and `mask_key` reveals the whole value when `len<=4` (verified: `BINARYREPAIR_ASSISTANT_PROVIDER_KEY=abcd` → `GET /api/assistant/key` masked `"abcd"`); 5–8-char env keys reveal 4 characters; a hand-written `BRKEY0` file is equally unvalidated.
- **A-1 — atomicity/concurrency — FIXED for the original defects; PARTIAL residual (N-2 MEDIUM).** Implemented: `tempfile.mkstemp` unique temp per writer (`:149`), `_SAVE_LOCK` around `save_key`/`clear_key` (`:31,194,220`), post-`os.replace` existence check (`:161-163`), `fchmod 0600` (`:152-155`). Verified: 20/20 rounds of two concurrent `save_key()` threads → no errors, final key is one complete input, no `*.tmp`; stale `assistant.key.tmp` no longer blocks; injected `os.replace` failure → OSError, old key preserved, no temp, generic HTTP 500, no key echo; replace-then-vanish → post-replace check raises, HTTP 500 instead of a false 200. **Residual N-2:** two simultaneous `POST /api/assistant/key` (two event loops, as in the two-`TestClient` harness) still give one spurious HTTP 500 per round (8/8 here; 9/10 and 10/10 in the verifier's runs) with `PermissionError [WinError 5]` on `os.replace`, because the competing request's `key_status()`/`load_key()` read holds `assistant.key` open on Windows. No corruption, no leak, the winner's key is complete, retry succeeds. In the documented single-process uvicorn configuration the async handlers serialise after their single `await request.json()`, so the residual needs multi-event-loop / multi-worker / cross-process callers; it is recorded as a limitation, not a security defect.
- **F2 — secret-path rejection — NOT FIXED (partial mitigation).** The exact basenames `assistant.key`, `.env`, `session.token` are now refused before copying in `app/services/attempt_writer.py:57-58` and `tools/routea_bundle_to_attempt.py:46-47` (verified). Bypasses that still copy the stored key are demonstrated in N-3: the fix is a three-name denylist, not containment.
- **F3 — masked real-key tails — FIXED.** `docs/handoffs/216…:22` and `docs/handoffs/218…:21` now read `sk-…<masked>`; no real-key tail remains in the current tracked tree. INFO: git history is append-only here — commit `8f0d728` still contains the old `…6789`/`…27d8` tails (rewriting history is the team's decision); the fake-key tail in `docs/handoffs/222` was removed by the final `c495656` docs commit.
- **No new echo/log path — PASS.** The fix commit adds no `print`/logging line (all 92 added lines scanned); save/status/delete and error responses, headers, 24 captured logging records, stdout/stderr contain no full fake key; the stored file remains DPAPI (`BRKEY1`, plaintext absent, round trip OK).

### 9.2 New findings

- **N-1 (LOW) — environment/hand-written keys bypass the new mask/validation policy.** `_env_key()` accepts any non-empty stripped string, `mask_key` reveals the entire value for `len<=4`, and non-ASCII env keys are accepted. Only reachable through operator-set env vars or a hand-written key file, never through `save_key`/POST. Recommendation: apply the same printable-ASCII/min-length policy to env keys, or mask anything shorter than the validation minimum with bullets only.
- **N-2 (MEDIUM, availability) — residual concurrent-save 500 on Windows.** See A-1; reachable only with multi-event-loop/process callers, not the documented single-process uvicorn. Recommendation if multi-process support is ever claimed: take the read path under the same lock, or briefly retry `os.replace` on `PermissionError`.
- **N-3 (HIGH — the unfixed part of F2) — the three-name denylist is bypassable, and one code path skips it.** Demonstrated by the Lead and independently by the verifier (fake keys, copied bytes verified in the artifact store):
  - **Windows filename aliases** pass the name check while reaching the same file: `ASSISTANT.KEY`, `Assistant.Key`, `assistant.key.`, `assistant.key `, `assistant.key::$DATA`, and a hardlink with a different basename (all copied by `attempt_writer`; it does not canonicalise the source path). An absolute/relative alias declared by a bundle is copied end-to-end into `jobs/<job>/artifacts/...` and is then downloadable/exported.
  - **Route A multi-evidence branch skips the per-source check entirely:** `tools/routea_bundle_to_attempt.py:123-136` zips all evidence for a gate first and only calls `_register()` on the archive (`V0-evidence.zip`), whose basename is not on the denylist. Lead reproduction: a V0 gate with two evidence paths (`assistant.key` + an innocuous file) produced a registered artifact whose ZIP contains `assistant.key` in plaintext. Single-evidence paths are blocked only because `convert()` canonicalises with `Path.resolve()` (`:119`).
  - **Operator-custom key filenames** (`BINARYREPAIR_ASSISTANT_KEY_FILE=…\mykey.dat`) are copied by both writers — the key store's configured path is not what the denylist checks. On this Windows host the copied bytes are DPAPI ciphertext; on the POSIX `mode-0600` fallback the same copy is base64 plaintext, i.e. direct key exposure.
  - `tools/route_bundle_ingest.py` remains safe (unchanged by the fix): `_safe_file` (`:73-89`) rejects absolute paths, `..` escapes, symlinks, and missing files (verified: absolute/`..`/missing rejected). Symlink and 8.3-short-name vectors could not be executed on this host (symlink privilege unavailable; 8.3 names disabled) — recorded as unverified, not passed.
- **N-4 (LOW) — committed tests do not cover the fix's risk areas.** The new tests cover mask/validation/stale-temp only; no committed test covers F2 rejection (or its bypasses), concurrent saves/lock behaviour, replace failure, POSIX mode, or the environment-key mask edge. `test_short_and_non_ascii_keys_are_rejected` actually tests a NUL character, not a non-ASCII key.
- **N-5 (INFO) — documentation residuals after F3.** Old masked real-key tails remain in git history (`8f0d728`); the fake-key tail in `docs/handoffs/222` was removed at `c495656`; this review's own files contain fake-key mask examples only.
- **N-6 (INFO) — M5's `docs/handoffs/226` says "full suite: pass" without numbers.** This re-review ran the required target suite (66 passed, exit 0) and the verifier ran a focused 5-file subset (32 collected / 31 passed / 1 skipped; skip = symlink creation unavailable). The 740-test full-suite count in `docs/handoffs/222` was not independently reproduced.
- **N-7 (unchanged prior findings, not in the fix scope):** F4 plaintext `BRKEY0` envelope still accepted on Windows and reported as `protection="dpapi-user"`; F7 save/clear still override `BINARYREPAIR_ASSISTANT_MODE`; F8 session-token file permissions/access-log exposure unchanged; old probe finding H (DELETE with `KEY_FILE` pointing at a directory → unhandled 500) unchanged; deterministic mode still does not gate `POST /api/assistant/key/test`.

### 9.3 Tests and commands (re-review)

```text
required command (adapted as in §3: the macOS path does not exist here; sandbox tmp_path shim used):
D:\Binary_Repair\.venv\Scripts\python.exe -m pytest -q -o addopts= \
  -p dshenv_win_temp -p no:cacheprovider \
  tests/test_assistant_key_store.py tests/test_assistant_key_api.py tests/test_agent_console.py
-> exit 0; 66 passed, 1 warning in 1.40s
   (store 5 passed / api 5 passed / agent console 56 passed)

git diff --stat 8f0908a 0d5791a -- <reviewed files>  -> store 52 lines, attempt_writer +2,
                                                        routea +2, tests +24, docs 216/218/222/226
git diff --stat 0d5791a c495656 -- <scope files>     -> empty (docs-only branch movement after the fix)

Lead probes: mask matrix, validation matrix, DPAPI, 20-round store concurrency, 8-round route
  concurrency, replace-failure + false-success simulation, F2 alias/ZIP/custom-name bypasses,
  echo/log scan, P1/V5 + main/tag checks.
Verifier (independent): mask, validation, DPAPI, concurrency, secret-path, no-echo probes and a
  focused pytest subset; raw logs under D:\BinRepair\.tmp\review-fix\logs\ (not committed).
```

Full re-review transcript excerpts: `docs/reviews/evidence/review-13-fix-rereview-0d5791a-2026-11-09.txt`.

### 9.4 Limitations of this re-review

1. The POSIX `mode-0600`/`fchmod` path was not executed (Windows host; same limitation as §6). The F2 plaintext-copy impact on POSIX is inferred from code and earlier static analysis, not observed on POSIX.
2. Symlink and 8.3 short-name bypasses could not be executed here (Windows symlink privilege unavailable; 8.3 names disabled). The denylist logic suggests both would bypass; recorded as unverified.
3. The N-2 concurrent-save 500 was reproduced with two event loops (`TestClient` threads), not against a real multi-worker uvicorn deployment; production exposure under the documented single-process configuration is unverified.
4. No browser run and no real provider call in this re-review; the fake-key UI/API paths were driven with `TestClient`/direct calls.
5. `docs/handoffs/226`'s "full suite: pass" and `docs/handoffs/222`'s 740-test count were not independently reproduced (only the required target suite and the verifier's focused subset).
6. Git history was not rewritten or re-audited beyond noting the residual masked tails (N-5).

### 9.5 Updated disposition

- F1, A-1 and F3 are **substantially fixed and independently verified**; the F1 and A-1 residuals are LOW/MEDIUM non-confidentiality robustness edges (N-1, N-2).
- **F2 remains open and is release-relevant.** A crafted/compromised result bundle plus a host adapter can still copy the stored key file into the artifact store/export path (plaintext on the POSIX fallback, DPAPI ciphertext on Windows). The three-name denylist blocks only the default names; the containment fix recommended under F2 is still required, especially before any stable tag on a POSIX host.
- Suggested disposition: v1.2.1 may remain an **rc prerelease candidate** with these limitations disclosed; **hold the stable `v1.2.1` tag** until F2 is fixed (or explicitly accepted by the Lead with the POSIX plaintext constraint stated), and preferably address N-1/N-2 and the N-4 test gaps in the same follow-up. This is consistent with M2/M5's own "hold stable" recommendation in `docs/handoffs/222`.

### 9.6 Submission gates (提交门槛)

| Gate | Status | Evidence |
|---|---|---|
| Fix re-review completed | **PASS** | Lead static + dynamic probes + independent verifier (task-4); all four findings adjudicated; residuals recorded |
| No key leakage | **NOT CLEAN (F2 residual)** | No full key in committed files/logs/responses (scanned); but F2's host-side copy path can still copy the stored key file into artifacts/exports under a crafted bundle (N-3) — plaintext on the POSIX fallback; F3 real-key tails removed from docs 216/218 |
| Unverified items explicit | **PASS** | §9.4 (6 items) |
| P1/V5 evidence unmodified | **PASS** | `git diff --stat 8f0908a 0d5791a -- T8.3-* M4-v4-handoff-* delivery/p1-*` empty; no P1/V5 run repeated |
| Tags/main not moved | **PASS** | `origin/main` still `472aa94b8d931e03a2b20a8e4f671ba64f832230`; no `v1.2.1` tag; release branch moved by M2/M5 (`0d5791a`→`c495656`), docs-only, not by this review |

---

## 10. F2 focused re-review addendum — M5 fix commit `b06dadc` (2026-11-10)

**reviewed commit `b06dadc40373b499f7ca46b338d2c6853cc0e86d`** ("fix(m5): close F2 secret-file aliases and archive bypass", M5, 2026-11-09 22:33 +0800; parent `78ac8d2`).

- Release branch head at review close: `99d15507a93aeecae511370ac3a2264f68c87782` (docs-only delta over `b06dadc`: 222/228 status alignment). The reviewed code files and `docs/handoffs/229` are **byte-identical** between `b06dadc` and `99d1550` (`git diff --stat b06dadc 99d1550 -- <scope files>` empty).
- Reviewed files (blob SHA-1 at `b06dadc`):
  - `app/services/assistant_key_store.py` → `086994d707fecb2e8dc07e2d73bce262fb919d54` (new `is_secret_file`, lines 229-246)
  - `app/services/attempt_writer.py` → `feb150546178781fac99d1ad662dd66a17c45a8a` (line 58 uses it)
  - `tools/routea_bundle_to_attempt.py` → `6e8888f332cf0a78db5fa6a5f8afdb0854731cf8` (lines 47 and 135)
  - `tools/route_bundle_ingest.py` → `b0a6351f38c20eb7404da6b21ee1ab93e6faea3b` (line 46: import only)
  - `docs/handoffs/229-v1.2.1-f2-hardening-2026-11-09.md` → `7351cea151b00e63c9c1ae0d65a7cd2217e8a136`
- Method: Lead static review + adversarial probe; one **independent** verifier agent (`f2-verifier`, Team task `task-5`) with separate logs. M5 wrote the fix and did not review its own work; this addendum is the M3 reviewer's independent result. Fake keys only; no provider/network call; no tracked file modified; no P1/V5 rerun.
- `is_secret_file` design: resolve-equality with `key_path()`, `os.path.samefile` (hardlinks/case aliases) when both exist, and a normalized-basename fallback (`rstrip(" .")` + `casefold()`). Adapters call it before copying; the Route A multi-evidence ZIP loop calls it per source before `zf.write`.

### 10.1 Required adversarial vectors — 8/8 PASS

All of these were rejected **before any copy**: `ValueError("refusing to copy secret material into evidence")`, 0 artifact files, 0 ZIP archives, 0 DB rows, `jobs/` tree not created, and no key bytes in the error output.

| # | Vector | `is_secret_file` | `attempt_writer` | routea single | Result |
|---|---|---|---|---|---|
| 1 | exact `…\assistant.key` | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 2 | `ASSISTANT.KEY` (case alias) | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 3 | `assistant.key.` (trailing dot) | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 4 | `"assistant.key "` (trailing space) | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 5 | `assistant.key::$DATA` | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 6 | hardlink `loot.bin -> assistant.key` | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 7 | custom key file `mykey.dat` (same env in adapter) | True | ValueError, 0 copied | ValueError, 0 copied | PASS |
| 8 | Route A multi-evidence ZIP containing `assistant.key` (both source orders) | — | — | ValueError, ZIP count 0 | PASS |

The Route A ZIP branch (the previous bypass) now fails closed: temp archive is cleaned, nothing registered, for `assistant.key` as first or last source, and also for `ASSISTANT.KEY` / trailing-dot / `::$DATA` / hardlink / `../` aliases (verifier's expanded matrix). Benign evidence still copies/registers normally (control), so the fix is not a blanket block. Rejection point: `is_secret_file` is checked before `source.is_file()` / `shutil.copyfile` in both writer `_register()` functions and before `zf.write()` in the ZIP loop. Error messages contain the fixed refusal sentence and no key value.

### 10.2 F2 verdict

**F2: PASS (focused re-review scope)** — the eight required vectors all fail closed, 0 artifacts, 0 ZIPs containing the key, 0 DB rows, and the rejection is pre-copy with a non-secret error message. The commit does what the task's vector list asks for the stored key file.

**This is not a clean "F2 fully closed" result.** The same commit message/record claim "secret-file aliases" and `docs/handoffs/229` claims application to `route_bundle_ingest.py`; independent probing found the following open issues. Overall F2 hardening should stay **OPEN** at the "all designated secret files / env-independent" bar until N-8/N-9/N-10 are fixed or explicitly accepted.

### 10.3 New findings

- **N-8 (HIGH, pre-existing — not closed by b06dadc): `.env` and `session.token` Windows aliases are still copied, and the ZIP branch copies even their plain names.** `attempt_writer._register` keeps only the exact-name set for these two, so `.ENV`, `.env.`, `".env "`, `.env::$DATA`, and a hardlink to `.env` are copied (artifact files created; the fake-key `.env` bytes verified in the copied file); `SESSION.TOKEN`, `session.token.`, and hardlinks behave the same. The Route A multi-evidence ZIP branch calls only `is_secret_file` per source, so a plain `.env` or `session.token` evidence member is accepted and ends up inside the registered `V*-evidence.zip` (Lead probe: zip members `[".env", "other.txt"]`, with the `.env` plaintext key value inside). `var/session.token` is the live GUI session credential (`app/main.py:46-70`); `.env` can hold `BINARYREPAIR_ASSISTANT_PROVIDER_KEY`. This is the same exfiltration class as F2 and is *not* fixed by the commit.
- **N-9 (MEDIUM, regression vs `0d5791a`): the unconditional `assistant.key` name deny was dropped.** The old check refused any source basename `assistant.key`; the new check only refuses the *configured* key file identity plus exact `.env`/`session.token`. When `BINARYREPAIR_ASSISTANT_KEY_FILE` points at a custom name (or a missing custom file), a separate file literally named `assistant.key` is no longer refused and is copied by `attempt_writer` and routea (Lead-reproduced: `is_secret_file=false`, artifact `…/assistant.key` created containing the fake key bytes; default-config control still blocks it). Restore an unconditional `assistant.key` basename deny (in addition to `is_secret_file`) or canonicalise every source against the key path predicate.
- **N-10 (MEDIUM): custom-key protection depends on the adapter process seeing the same `BINARYREPAIR_ASSISTANT_KEY_FILE`.** In-process with the env set the custom file is blocked; a subprocess adapter with the variable removed copies the custom-named key file (Lead-reproduced via a subprocess; routea ZIP member would contain the key bytes). Worker processes inherit `os.environ`, but standalone routea tooling/launchers may not — record this limitation and avoid relying on env-var equality across processes.
- **N-11 (LOW/MEDIUM, documentation integrity): `docs/handoffs/229` overstates the fix.** It says `is_secret_file` was "Applied to `tools/route_bundle_ingest.py`", but that file only gained an **unused import** (0 call sites, confirmed by grep); `_safe_file`/`_register_file` still accept and copy a bundle-local `assistant.key`/`.env` unchecked (route_bundle_ingest only reads inside the bundle root, so this is a defense-in-depth gap rather than a host-key exfiltration path, but the claim is false). The same record's "Tests: full suite pass" was not reproduced: b06dadc adds **no tests** and no committed test references the refusal; the verifier's full-suite attempt on this sandbox gave 740 collected / 715 passed / 13 skipped / **12 environment errors** (all e2e Edge/CDP setup) exit 1; targeted subsets passed (Lead: 66/66 required and 70/70 five-file; verifier: 86/86 targeted). *(Superseded: §11.4 records N-11 FIXED (docs-only) after the final wording correction `3418491`; the code has no runtime guard and the corrected docs say so.)*
- **N-12 (LOW): `is_secret_file` docstring inaccuracy.** It claims the name fallback catches the `::$DATA` spelling "even when the target is momentarily missing"; verified FALSE for a missing configured target (`is_secret_file("…missing.dat::$DATA")` → False). No security impact when the target exists (resolve/samefile catch it), but the documented guarantee is not real.
- **N-13 (INFO): over-blocking trade-off / no tests.** Blocking any path whose normalized basename equals the configured key name even when the key file is absent is conservative and harmless; the commit adds no regression tests for `is_secret_file` or the two writers, so the new behaviour is unguarded against future edits.

### 10.4 Tests and evidence (re-review)

```text
required command (adapted as before: macOS path absent, sandbox tmp_path shim):
D:\Binary_Repair\.venv\Scripts\python.exe -m pytest -q -o addopts= \
  -p dshenv_win_temp -p no:cacheprovider \
  tests/test_assistant_key_store.py tests/test_assistant_key_api.py tests/test_agent_console.py
-> exit 0; 66 passed, 1 warning (store 5 / api 5 / agent console 56)

five-file subset incl. adapters:
tests/test_attempt_writer_gates.py 2 passed; tests/test_routea_adapter.py 2 passed
-> 70 passed, exit 0

git diff --stat b06dadc^ b06dadc           -> 5 files, +51/-2 (no tests)
git diff --stat b06dadc 99d1550 -- <scope> -> empty (docs-only branch movement after the fix)
Lead probes: is_secret_file matrix; required 8 vectors through both writers + ZIP branch
  (both orders); .env/session.token alias matrix; custom-key env-mismatch subprocess;
  route_bundle_ingest claim check; custom-env regression check; error-message scan.
Verifier (independent, task-5): expanded matrix incl. ../ traversal, CLI end-to-end,
  controls, full-suite attempt and targeted subsets; raw logs under
  D:\BinRepair\.tmp\review-f2-b06dadc\ (not committed).
```

### 10.5 Residual limitations

1. Symlink aliases and 8.3 short-name aliases were not executable on this host (symlink privilege `WinError 1314`; 8.3 names disabled); `is_secret_file`'s resolve/samefile logic should catch a symlink to the key file, but this is unverified.
2. POSIX `mode-0600` plaintext fallback not exercised; `is_secret_file` is platform-neutral, but the real-copy exposure on POSIX was not run.
3. The custom-`BINARYREPAIR_ASSISTANT_KEY_FILE` protection is env-dependent (N-10); worker env propagation and launcher configurations were not audited end to end.
4. Full guest→adapter→artifact-download pipeline and `route_bundle_ingest.ingest()` full flow were not driven; the ZIP branch and `_register` primitives were tested directly.
5. Real DPAPI key material was not used; only fake key bytes.
6. The repository's full test suite is not green in this sandbox (12 environment e2e errors); the 740-test "full suite pass" claim remains unreproduced.

### 10.6 Updated disposition

- **F2 focused fix `b06dadc`: PASS** for the required stored-key-file vectors (8/8, pre-copy, 0 artifacts/ZIPs/rows).
- **Overall F2 hardening: OPEN** — N-8 (`.env`/`session.token` aliases + ZIP plain-name copies) is HIGH and in the same leak class; N-9 is a MEDIUM regression; N-10 is an env-dependent coverage limitation; N-11's false claims must be corrected. Recommended before any stable `v1.2.1` tag (and before repeating a "F2 fixed" claim):
  1. generalise the secret predicate to cover `.env`/`session.token` aliases (resolve/samefile/normalized name) and apply it to **every** evidence source, including the Route A ZIP loop (not only `is_secret_file`);
  2. restore the unconditional `assistant.key` basename deny alongside `is_secret_file`, or canonicalise all sources against the configured key path;
  3. wire `is_secret_file` into `route_bundle_ingest` or remove the import and correct `docs/handoffs/229`;
  4. add committed regression tests for the 8 vectors and the `.env`/`session.token` aliases.
  This is consistent with the earlier §9.5 recommendation to keep the stable tag held; an rc prerelease may proceed with these documented limitations.

### 10.7 Submission gates (提交门槛)

| Gate | Status | Evidence |
|---|---|---|
| All bypass attempts rejected | **PASS for the 8 required vectors** (8/8 ValueError, 0 artifacts, 0 zips containing the key, pre-copy) / **NOT CLEAN for the extra attempts** (` .env`/`session.token` aliases, routea ZIP plain names, custom-key env mismatch → N-8/N-9/N-10) | §10.1 table + §10.3; Lead and verifier probes |
| No key leakage | **PASS for the stored `var/assistant.key`** (no copy in any required vector; no full key in repo/logs/responses) / **residual limitation**: `.env` (which may hold the real provider key) and `session.token` can still be copied via N-8 | §10.3 N-8 |
| Unverified items explicit | **PASS** | §10.5 (6 items) |
| P1/V5 evidence unmodified | **PASS** | `git diff --stat b06dadc^ b06dadc -- T8.3-* M4-v4-handoff-* delivery/p1-*` empty; no P1/V5 run repeated |
| Tags/main not moved | **PASS** | `origin/main` still `472aa94b8d931e03a2b20a8e4f671ba64f832230`; no `v1.2.1` tag; release branch moved by M5 docs (`b06dadc`→`99d1550`), not by this review |
| Independent re-review, not M5 self-review | **PASS** | M5 authored `b06dadc`; the fix was reviewed and probed by the M3 reviewer role plus a separately-run independent verifier agent (`task-5`), with separate raw logs. All agents are AI role windows operated by the same human owner: role-separated review, not a human-independent two-person signature — no such claim is made. |

### 10.8 Release-gate restatement (2026-11-10, M3 highest-priority request)

No review work was repeated for this restatement; it records the same `b06dadc` evidence in the exact gate form requested.

```text
reviewed commit b06dadc
F2: PASS

PASS scope: the task-defined F2 bypass vectors against the stored API-key file
(exact path, ASSISTANT.KEY case alias, trailing dot, trailing space, ::$DATA,
hardlink, custom BINARYREPAIR_ASSISTANT_KEY_FILE in the same adapter env, and the
Route A multi-evidence ZIP containing assistant.key). All were rejected with
ValueError before any copy; artifact files = 0; ZIPs containing the key = 0;
DB rows = 0; error text contains no key.
```

- **Windows DPAPI: cited from M2 evidence only.** This F2-focused re-review did not re-test DPAPI and makes **no independent DPAPI claim**; the only basis is M2's recorded evidence (`docs/handoffs/222-v1.2.1-rc-verification-2026-11-09.md` and `docs/handoffs/229-v1.2.1-f2-hardening-2026-11-09.md` / M2's DPAPI probe). Earlier DPAPI runs in this review (§3.5, §9) belong to the original review, not to this F2 gate.
- **PASS/FAIL consequence:** M3 verdict is **PASS** for the F2 focused scope, so the rule "M3 FAIL ⇒ M4 must not publish rc1" is **not triggered** — M4 may publish **v1.2.1-rc1 prerelease only**, with the residuals below disclosed, and must **not** move `main`/tags or claim "F2 fully closed".
- **Not covered by this PASS (stay open for the stable tag):** N-8 (`.env`/`session.token` Windows aliases and Route A ZIP plain-name copies — same leak class, pre-existing), N-9 (MEDIUM regression: unconditional `assistant.key` basename deny dropped under a custom/missing `BINARYREPAIR_ASSISTANT_KEY_FILE`), N-10 (custom-key protection depends on the adapter process seeing the same key-file env). These must be fixed or explicitly accepted before any stable `v1.2.1` tag or "F2 closed" statement.
- **Test record for this request:** required command re-run on the current head: **66 passed, exit 0** (store 5 / api 5 / agent console 56; adapted only for the Windows host + sandbox tmp_path defect). The F2 adversarial probe matrix above is the evidence set (no re-run needed). **Full suite:** attempted by the independent verifier on this sandbox — 740 collected / 715 passed / 13 skipped / **12 environment errors** (all e2e Edge/CDP setup), exit 1; a full green full-suite run is not feasible in this headless sandbox and is not claimed. No P1/V5 run was repeated.

| Gate | Status |
|---|---|
| F2 all bypasses rejected | **PASS** (task-defined 8/8; ValueError pre-copy, 0 artifacts, 0 keys in ZIP) — N-8/N-9/N-10 are outside this scope and remain open |
| No key leakage | **PASS for the stored `var/assistant.key`** (no full key in repo/logs/responses; no copy in required vectors); residual `.env`/`session.token` alias copy = N-8 |
| P1/V5 unmodified | **PASS** (diff empty; no P1/V5 run) |
| Tag/main not moved | **PASS** (`origin/main` `472aa94…`; no `v1.2.1` tag; release head `99d1550` is M5 docs-only) |
| Independent review, not M5 self-review | **PASS** (M3 role + independent verifier agent `task-5`; same human operator → role-separated only) |
| PASS or FAIL explicit | **PASS** (focused F2 scope, as defined above); M4 rc1 rule not triggered; stable tag still held |

---

## 11. N-8/N-9 focused addendum — commits `079da82` (fix) and `ab25c17` (docs) (2026-11-10)

**reviewed fix commit `079da829817c02fef99dd126a927d1bbec790cf0`** ("fix(m5): close literal secret aliases (N8/N9)", M5, 2026-11-10 10:04 +0800; parent `99d1550`), **docs commit `ab25c17`** ("docs(m5): correct N11 and disclose N10 for rc1"), and the **final N-11 wording correction `3418491`** ("docs: correct N11 wording in release branch", docs-only). Reviewed release head at this final pass: `3418491`; the reviewed N-8/N-9 code is unchanged from `079da82` through this head (`git diff --stat 079da82 3418491 -- <reviewed files>` is empty).

- **Fix scope:** `app/services/assistant_key_store.py` adds `_PROTECTED_NAMES = {"assistant.key", ".env", "session.token"}` (line 229), `_normalized_secret_name()` (lines 232-237: casefold, strip after `::`, right-strip spaces/dots) and an **environment-independent literal-name guard** in `is_secret_file()` (lines 239-258; guard at 247-249). The two writers were not changed because they already call `is_secret_file`: `app/services/attempt_writer.py:58`, `tools/routea_bundle_to_attempt.py:47` (single evidence) and `:135` (multi-evidence ZIP loop). One test added (`tests/test_assistant_key_store.py:49-54`).
- **Docs scope:** `ab25c17` corrected `docs/handoffs/229` (literal protected names; no product-runtime coverage for `route_bundle_ingest`; platform-scoped numbers) and added `docs/handoffs/233` (N-10/N-11 disclosure); the final docs-only commit `3418491` then corrected the remaining N-11 wording (`route_bundle_ingest` — "NOT modified by this fix ... no runtime coverage claim"; Windows required target 67 passed; no Windows full-suite pass claimed).
- **Method:** Lead static review + adversarial probe; one **independent** verifier agent (`n8n9-verifier`, Team task `task-6`) with separate logs. M5 wrote the fix and did not review its own work. Fake keys only; no provider/network call; no tracked file modified; no P1/V5 rerun.
- **Windows DPAPI: not re-tested in this addendum.** Reference only to M2's records (`docs/handoffs/222`, `229`); no independent DPAPI claim is made here.

### 11.1 N-8 matrix — `.env` / `session.token` Windows aliases: 10/10 PASS

Each path was exercised against three sinks: `attempt_writer._register`, `routea_bundle_to_attempt._register` (single evidence), and `routea_bundle_to_attempt.convert()` multi-evidence **ZIP branch** (`[alias, other.txt]`). Counts are artifact files created and ZIPs containing secret bytes.

| Alias | `.env` sink result | `session.token` sink result |
|---|---|---|
| exact name | ValueError; 0 copied; 0 zip | ValueError; 0 copied; 0 zip |
| case alias (` .ENV` / `SESSION.TOKEN`) | ValueError; 0 copied; 0 zip | ValueError; 0 copied; 0 zip |
| trailing dot (` .env.` / `session.token.`) | ValueError; 0 copied; 0 zip | ValueError; 0 copied; 0 zip |
| trailing space (`".env "` / `"session.token "`) | ValueError; 0 copied; 0 zip | ValueError; 0 copied; 0 zip |
| NTFS default stream (` .env::$DATA` / `session.token::$DATA`) | ValueError; 0 copied; 0 zip | ValueError; 0 copied; 0 zip |

`is_secret_file` returned True for all ten paths (literal guard, independent of `BINARYREPAIR_ASSISTANT_KEY_FILE`). **Rejection happens before any copy** (artifact directory listing identical before/after; `jobs/` tree not created). Error messages are exactly `refusing to copy secret material into evidence` and contain no `.env`/session-token/key bytes. The Route A multi-evidence ZIP branch (the previous bypass) now rejects these members before `zf.write`, leaves no temp archive, and registers 0 artifacts.

### 11.2 N-9 matrix — literal `assistant.key` independent of env: 18/18 PASS

Six alias spellings (`assistant.key`, `ASSISTANT.KEY`, `Assistant.Key`, `assistant.key.`, `"assistant.key "`, `assistant.key::$DATA`) × three env configurations (env unset/default; custom existing `BINARYREPAIR_ASSISTANT_KEY_FILE=…\mykey.dat`; custom **missing** path) → all 18 combinations: `is_secret_file` True, `attempt_writer` ValueError with 0 copied, routea single ValueError with 0 copied, routea ZIP ValueError with 0 ZIP/artifact. The N-9 regression from §10 is closed: the literal-name guard no longer depends on the configured key path. A subprocess adapter **without** the env var also rejected the literal `assistant.key` (ValueError, 0 copied) — the env-independent part holds across processes.

### 11.3 N-10 — ACCEPTED LIMITATION (confirmed as documented)

- `docs/handoffs/229` now has an explicit "N-10 (accepted limitation)" section, and `docs/handoffs/233` discloses it for rc1: a **custom** `BINARYREPAIR_ASSISTANT_KEY_FILE` is protected only when the adapter process sees the same env; the default path and all literal names are always protected.
- Re-measured behavior matches: same-process custom env → `is_secret_file(mykey.dat)=True`, both writers refuse; adapter subprocess with the env removed → the custom-named `mykey.dat` is copied (bytes verified in the artifact path; the fake-job harness then fails at the DB FK step, after the copy), while literal `assistant.key` is still refused. This is an accepted, disclosed limitation, **not a MUST-FIX** for the rc1 prerelease.

### 11.4 N-11 — FIXED (docs-only; no runtime-guard claim) after correction `3418491`

- **Final correction reviewed:** commit `3418491` (docs-only; release head) changes exactly two docs and no code:
  - `docs/handoffs/229` now says: `tools/route_bundle_ingest.py — NOT modified by this fix. It has no active product call path and no runtime coverage claim.` (the false "guard added" wording is gone);
  - the same record now scopes test numbers honestly: "741/739/2 on this macOS run; M3's required Windows target set is 67 passed; no Windows full-suite pass is claimed here" (matches this reviewer's required-suite count, 67 passed).
- **Code truth (unchanged):** `tools/route_bundle_ingest.py` still only has the `is_secret_file` import with **0 call sites**; it is not wired as a runtime guard. The corrected docs now say exactly that ("NOT modified by this fix", "no runtime coverage claim") instead of claiming a guard — this is the required outcome, and it is explicitly **not** presented as a runtime guard.
- **Verdict: N-11 = FIXED (docs-only).** The task's requirement — `docs/229` corrected, no docs-only fix passed off as a runtime guard — is met. This verdict does not claim the `route_bundle_ingest` copy path is guarded: that path has no active product call path and remains defense-in-depth only (disclosed; see residual below).
- **Residual (INFO):** `docs/handoffs/233` still self-labels `N-11: FAIL (partial, docs-only)`; that label is now stale/conservative rather than false — recommend aligning it to "FIXED (docs-only, no runtime guard)" for consistency in a future docs-only edit. The correction `3418491` is post-publication (the published rc1 predates it); docs-only, non-security, no recall trigger.

### 11.5 Tests and evidence

```text
required command (adapted only for the Windows host + sandbox tmp_path shim):
D:\Binary_Repair\.venv\Scripts\python.exe -m pytest -q -o addopts= \
  -p dshenv_win_temp -p no:cacheprovider \
  tests/test_assistant_key_store.py tests/test_assistant_key_api.py tests/test_agent_console.py
-> exit 0; 67 passed, 1 warning (store 6 / api 5 / agent console 56)
adapter subset: tests/test_attempt_writer_gates.py 2 passed; tests/test_routea_adapter.py 2 passed

Lead probe re-run at final head `3418491` (docs-only change; code unchanged): N-8 10 paths x 3 sinks
  and N-9 6 aliases x 3 env variants x 3 sinks all still PASS (ValueError, 0 artifacts, 0 ZIPs with
  secret, fixed refusal text); N-10 residual unchanged (accepted limitation); docs 229 now reads
  "NOT modified by this fix ... no runtime coverage claim" and the 67-pass Windows number.
Verifier (independent, task-6): instrumented 100-row matrix on the worktree -> 100/100 PASS;
  the same 100-row matrix re-run on the published rc1 candidate tree -> 100/100 PASS; required
  pytest 67 passed / 0 failed; full collection 741; candidate-tree targeted 89 passed / 0 failed.
  Raw logs under D:\BinRepair\.tmp\review-n8n9-079da82\ (not committed).
```

### 11.6 rc1 publication evidence and decision

- **Publication refs (verified read-only from this host):** the public repo is `leesirleesirlee-star/Binary_Repair` (not this workspace's `origin`). `git ls-remote` returned `refs/heads/main 9439340…` (public v1.2.0), `refs/heads/v1.2.1-rc1 → d7d20f4…` and annotated `refs/tags/v1.2.1-rc1` (object `f5346978…`). Records: `docs/handoffs/235` (Lead: rc1 approved, source `ab25c17`, candidate `d7d20f4`, stable HOLD) and `docs/handoffs/237`/`230` (published prerelease, stable boundaries; public main 9439340/v1.2.0, v1.1.3 frozen).
- **Published-tree content verification:** the GitHub contents API at commit `d7d20f4` returned blob SHA-1s **identical** to the reviewed `079da82` blobs for `app/services/assistant_key_store.py` (`e48e6533cd70204aa6be467cb9d5a8107f722794`), `app/services/attempt_writer.py` (`feb150546178781fac99d1ad662dd66a17c45a8a`) and `tools/routea_bundle_to_attempt.py` (`6e8888f332cf0a78db5fa6a5f8afdb0854731cf8`); the raw public file also shows `_PROTECTED_NAMES`/literal-name guard. The independent verifier separately extracted the published rc1 candidate tree from the team's tracked rc1 git bundle (bundle SHA-256 matches the delivery `SHA256SUMS`; tag object matches `docs/handoffs/236/237`), confirmed the same source files byte-identical, found the "close literal secret aliases N8/N9" fix in the candidate history, and **re-ran the full 100-row N-8/N-9 matrix on that candidate tree: 100/100 PASS**. So the published rc1 tree contains the reviewed N-8/N-9 fixed code (git `fetch`/`clone` to the public repo was intermittently blocked from this host; the read-only GitHub API/raw endpoints served the primary verification).
- **Package content:** the delivery branch `origin/delivery/all-hands-2026-11-07` (head `c86c9ab`) contains the refreshed rc1 package after the N-8/N-9 hardening (`05d37cb`) and the N-10/N-11 disclosure (`b3c39db`). The tracked `delivery/handoff-v1.2.1-rc1-2026-11-09.zip` was verified binary-safe: SHA-256 `54e2759d3b77df8b116c3f74227e5bbafc52787676f0bf6a975c1f3dffb261bb` matches its recorded `.sha256`; the ZIP (31 members) contains `docs/handoffs/229`, `232` (N-8/N-9 hardening) and `233` (N-10/N-11 disclosure).
- **Decision (final, after the 2026-11-11 N-11 closure review of `3418491` + handoff `1dbd34c6…`):** **rc1: RETAIN (no recall).** N-8/N-9 are fixed and independently verified on both the reviewed worktree and the published rc1 candidate tree; N-10 is disclosed as accepted; N-11 is **FIXED (docs-only)** by `3418491` (the corrected docs are inside the rebuilt handoff package whose SHA-256 is `1dbd34c6…`), with no runtime guard claimed or implied. **Stable: ELIGIBLE from the M3 security-review standpoint**, subject to: (a) the stable artifact is built from a head that includes `3418491` (corrected docs — if built from the earlier `ab25c17` docs, the false `route_bundle_ingest` guard wording must not be carried over); (b) the N-10 accepted limitation is disclosed in the release notes; (c) N-11 remains described as docs-only — no runtime guard for `route_bundle_ingest` exists or is claimed; (d) full-suite numbers stay platform-scoped (macOS 741/739/2; M3's required Windows target 67 passed) and are not presented as a Windows full-suite pass. M3 does not create/move stable tags or public main; that remains the M4/Lead release process. If the Lead's release policy additionally requires an independent Windows full-suite or an independent DPAPI run, those are outside this pass and stable would be HOLD on that policy.

Residual observations for this addendum (not failures of the N-8/N-9 acceptance criteria): only the exact literal protected names/aliases are guarded — a derived env-file name such as `.env.local` is not in `_PROTECTED_NAMES` and is copied if an untrusted bundle names it (INFO; not part of the declared protected set — extend the set if the team treats env-file families as secret); 8.3 short-name aliases could not be resolved on this volume (unverified); the N-10 custom-env limitation remains accepted and disclosed; the N-11 docs-only correction landed at `3418491` (post-publication) and no runtime guard is claimed — only the stale `233` label remains as INFO.

### 11.7 Submission gates (提交门槛)

| Gate | Status | Evidence |
|---|---|---|
| N-8/N-9 adversarial tests completed | **PASS** | N-8: 10/10 paths × 3 sinks (ValueError, pre-copy, 0 artifacts, 0 ZIPs with secret); N-9: 18/18 env×alias combos + cross-process literal case; both Lead and independent verifier |
| No key leakage | **PASS** for the reviewed vectors | No `.env`/`session.token`/`assistant.key` bytes in any data dir, ZIP, or error text; fixed refusal message only; N-10 residual (custom-name adapter env mismatch) disclosed in 229/233 and copied bytes contain no key in this rc1 Windows config (it is the key file itself — see N-10 accepted limitation) |
| P1/V5 not rerun | **PASS** | No P1/V5 command run; evidence directories untouched |
| Tag/main not moved | **PASS** | This review moved no ref: public `main` `9439340…` (v1.2.0) and the published `v1.2.1-rc1` tag/commit (`f5346978…` → `d7d20f4…`) were observed read-only and unchanged; this workspace's `origin/main` `472aa94…` is also unchanged; no stable tag created |
| rc1 / stable explicit | **PASS** | **rc1: RETAIN (no recall); stable: ELIGIBLE from the M3 security-review view** (conditions in §11.6/§11.9: include `3418491` docs, disclose N-10, no runtime-guard claim, platform-scoped numbers) |
| Handoff package `1dbd34c6…` verified | **PASS** | delivery branch head `b40e244`: `delivery/handoff-v1.2.1-rc1-2026-11-09.zip` SHA-256 = `1dbd34c64901324a70761cd0a33e569d6abb0ad6f0e4ea14429ed72a0f375cf8`, matches its recorded `.sha256`; package contains corrected `229`/`233` (229: route_bundle_ingest NOT modified, no runtime coverage claim; 233: N-11 FAIL(partial), docs-only; platform-scoped numbers) |
| N-8/N-9 still FIXED at final head `3418491` | **PASS** | code delta `079da82..3418491` for the reviewed files = empty; Lead matrix re-run at `3418491` all PASS; verifier 100/100 on worktree and on published candidate tree |
| N-11 doc correction | **PASS (docs-only)** | `3418491` makes 229 say route_bundle_ingest is NOT modified / no runtime coverage claim and scopes the 67-pass Windows number; no docs-only change is presented as a runtime guard (route_bundle_ingest still has 0 call sites; disclosed, not claimed) |
| Independent review, not M5 self-review | **PASS** | M5 wrote `079da82`/`ab25c17`/`3418491`; M3 and a separate independent verifier agent (`task-6`) reviewed; verifier ran its own instrumented 100-row matrix (100/100 PASS) and re-ran it on the published rc1 candidate tree (100/100 PASS). All AI role windows share the same human operator: role-separated review only, no human-independent signature claim. |

### 11.8 F2 overall status after this addendum

**F2 overall: PASS WITH LIMITATION.** The stored-key and literal-secret-name bypass class (N-3/N-8/N-9) is fixed and adversarially verified — by the Lead and by the independent verifier — across aliases, hardlinks, custom/missing env, and the Route A multi-evidence ZIP branch, on both the reviewed worktree and the published rc1 candidate tree. N-10 remains an **ACCEPTED LIMITATION** (custom-named key files require the adapter process to see the same `BINARYREPAIR_ASSISTANT_KEY_FILE`; documented/disclosed for rc1). N-11 is **FIXED (docs-only)** by `3418491` (docs corrected: route_bundle_ingest "NOT modified by this fix", no runtime coverage claim, Windows required target 67 passed; the docs-only correction is not presented as a runtime guard); `docs/handoffs/233` keeps the accurate "N-11: FAIL (partial, docs-only)" label for the code aspect, which is consistent with the absence of a runtime guard. Residual items are non-blocking: derived env-file names such as `.env.local` are outside the literal protected set (INFO); 8.3 short names / symlinks / POSIX 0600 remain unverified here. **rc1: RETAIN (no recall); stable: ELIGIBLE from the M3 security-review view** (conditions in §11.6/§11.9).

### 11.9 Final N-11 closure review — `3418491` + handoff `1dbd34c6…` (2026-11-11)

**Reviewed:** docs-only commit `3418491` ("docs: correct N11 wording in release branch"; release head) and the rebuilt handoff package whose SHA-256 is `1dbd34c64901324a70761cd0a33e569d6abb0ad6f0e4ea14429ed72a0f375cf8` (delivery branch `origin/delivery/all-hands-2026-11-07` head `b40e244`). No code changed between `079da82` and `3418491` for the reviewed files; no P1/V5 command was run.

**Required confirmations (all PASS):**

1. **`229` no longer presents `route_bundle_ingest` as a runtime guard** — current text: "`tools/route_bundle_ingest.py` — NOT modified by this fix. It has no active product call path and no runtime coverage claim." Code truth is consistent: the module has only the unused `is_secret_file` import (0 call sites).
2. **`233` explicitly states N-11 FAIL(partial)** — current text: "N-11: FAIL (partial, docs-only) — 229 wording corrected but no runtime guard; full-suite numbers platform-scoped." This is accurate for the code aspect and is preserved (not papered over).
3. **Full-suite numbers are platform-limited** — `229`: "741/739/2 on this macOS run; M3's required Windows target set is 67 passed; no Windows full-suite pass is claimed here." No Windows full-suite pass is presented as verified by this review.

**Handoff package verification:** the delivery-branch `delivery/handoff-v1.2.1-rc1-2026-11-09.zip` was read binary-safe; SHA-256 = `1dbd34c6…` matches the recorded `.sha256` (and matches the Lead handoff hash in `docs/handoffs/245`). The 36-member package contains the corrected `docs/handoffs/229` and `233` with the texts quoted above, plus the rc1 README/SHA256SUMS. The correction is post-publication (published rc1 `d7d20f4` predates it); the code tree of published rc1 was previously verified identical to the reviewed fixed code, so there is **no rc1 recall trigger**.

**Still-FIXED/mandatory states:** N-8 FIXED (10 paths × 3 sinks, 0 artifacts/0 ZIPs with secret, pre-copy ValueError — Lead and independent verifier 100/100); N-9 FIXED (6 aliases × 3 env variants × 3 sinks + env-removed subprocess — all rejected; literal `assistant.key` is env-independent); N-10 ACCEPTED LIMITATION (custom-named key file protection requires the adapter process to see the same env; documented in 229/233); required suite re-run 2026-11-11: **67 passed / exit 0** (store 6 / api 5 / agent console 56). Re-running the required suite at the same code state does not change any verdict.

**Final verdicts for this review:**

```text
reviewed commit: 3418491 (docs-only; release head) + handoff 1dbd34c6… (verified package hash)
N-8:  FIXED
N-9:  FIXED
N-10: ACCEPTED LIMITATION
N-11: FIXED (docs-only) — documentation finding closed; no runtime guard exists or is claimed;
      docs/handoffs/233 keeps the accurate FAIL(partial, docs-only) label for the code aspect
F2 overall: PASS WITH LIMITATION
rc1:  RETAIN (no recall)
stable: ELIGIBLE (M3 security-review view; conditions in §11.6: build from a head including 3418491,
        disclose N-10, no runtime-guard claim, platform-scoped full-suite numbers; tag/main action
        remains M4/Lead's process)
```

**Gates for this closure review:**

| Gate | Status | Evidence |
|---|---|---|
| 229 not a runtime-guard claim | **PASS** | 229 text + code truth (route_bundle_ingest import only, 0 call sites) |
| 233 explicit N-11 FAIL(partial) | **PASS** | 233 text retained; no overclaim |
| Full-suite numbers platform-limited | **PASS** | 229 text: macOS 741/739/2; M3 required Windows 67; no Windows full-suite claim |
| Handoff `1dbd34c6…` verified | **PASS** | binary-safe SHA-256 match; package contains corrected 229/233; Lead record 245 hash match |
| No P1/V5 modification | **PASS** | no P1/V5 command run; no P1/V5 path change in this review's commits |
| No tag/main movement | **PASS** | no ref created/moved by this review; public `main` 9439340/v1.2.0 and `v1.2.1-rc1` tag unchanged; workspace `origin/main` 472aa94 unchanged |
| Docs-only not passed off as runtime guard | **PASS** | verdict and release conditions explicitly say docs-only/no runtime guard |
| rc1 / stable explicit | **PASS** | **rc1: RETAIN (no recall); stable: ELIGIBLE (M3 security-review view)** |

### 11.10 M3 confirmation for the proposed stable candidate (2026-11-11)

**Context.** A team member prepared a docs-only stable successor, local commit `148d236d46bbd514dbb48f0a0f506ef2a2143fcc`, based on public rc1 `d7d20f4`, and asked the Lead for the stable decision. M3's condition for stable eligibility requires the corrected N-11 documentation in the stable artifact. **M3's task in that request is the documentation confirmation of the proposed public stable tree.**

**Verified claims about public rc1 `d7d20f4` — it does NOT satisfy M3's condition.** Read directly from the public repo (`leesirleesirlee-star/Binary_Repair`, raw files at `d7d20f4`):

- `docs/development/handoffs/217-v1.2.1-f2-hardening.md` still says: "`tools/route_bundle_ingest.py` — guard added; this module has no active product call path (do not claim runtime coverage)". Source `3418491` corrected exactly this to "NOT modified by this fix ... no runtime coverage claim". The false guard claim is still in the public rc1 tree.
- `docs/development/handoffs/220-v1.2.1-n10-n11.md` still says "N-11: FIXED (229 corrected: route_bundle_ingest has no active product call path; full-suite numbers platform-scoped)", whereas corrected source `233` says "N-11: FAIL (partial, docs-only) — 229 wording corrected but no runtime guard". The public rc1 tree still overstates N-11 as fixed.
- `README.md` on the public rc1 tree says "Release v1.2.0 (2026-11-09)" — no v1.2.1 identity.
- (For continuity: the reviewed application code on the public rc1 tree was previously verified blob-identical to the fixed source for the key/F2 surface; the mismatch is documentation/version only.)

**Proposed successor `148d236…` is not independently verifiable from this host.** GitHub API commit lookup returns `422 No commit found`; the hash is not in this workspace's `origin` refs, and the message states it is local-only and unpushed. M3 cannot confirm a documents-only claim without the tree — a docs-only diff must still be inspected. Once pushed to a branch / provided as a bundle/patch, M3 verification is a short, deterministic pass (below).

**Accessible corrected artifact — M1 candidate branch `origin/release/v1.2.1-candidate-2026-11-11` @ `612510d`:**

- `docs/handoffs/229` and `docs/handoffs/233` are **blob-identical** to corrected source `3418491` (`388bfe9a…` / `ffc204d5…`): 229 says route_bundle_ingest is NOT modified / no runtime coverage claim; 233 says N-11 FAIL(partial, docs-only); numbers platform-scoped.
- **No application-code delta** vs reviewed fix commit `079da82` (`git diff --stat 079da82 612510d -- app binaryrepair_ai routea routeb workers tools schemas` empty).
- Adds `SETUP.md` + `release/V1.2.1-RC1-CANDIDATE-2026-11-11.md` (pins source `3418491`, public `d7d20f4`, RC tag `f5346978…`, public main `9439340`; states stable HOLD).
- M3 ran the required target suite on this tree: **67 passed / exit 0** (store 6 / api 5 / agent console 56; same host/tmp-path shim caveat as earlier passes).
- **Gaps for a public stable snapshot:** its `README.md` has no v1.2.1 release/version line (public rc1 README says v1.2.0), and it uses source-tree doc paths (`docs/handoffs/229/233`) rather than the public-tree paths (`docs/development/handoffs/217/220`). A published stable tree therefore still needs the README version update plus the two public-path documentation corrections — the same three-file intent as `148d236…`.

**M3 acceptance criteria for the corrected stable target (confirmation is currently PENDING, not given):**

1. The **public tree** at the proposed stable commit has `docs/development/handoffs/217` and `220` corrected to match the `3418491` content (the quotes above) and `README.md` identifies the release as **v1.2.1** (not v1.2.0).
2. **No application-code delta** vs `d7d20f4` (otherwise full re-review and full tests are required); if built from source `612510d`, the public snapshot's app files must remain byte-identical to the verified fixed code for the key/F2 surface (M2 confirms the broader tree).
3. N-10 remains an accepted, disclosed limitation; N-11 remains docs-only and **no runtime guard is claimed** for `route_bundle_ingest`.
4. M3 verifies the exact proposed commit/tree (pushed branch, bundle, or patch). M3 cannot sign for M1/M2/M4 and does not publish.

**M3 input on the three Lead questions (recommendation only; publication authority is the Lead/M4):**

1. **Stable GO:** **conditional YES from M3** — accept N-10 as a documented limitation and N-11 as a docs-only fix with no runtime guard; this match §11.9. The condition is criterion (1)/(4) above: the public stable tree must actually contain the corrected N-11 documentation.
2. **Target:** **use the corrected successor, not `d7d20f4`** — `d7d20f4` fails M3's documentation condition as shown above. `148d236…` may be used **after** M3 verifies it against the criteria; if it cannot be made available quickly, produce the public stable snapshot from the corrected source (`3418491`/`612510d`) with the README/public-path doc fixes and have M3 verify that commit.
3. **Public `main`:** M3 has **no security objection** to moving `main` to the same approved stable commit (single identity for release and main), with the RC tag left untouched; M2 must verify the public tree and M4 owns the publication.

**Status:** M3 documentation confirmation = **PENDING** — public `d7d20f4` is **not confirmed**, and the corrected successor is not yet accessible. No P1/V5 run or modification; this review moved no tag/main.

### 11.11 Stable-target documentation sign-off — BLOCKED: candidate not published (2026-11-11)

**Task received:** fetch M4's `release/v1.2.1-stable-candidate`; diff `148d236…` against public `d7d20f4`; confirm only README/217/220 changed; confirm no application-code change; then sign `stable docs: PASS`.

**Result: BLOCKED — the branch and commit are not published to either repository reachable from this host. M3 cannot inspect the candidate and must not sign an unseen artifact.**

*(Superseded: the bundle `v1.2.1-stable-148d236.bundle` was delivered on 2026-11-11 and the sign-off was completed in §11.12 — `stable docs: PASS` for the exact commit `148d236d46bbd514dbb48f0a0f506ef2a2143fcc`.)*

Evidence:
- `git ls-remote --heads origin` (chenfanaichifan/binary-repair, 88 heads incl. `release/v1.2.1`, `release/v1.2.1-candidate-2026-11-11`, `release/v1.2.1-handoff-2026-11-09`): **no `release/v1.2.1-stable-candidate`**. Branch-name variants tried: `release/v1.2.1-stable`, `v1.2.1-stable-candidate`, `release/stable-v1.2.1`, `stable/v1.2.1`, `release/v1.2.1-stable-candidate-2026-11-11` — none.
- Public repo `leesirleesirlee-star/Binary_Repair`: branches are only `main` (9439340) and `v1.2.1-rc1` (d7d20f4); forks list is empty; no stable-candidate branch.
- Proposed commit `148d236d46bbd514dbb48f0a0f506ef2a2143fcc`: GitHub API returns `422 No commit found` on both repositories; `git fetch <remote> 148d236…` returns "upload-pack: not our ref"; the object is not in this workspace's git objects or worktrees.
- No `v1.2.1` stable tag exists on either remote (only `v1.2.1-rc1`).

Baseline verified meanwhile (so the sign-off is one pass once the artifact is visible):
- Public rc1 `d7d20f4` was fetched locally via annotated tag `v1.2.1-rc1` (tag object `f5346978…`) and is retained under a local review ref; its documentation is confirmed to be the pre-correction state:
  - `README.md`: "Release v1.2.0 (2026-11-09)".
  - `docs/development/handoffs/217-v1.2.1-f2-hardening.md`: route_bundle_ingest "guard added"; old numbers "…Windows M3 used 66/740 with e2e environment skips."
  - `docs/development/handoffs/220-v1.2.1-n10-n11.md`: "N-11: FIXED (229 corrected…)".
- Corrected text is available in source `3418491` and M1 candidate `612510d`: docs `229` — "NOT modified by this fix. It has no active product call path and no runtime coverage claim."; docs `233` — "N-11: FAIL (partial, docs-only) — 229 wording corrected but no runtime guard; full-suite numbers platform-scoped"; numbers — "741/739/2 on this macOS run; M3's required Windows target set is 67 passed; no Windows full-suite pass is claimed here."
- Public rc1's key/F2 application files were previously verified blob-identical to the reviewed fixed source (`assistant_key_store.py`, `attempt_writer.py`, `routea_bundle_to_attempt.py`); the stable candidate must preserve that (no application-code delta).
- **Exact expected 3-file diff for the stable candidate:**
  1. `README.md`: release identity v1.2.0 → v1.2.1.
  2. `docs/development/handoffs/217-v1.2.1-f2-hardening.md`: replace the "guard added" sentence with the corrected one; replace the old Windows number sentence with "M3's required Windows target set is 67 passed; no Windows full-suite pass is claimed here."
  3. `docs/development/handoffs/220-v1.2.1-n10-n11.md`: N-11 line → "N-11: FAIL (partial, docs-only) — 229 wording corrected but no runtime guard; full-suite numbers platform-scoped."
  No other file may change (especially no `app/`, `tests/`, fixtures/evidence, P1/V5, tag/main).

M3 sign-off checklist, to run once the branch/commit is available:
1. `git diff --name-only d7d20f4 <candidate>` == exactly {`README.md`, `docs/development/handoffs/217-v1.2.1-f2-hardening.md`, `docs/development/handoffs/220-v1.2.1-n10-n11.md`}.
2. `git diff --quiet d7d20f4 <candidate> -- app binaryrepair_ai routea routeb workers tools schemas tests fixtures artifacts` passes (no application-code/test/evidence changes).
3. Contents match the corrected text above; README identifies v1.2.1; N-10 accepted limitation is retained; no runtime-guard claim is made.
4. The candidate tree is reachable from this host (branch pushed to origin/public or a bundle/patch + SHA provided); M3 records the exact signed commit SHA.
5. Optional: re-run the targeted key/API/console suite on the candidate tree; with no code delta the expected result is 67/67 (as measured on `3418491`/`612510d`).

**Sign-off status: `stable docs: PENDING/BLOCKED` — not PASS.** An unreviewed local-only commit cannot be signed; missing is not passing. This is a missing-artifact block, not a content FAIL.

Constraints respected: no docs-only change is described as a runtime guard; no P1/V5 command or modification; no tag/main movement (public `main` 9439340/v1.2.0 and `v1.2.1-rc1` tag unchanged; workspace `origin/main` 472aa94 unchanged; no stable tag; locally fetched public tags were removed and the rc1 commit retained only under a local `refs/review/…` ref for the pending comparison).

**Next action for M4:** push `release/v1.2.1-stable-candidate` (or provide the commit/bundle/patch + SHA) so M3 can fetch `148d236…`; M3 then completes the diff/no-code-change checks and reports `stable docs: PASS/FAIL` in one pass.

### 11.12 Stable-target documentation sign-off — `stable docs: PASS` (2026-11-11)

**Task received:** review the exact public candidate delivered as `v1.2.1-stable-148d236.bundle`, specifically the N-10 disclosure and N-11 wording, and confirm or reject it in M3's own record. Prior approval (M3 review `f311086` of source `3418491`) does not sign this new public commit.

**Candidate transfer verification:**
- Bundle file: `v1.2.1-stable-148d236.bundle`; SHA-256 = `c279ce826aeed1e02d074f0026642c0cb63810539627499013e0110e0dea6b3c` — matches the expected value.
- `git bundle verify` → "is okay"; bundle contains `refs/heads/prep/v1.2.1-stable-docs` → `148d236d46bbd514dbb48f0a0f506ef2a2143fcc`, requires parent `d7d20f4`.
- Fetched into a local review ref (`review/v1.2.1-stable-148d236`); `git rev-parse` = `148d236d46bbd514dbb48f0a0f506ef2a2143fcc` (matches expected). Candidate commit: `Release preparation <release-preparation@users.noreply.github.com>`, 2026-11-11 20:02:36, "docs: prepare v1.2.1 stable documentation".
- Parent = `d7d20f4ff2f920b5cfec5e81e3c4377529a9885a`; public main `9439340` is an ancestor of the candidate (`git merge-base --is-ancestor` true).

**Diff vs public RC `d7d20f4` — exactly three documentation files, nothing else:**

```text
M README.md                                            7 +-    (Version v1.2.1; source pin; test-row label)
M docs/development/handoffs/217-v1.2.1-f2-hardening.md 8 +-    (N-11 wording: NOT modified/no runtime coverage; Windows 67-pass/scoped numbers)
M docs/development/handoffs/220-v1.2.1-n10-n11.md      4 +-    (N-11 label -> FAIL (partial, docs-only); N-10 retained)
3 files changed, 9 insertions(+), 10 deletions(-)
```

- `git diff --check` on the candidate: **clean** (no whitespace errors).
- **No application-code, test, fixture or evidence change:** the name-only diff is exactly the three docs files above; `git diff --quiet d7d20f4 148d236 -- app binaryrepair_ai routea routeb workers tools schemas tests fixtures artifacts` exits 0.
- `docs/development/handoffs/217` blob = `388bfe9a89860a9e7675e47955c31f33a5f79a96` = corrected source `3418491:docs/handoffs/229…` blob (byte-identical corrected text); `220` blob = `ffc204d5a2e41ce555311fff329c2f737138571f` = corrected source `233` blob. The public candidate therefore carries exactly the N-11 corrections that M3 reviewed at source.

**Content checks against M3's conditions (`f311086`/§11.9):**
- `README.md`: "Version v1.2.1"; source pin "release/v1.2.1 @ 3418491 (source and corrected documentation)"; the old test-suite total is explicitly relabelled "historical v1.2.0 record" so it cannot be misread as a v1.2.1 result; browser-e2e row unchanged.
- `217`: route_bundle_ingest is "NOT modified by this fix. It has no active product call path and no runtime coverage claim."; numbers are "741/739/2 on this macOS run; M3's required Windows target set is 67 passed; no Windows full-suite pass is claimed here."
- `220`: "N-11: FAIL (partial, docs-only) — 229 wording corrected but no runtime guard; full-suite numbers platform-scoped"; N-10 "ACCEPTED LIMITATION (custom key path requires adapter to see same env; default path and literal name are always protected)" retained.
- Candidate-tree grep finds no "guard added" claim; only the negative "no runtime coverage claim" / "no runtime guard" statements.
- Verification run on the candidate tree: required targeted suite (`test_assistant_key_store.py` + `test_assistant_key_api.py` + `test_agent_console.py`) = **67 passed / exit 0** (store 6 / api 5 / agent console 56; same Windows-host/sandbox tmp_path shim caveat as prior passes). No RC/source result is re-attributed; the preparer's statement that no suite/browser run was performed on this comment is respected — this targeted run is M3's own, on the candidate tree, and no browser run is claimed.

**Public refs at review time (read-only):** public `main` = `9439340` (v1.2.0); RC tag `v1.2.1-rc1` object `f5346978…` → `d7d20f4`; branch `v1.2.1-rc1` = `d7d20f4`. Candidate `148d236` is local-only (bundle) and has not been published; M3 performed no tag/main movement.

**Sign-off:**

```text
reviewed public candidate: 148d236d46bbd514dbb48f0a0f506ef2a2143fcc
parent:                    d7d20f4ff2f920b5cfec5e81e3c4377529a9885a
bundle SHA-256:            c279ce826aeed1e02d074f0026642c0cb63810539627499013e0110e0dea6b3c (verified)
diff scope:                README.md + docs/development/handoffs/217 + docs/development/handoffs/220 only
application code:          unchanged (0 code/test/evidence delta)
N-10:                      ACCEPTED LIMITATION, disclosed (custom key-file env requirement retained)
N-11:                      docs-only correction; no runtime guard claimed
stable docs:               PASS  (for this exact public commit; not a signature on a recreated commit)
```

**Boundaries:** this PASS is documentation sign-off for the exact SHA `148d236…`; it is not an attestation that a release occurred and it does not sign for M1/M2/M4. No docs-only change is described as a runtime guard; no P1/V5 command or modification was made; no tag/main was created or moved by this review (only local refs for the bundle/RC commits were kept for traceability). Prior approvals remain attributed to their original sources/platforms.

**Next (per the Lead's ordered workflow):** M4 re-reads current public refs and release conditions and stops if they changed unexpectedly; publishes `v1.2.1` and fast-forwards public `main` to the exact target `148d236…` only after this acceptance, preserving the RC tag; M1 produces the stable handoff + LF SHA256SUMS from the actual published refs; M2 independently verifies the published stable tree and records its own results after release.
